package com.link.anything.middleware.stream.media.common.domain;

public enum HistoryVideoPlayControl {
  Play(0),FastForward(1),KeyframeRewindPlayback(2),KeyframePlay(3),SingleFramePlay(4);

  private int code;

  HistoryVideoPlayControl(int code) {
    this.code = code;
  }
}
