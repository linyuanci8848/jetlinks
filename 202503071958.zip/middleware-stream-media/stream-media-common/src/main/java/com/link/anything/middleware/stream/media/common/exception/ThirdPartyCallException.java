package com.link.anything.middleware.stream.media.common.exception;

import lombok.Data;

/**
 * 简介
 *
 * @author linyuanci
 */
@Data
public class ThirdPartyCallException extends RuntimeException {
    public static final String DEFAULT_MESSAGE = "第三方调用异常";

    private Object rawResp;

    public ThirdPartyCallException(Object rawResp) {
        super(DEFAULT_MESSAGE);
        this.rawResp = rawResp;
    }
}
