package com.link.anything.middleware.stream.media.common.domain;

public enum StreamTransferMethod {
  /**
   * TCP被动
   */
  TCP_PASSIVE,
  /**
   * TCP主动
   */
  TCP_ACTIVE,
  /**
   * UDP被动
   */
  UDP_PASSIVE,
  /**
   * UDP主动
   */
  UDP_ACTIVE;
}

