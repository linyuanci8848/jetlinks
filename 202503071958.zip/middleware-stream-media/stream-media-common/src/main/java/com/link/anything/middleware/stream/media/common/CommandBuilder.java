package com.link.anything.middleware.stream.media.common;

import com.link.anything.common.constant.Command;
import com.link.anything.common.constant.Parameter;
import java.util.ArrayList;

/**
 * 命令构建器
 */
public class CommandBuilder {

  private Command command;

  public static CommandBuilder newBuilder(String key) {
    CommandBuilder commandBuilder = new CommandBuilder();
    commandBuilder.command = new Command();
    commandBuilder.command.setKey(key);
    commandBuilder.command.setParameters(new ArrayList<>());
    return commandBuilder;
  }

  /**
   * 追加参数
   *
   * @param key
   * @param value
   * @return
   */
  public CommandBuilder appendParameter(String key, String value) {
    Parameter parameter = new Parameter();
    parameter.setValue(value);
    parameter.setKey(key);
    this.command.getParameters().add(parameter);
    return this;
  }

  /**
   * 构建指令对象
   *
   * @return
   */
  public Command build() {
    return this.command;
  }


}
