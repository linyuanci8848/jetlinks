//package com.link.anything.middleware.stream.media.common.middleware;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.kafka.core.KafkaOperations;
//import org.springframework.kafka.listener.CommonErrorHandler;
//import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
//import org.springframework.kafka.listener.DefaultErrorHandler;
//import org.springframework.kafka.support.converter.BatchMessagingMessageConverter;
//import org.springframework.kafka.support.converter.JsonMessageConverter;
//import org.springframework.kafka.support.converter.RecordMessageConverter;
//import org.springframework.util.backoff.FixedBackOff;
//
///**
// * Kafka 配置初始化
// */
//@Configuration
//public class KafkaConfiguration {
//
//
//
//  @Bean
//  public CommonErrorHandler errorHandler(KafkaOperations<Object, Object> template) {
//    return new DefaultErrorHandler(new DeadLetterPublishingRecoverer(template), new FixedBackOff(1000L, 2));
//  }
//
//  @Bean
//  public RecordMessageConverter converter() {
//    return new JsonMessageConverter();
//  }
//
//  @Bean
//  public BatchMessagingMessageConverter batchConverter() {
//    return new BatchMessagingMessageConverter(converter());
//  }
//}
