package com.link.anything.middleware.stream.media.common.domain;

import lombok.Data;

@Data
public class MediaTrack {
  /**
   * 音频通道数
   */
  private int channels;

  /**
   *  H264 = 0, H265 = 1, AAC = 2, G711A = 3, G711U = 4
   */
  private int codecId;

  /**
   * 编码类型名称 CodecAAC CodecH264
   */
  private String codecIdName;

  /**
   * Video = 0, Audio = 1
   */
  private int codecType;

  /**
   * 轨道是否准备就绪
   */
  private boolean ready;

  /**
   * 音频采样位数
   */
  private int sampleBit;

  /**
   * 音频采样率
   */
  private int sampleRate;

  /**
   * 视频fps
   */
  private int fps;

  /**
   * 视频高
   */
  private int height;

  /**
   * 视频宽
   */
  private int width;
}
