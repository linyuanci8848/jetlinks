package com.link.anything.middleware.stream.media.common.domain;

/**
 * 播放类型
 */
public enum HistoryStreamPlayType {
  /**
   * 正常播放
   */
  Normal,
  /**
   * 快进
   */
  FastForward,
  /**
   * 关键帧快退播放
   */
  KeyFramesFastBack,
  /**
   * 关键帧播放
   */
  KeyFrames,

  /**
   * 单帧播放
   */
  SingleFrame;


}
