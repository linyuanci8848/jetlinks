package com.link.anything.middleware.stream.media.common.domain;


import java.io.Serializable;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import cn.hutool.core.collection.ConcurrentHashSet;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 一个推流一个session
 * <p>这个对流对象对应多个播放流</p>
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@ToString
public class StreamSession implements Serializable {


  /**
   * 推流鉴权
   * <p>用在Zl的 on_publish 事件</p>
   */
  @Builder.Default
  private String streamSource = UUID.randomUUID().toString();
  /**
   * 流播放Token
   * <p>创建的时候默认给当前流创建者创建一个播放Token</p>
   */
  @Builder.Default
  private Set<String> playTokens = new ConcurrentHashSet<>();


  @Builder.Default
  private StreamSessionApp app = StreamSessionApp.live;


  /**
   * 流媒体服务器ID
   */
  private String mediaServerId;
  /**
   * 对应的设备标识
   */
  private String device;
  /**
   * 对应的通道信息
   */
  private String channel;

  /**
   * 流源类型
   */
  private StreamSourceProtocol streamSourceProtocol;

  /**
   * 视频流接收服务器IP
   * <p>推流有效</p>
   */
  private String receiveIp;
  /**
   * 视频流接收端口
   * <p>推流有效</p>
   */
  private Integer receivePort;

  /**
   * 网络类型
   */
  private StreamTransferMethod streamTransferMethod;

  /**
   * 码流
   */
  private Integer bitstream;
  /**
   * 流类型
   */
  private StreamType streamType;


  /**
   * 片段开始时间戳
   */
  private Long start;

  /**
   * 片段结束时间戳
   */
  private Long end;


  /**
   * 流唯一标识
   */
  private String streamId;


  private String ssrc;
  /**
   * 流总数
   */
  @Builder.Default
  private AtomicInteger streamTotal = new AtomicInteger(0);
  /**
   * 流代理标识，只有TCP主动模式才有效
   */
  private String streamProxyKey;

  public String addToken() {
    String token = UUID.randomUUID().toString();
    this.playTokens.add(token);
    return token;
  }

  /**
   * 验证Token 是否存在
   *
   * @param token
   * @return
   */
  public boolean verifyToken(String token) {
    return this.playTokens.contains(token);
  }

  /**
   * 流是否就绪
   */
  @Builder.Default
  private volatile boolean ready = false;
  /**
   * 会话创建时间
   */
  @Builder.Default
  private Long createAt = System.currentTimeMillis();

}
