package com.link.anything.middleware.stream.media.common.domain;

/**
 * 实时视频流控制
 */
public enum LiveStreamControl {
  /**
   * 关闭视频流
   */
  CLoseVideo,
  /**
   * 关闭音频流
   */
  CloseAudio,
  /**
   * 关闭音频和视频
   */
  CloseAudioAndVideo,
  /**
   * 切换码流
   */
  ChangeBitStream,
  /**
   * 暂停流发送
   */
  PauseStream,
  /**
   * 继续流发送
   */
  ContinueStream;
}
