package com.link.anything.middleware.stream.media.common.domain;

import lombok.Getter;

@Getter
public enum PTZStreamControl {

  /**
   * 左移
   */
  Left(2),
  /**
   * 右移
   */
  Right(1),
  /**
   * 上移
   */
  Up(8),
  /**
   * 下移
   */
  Down(4),
  /**
   * 上左移动
   */
  UpLeft(10),
  /**
   * 上右移动
   */
  UpRight(9),
  /**
   * 下左移动
   */
  DownLeft(6),
  /**
   * 下右移动
   */
  DownRight(5),
  /**
   * 缩小画面
   */
  ZooMin(16),
  /**
   * 放大画面
   */
  ZoomOut(32),
  /**
   * 停止移动
   */
  Stop(0);

  private int code;

  PTZStreamControl(int code) {
    this.code = code;
  }
}
