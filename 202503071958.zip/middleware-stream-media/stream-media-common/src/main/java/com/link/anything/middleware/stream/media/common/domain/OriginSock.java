package com.link.anything.middleware.stream.media.common.domain;

import lombok.Data;

@Data
public class OriginSock {
  private String identifier;
  private String local_ip;
  private int local_port;
  private String peer_ip;
  private int peer_port;
}
