package com.link.anything.middleware.stream.media.common.constant;

/**
 * 这里定义全局的系统事件Key，方便其他模块对事件进行监听然后处理相关的业务逻辑
 *
 * @author lemon-mx
 */
public enum StreamDefinitionEventKey {
  /**
   * 流注册
   */
  StreamRegister,
  /**
   * 流注销
   */
  StreamUnRegister,
  /**
   *
   */
  PlayTimeout,
  /**
   * 流媒体服务器启动
   */
  MediaServerStart,
  /**
   * 流媒体服务器停止
   */
  MediaServerStop,
  /**
   * 流推送事件
   */
  StreamPush,
  /**
   * 视频流查询回执事件
   */
  HistoryVideoFindCallback,
  /**
   * 设备状态变化
   */
  DeviceStateChange,
  /**
   * 对话流注册事件
   */
  TalkStreamRegister,
  /**
   * 对讲流链路用户端介入
   */
  TalkStreamLinkUserTerminalJoin,
  /**
   * 报警截图完成
   */
  DeviceAlarmSnapshotFinish,

  /**
   * 报警截图上传
   */
  DeviceAlarmSnapshotUpload;
}
