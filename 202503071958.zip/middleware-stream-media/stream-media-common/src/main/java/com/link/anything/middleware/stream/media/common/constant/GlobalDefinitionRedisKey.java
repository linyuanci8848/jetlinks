package com.link.anything.middleware.stream.media.common.constant;

/**
 * 预定义redis Key
 *
 * @author YcYa_xbj
 */
public class GlobalDefinitionRedisKey {

  /**
   * 在线媒体服务器列表
   */
  public static final String MEDIA_SERVER_ONLINE_LIST = "middleware:stream:media:online_media_server";
  /**
   * 历史音视频查询流水号
   */
  public static final String JTT1078_HISTORY_SN_KEY = "middleware:stream:media:jtt1078_history_sn";
  /**
   * 设备通道流水号
   */
  public static final String DEVICE_CHANNEL_SN_KEY = "middleware:stream:media:device_channel_sn";

  /**
   * CSEQ 计数器
   */
  public static final String SIP_CSEQ_PREFIX = "middleware:stream:media:sip_cseq_";


  /**
   * 音频流锁
   * <p>单一设备同时只能跟一个对象进行通话</p>
   */
  public static final String LOCK_KEY_AUDIO_STREAM = "LOCK_KEY:middleware:stream:media:history";


}
