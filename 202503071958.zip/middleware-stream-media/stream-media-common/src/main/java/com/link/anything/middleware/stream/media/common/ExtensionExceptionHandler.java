package com.link.anything.middleware.stream.media.common;

import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.link.anything.middleware.stream.media.common.exception.ThirdPartyCallException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.TypeMismatchException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;

import org.springframework.validation.BindException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/**
 * 全局异常处理
 *
 * @author YcYa_xbj
 */
@Slf4j
@RestControllerAdvice
public class ExtensionExceptionHandler {



  @ExceptionHandler(value = BindException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String exceptionHandler(BindException e) {
    List<String> messages = new ArrayList<>();
    e.getAllErrors().forEach(item -> messages.add(item.getDefaultMessage()));
    return String.join("\n", messages);
  }


  @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
  @ResponseBody
  public ResponseEntity<String> httpRequestMethodNotSupportedExceptionHandler(HttpRequestMethodNotSupportedException e) {
    log.error("http请求的方法不正确:【" + e.getMessage() + "】");
    return ResponseEntity.status(405).body(e.getMessage());
  }


  /**
   * 请求参数不全
   */
  @ExceptionHandler(MissingServletRequestParameterException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String missingServletRequestParameterExceptionHandler(MissingServletRequestParameterException e) {
    log.error("请求参数不全:【" + e.getMessage() + "】");
    return "参数不全";
  }

  /**
   * 请求参数类型不正确
   */
  @ExceptionHandler(TypeMismatchException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String typeMismatchExceptionHandler(TypeMismatchException e) {
    log.error("请求参数类型不正确:【" + e.getMessage() + "】");
    return "参数类型不正确";
  }


  @ExceptionHandler(IllegalArgumentException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String exceptionHandler(IllegalArgumentException e) {
    log.warn(e.getLocalizedMessage());
    return e.getMessage();
  }

  @ExceptionHandler(MethodArgumentTypeMismatchException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String exceptionHandler(MethodArgumentTypeMismatchException e) {
    if (log.isDebugEnabled()) {
      log.error(e.getLocalizedMessage(), e);
    }
    return e.getMessage();
  }

  @ExceptionHandler(value = MismatchedInputException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String exceptionHandler(final MismatchedInputException e) {
    if (log.isDebugEnabled()) {
      log.error(e.getLocalizedMessage(), e);
    }
    return "非法数据";
  }

  @ExceptionHandler(value = HttpMessageNotReadableException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String exceptionHandler(final HttpMessageNotReadableException e) {
    if (log.isDebugEnabled()) {
      log.error(e.getLocalizedMessage(), e);
    }
    log.error(e.getLocalizedMessage(), e);
    return "非法数据";
  }

  @ExceptionHandler(value = DateTimeParseException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String exceptionHandler(final DateTimeParseException e) {
    if (log.isDebugEnabled()) {
      log.error(e.getLocalizedMessage(), e);
    }
    log.error(e.getLocalizedMessage(), e);
    return "非法数据";
  }

  @ExceptionHandler(value = DuplicateKeyException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public String exceptionHandler(final DuplicateKeyException e) {
    if (log.isDebugEnabled()) {
      log.error(e.getLocalizedMessage(), e);
    }
    log.error(e.getLocalizedMessage(), e);
    return "重复数据";
  }

  /**
   * 默认异常处理
   *
   * @param e 异常对象
   * @return 提示字符串
   */
  @ExceptionHandler(Exception.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public String exceptionHandler(Exception e) {
    log.error(e.getLocalizedMessage(), e);
    return "服务器开小差啦，请稍后再试";
  }


  /**
   * 默认异常处理
   *
   * @param e 异常对象
   * @return 提示字符串
   */
  @ExceptionHandler(ThirdPartyCallException.class)
  @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
  public Object thirdPartyExceptionHandler(ThirdPartyCallException e) {
      log.error(e.getLocalizedMessage(), e);
      return e.getRawResp();
  }
}
