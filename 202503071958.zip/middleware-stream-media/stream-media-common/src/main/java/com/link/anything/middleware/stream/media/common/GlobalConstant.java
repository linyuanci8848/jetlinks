package com.link.anything.middleware.stream.media.common;

import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author YcYa_xbj 这个系统需要用到的常量
 */
public class GlobalConstant {


  /**
   * 默认日期时间格式
   */
  public static final String DEFAULT_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
  /**
   * 默认日期格式
   */
  public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";
  public static final DateTimeFormatter DEFAULT_DATE_FORMATTER = DateTimeFormatter.ofPattern(DEFAULT_DATE_FORMAT);
  public static final DateTimeFormatter DEFAULT_DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern(DEFAULT_DATE_TIME_FORMAT);
  /**
   * 年月格式
   */
  public static final String YEAR_MONTH_FORMAT = "yyyy-MM";
  /**
   * 月日格式
   */
  public static final String MONTH_DAY_FORMAT = "MM-dd";
  /**
   * 默认时间格式
   */
  public static final String DEFAULT_TIME_FORMAT = "HH:mm:ss";
  /**
   *
   */
  public static final String DATE_TIME_FORMAT = "yyyyMMddHHmmss";

}
