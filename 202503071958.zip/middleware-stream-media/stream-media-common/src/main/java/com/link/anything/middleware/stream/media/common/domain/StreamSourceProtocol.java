package com.link.anything.middleware.stream.media.common.domain;

import lombok.Getter;

/**
 * 流传输协议
 */
@Getter
public enum StreamSourceProtocol {

  GB28181(0),
  JTT1078(1),
  HKV(2);

  StreamSourceProtocol(int code) {
    this.code = code;
  }

  private final int code;
}
