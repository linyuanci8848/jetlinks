package com.link.anything.middleware.stream.media.common.domain;

/**
 * 流session 的状态
 */
public enum StreamSessionApp {

  /**
   * 直播流
   */
  live,
  /**
   * 点播
   */
  record;


}
