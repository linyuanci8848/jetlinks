package com.link.anything.middleware.stream.media.common.domain;

public enum HistoryVideoSource {
  Device,Center;
}
