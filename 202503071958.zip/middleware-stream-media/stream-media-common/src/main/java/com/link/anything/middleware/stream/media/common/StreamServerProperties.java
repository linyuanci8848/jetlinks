package com.link.anything.middleware.stream.media.common;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * 流相关的配置
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "middleware.stream", ignoreInvalidFields = true)
public class StreamServerProperties {

  /**
   * 服务器实例ID
   */
  private String id;

  /**
   * 流创建超时(单位毫秒)
   */
  private Integer createStreamTimeout = 10000;
  /**
   * 当前控制服务器IP(必须ZLMediaKit 可达)
   */
  private String currentControlHost;


  /**
   * 服务端口
   */
  private Integer httpPort;
  /**
   * 加密秘钥
   */
  private String secret;

  /**
   * 录像存储路径
   */
  private String recordPath;
  /**
   * SIP监听端口
   */
  private Integer sipPort;


}
