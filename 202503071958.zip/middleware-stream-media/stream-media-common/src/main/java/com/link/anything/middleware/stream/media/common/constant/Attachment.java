package com.link.anything.middleware.stream.media.common.constant;

import com.link.anything.common.constant.MediaType;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.HashMap;
import java.util.Map;
import lombok.Data;

/**
 * 附件信息.
 */
@Data
@Schema(title = "附件")
public class Attachment {
  @Schema(title = "附件名称")
  private String name;
  @Schema(title = "访问路径")
  private String url;
  @Schema(title = "附件类型")
  private MediaType media;
  @Schema(title = "扩展信息")
  private Map<String, Object> ext = new HashMap<>();
  @Schema(title = "文件大小", description = "视频和音频就是时长(秒)，其他就是文件大小(kb)")
  private Integer size;
}
