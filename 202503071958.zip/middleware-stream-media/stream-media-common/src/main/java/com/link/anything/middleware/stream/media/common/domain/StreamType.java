package com.link.anything.middleware.stream.media.common.domain;

import lombok.Getter;

/**
 * 流类型
 */
@Getter
public enum StreamType {
  //视频流
  Video(0),
  //音频流
  Audio(1),
  //音频和视频
  VideoAndAudio(2),
  //双向对讲
  TwoWayIntercom(3),
  //监听
  Monitor(4),
  //中心广播
  CentralBroadcasting(5),
  //数据透传
  Transparent(6);

  private final Integer code;

  StreamType(Integer code) {
    this.code = code;
  }
}
