package com.link.anything.middleware.stream.media.common.domain;

import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import java.util.Objects;
import lombok.Data;
import lombok.Getter;

@Getter
@Schema(description = "流信息")
public class StreamInfo implements Serializable {


  @Schema(description = "HTTP-FLV流地址")
  private String flv;

  @Schema(description = "HTTPS-FLV流地址")
  private String https_flv;
  @Schema(description = "Websocket-FLV流地址")
  private String ws_flv;
  @Schema(description = "Websockets-FLV流地址")
  private String wss_flv;
  @Schema(description = "HTTP-FMP4流地址")
  private String fmp4;
  @Schema(description = "HTTPS-FMP4流地址")
  private String https_fmp4;
  @Schema(description = "Websocket-FMP4流地址")
  private String ws_fmp4;
  @Schema(description = "Websockets-FMP4流地址")
  private String wss_fmp4;
  @Schema(description = "HLS流地址")
  private String hls;
  @Schema(description = "HTTPS-HLS流地址")
  private String https_hls;
  @Schema(description = "Websocket-HLS流地址")
  private String ws_hls;
  @Schema(description = "Websockets-HLS流地址")
  private String wss_hls;
  @Schema(description = "HTTP-TS流地址")
  private String ts;
  @Schema(description = "HTTPS-TS流地址")
  private String https_ts;
  @Schema(description = "Websocket-TS流地址")
  private String ws_ts;
  @Schema(description = "Websockets-TS流地址")
  private String wss_ts;
  @Schema(description = "RTMP流地址")
  private String rtmp;
  @Schema(description = "RTMPS流地址")
  private String rtmps;
  @Schema(description = "RTSP流地址")
  private String rtsp;
  @Schema(description = "RTSPS流地址")
  private String rtsps;
  @Schema(description = "RTC流地址")
  private String rtc;

  @Schema(description = "RTCS流地址")
  private String rtcs;
  @Schema(description = "流ID")
  private String streamId;
  public void setStreamId(String streamId) {
    this.streamId = streamId;
  }

  public void setRtmp(String host, int port, int sslPort, String app, String stream, String callIdParam) {
    String file = String.format("%s/%s%s", app, stream, callIdParam);
    if (port > 0) {
      this.rtmp = String.format("rtmp://%s:%s/%s", host, port, file);
    }
    if (sslPort > 0) {
      this.rtmps = String.format("rtmps://%s:%s/%s", host, port, file);
    }
  }

  public void setRtsp(String host, int port, int sslPort, String app, String stream, String callIdParam) {
    String file = String.format("%s/%s%s", app, stream, callIdParam);
    if (port > 0) {
      this.rtsp = String.format("rtsp://%s:%s/%s", host, port, file);
    }
    if (sslPort > 0) {
      this.rtsps = String.format("rtsps://%s:%s/%s", host, port, file);
    }
  }

  public void setFlv(String host, int port, int sslPort, String app, String stream, String callIdParam) {
    String file = String.format("%s/%s.live.flv%s", app, stream, callIdParam);
    if (port > 0) {
      this.flv = String.format("http://%s:%s/%s", host, port, file);
      this.ws_flv = String.format("ws://%s:%s/%s", host, port, file);
    } else {
      this.flv = String.format("http://%s/%s", host, file);
      this.ws_flv = String.format("ws://%s/%s", host, file);
    }

    if (sslPort > 0) {
      this.https_flv = String.format("https://%s:%s/%s", host, port, file);
      this.wss_flv = String.format("wss://%s:%s/%s", host, port, file);
    } else {
      this.https_flv = String.format("https://%s/%s", host, file);
      this.wss_flv = String.format("wss://%s/%s", host, file);
    }
  }

  public void setFmp4(String host, int port, int sslPort, String app, String stream, String callIdParam) {
    String file = String.format("%s/%s.live.mp4%s", app, stream, callIdParam);
    if (port > 0) {
      this.fmp4 = String.format("http://%s:%s/%s", host, port, file);
      this.ws_fmp4 = String.format("ws://%s:%s/%s", host, port, file);
    }
    if (sslPort > 0) {
      this.https_fmp4 = String.format("https://%s:%s/%s", host, port, file);
      this.wss_fmp4 = String.format("wss://%s:%s/%s", host, port, file);
    }
  }

  public void setHls(String host, int port, int sslPort, String app, String stream, String callIdParam) {
    String file = String.format("%s/%s/hls.m3u8%s", app, stream, callIdParam);
    if (port > 0) {
      this.hls = String.format("http://%s:%s/%s", host, port, file);
      this.ws_hls = String.format("ws://%s:%s/%s", host, port, file);
    }
    if (sslPort > 0) {
      this.https_hls = String.format("https://%s:%s/%s", host, port, file);
      this.wss_hls = String.format("wss://%s:%s/%s", host, port, file);
    }
  }

  public void setTs(String host, int port, int sslPort, String app, String stream, String callIdParam) {
    String file = String.format("%s/%s.live.ts%s", app, stream, callIdParam);

    if (port > 0) {
      this.ts = String.format("http://%s:%s/%s", host, port, file);
      this.ws_ts = String.format("ws://%s:%s/%s", host, port, file);
    }
    if (sslPort > 0) {
      this.https_ts = String.format("https://%s:%s/%s", host, port, file);
      this.wss_ts = String.format("wss://%s:%s/%s", host, port, file);
    }
  }

  public void setRtc(String host, int port, int sslPort, String app, String stream, String callIdParam) {
    if (callIdParam != null) {
      callIdParam = Objects.equals(callIdParam, "") ? callIdParam : callIdParam.replace("?", "&");
    }
    String file = String.format("index/api/webrtc?app=%s&stream=%s&type=play%s", app, stream, callIdParam);
    if (port > 0) {
      this.rtc = String.format("http://%s:%s/%s", host, port, file);
    }
    if (sslPort > 0) {
      this.rtcs = String.format("https://%s:%s/%s", host, port, file);
    }
  }


}
