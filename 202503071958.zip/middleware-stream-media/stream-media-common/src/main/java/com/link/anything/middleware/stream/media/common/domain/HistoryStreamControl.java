package com.link.anything.middleware.stream.media.common.domain;

public enum HistoryStreamControl {
  /**
   * 正常播放
   */
  Play(0),
  /**
   * 暂停
   */
  Suspend(1),
  /**
   * 结束播放
   */
  Close(2),

  /**
   * 快进
   */
  FastForward(3),

  /**
   * 关键帧快退播放
   */
  KeyframeRewindPlayback(4),
  /**
   * 拖动
   */
  Drag(5),
  /**
   * 单帧播放
   */
  SingleFramePlay(6);

  private int code;

  HistoryStreamControl(int code) {
    this.code = code;
  }
}
