package com.link.anything.middleware.stream.media.common;


import lombok.Data;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PreDestroy;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;

/**
 * 订阅管理器
 */
@Slf4j
@Component
public class SubscribeManager {

    private final ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(
        Runtime.getRuntime().availableProcessors() * 4,
        new ThreadPoolExecutor.CallerRunsPolicy()
    );

    private final Map<String, ConcurrentHashMap<Long, EventCallbackEntity>> eventMap = new ConcurrentHashMap<>();

    private final static Lock lock = new ReentrantLock();

    /**
     * 添加临时性质订阅
     */
    public Long subscribe(
        String event,
        Integer aliveMilliseconds,
        Consumer<Object> consumer,
        Consumer<Object> perishCallback,
        boolean isSnapchat
    ) {
        eventMap.putIfAbsent(event, new ConcurrentHashMap<>());
        ConcurrentHashMap<Long, EventCallbackEntity> consumers = eventMap.get(event);

        EventCallbackEntity entity = new EventCallbackEntity();
        entity.setCallback(consumer)
            .setAliveMilliseconds(aliveMilliseconds)
            .setSnapchat(isSnapchat);

        try {
            lock.lock();
            consumers.put(entity.id, entity);

            if (aliveMilliseconds != null) {
                entity.setPerishCallback(perishCallback);
                executor.schedule(
                    () -> {
                        if (consumers.containsKey(entity.id)) {
                            consumers.remove(entity.id);
                            if (entity.perishCallback != null) {
                                entity.perishCallback.accept(entity.id);
                            }
                        }
                    },
                    aliveMilliseconds,
                    TimeUnit.MILLISECONDS
                );
            }
        } finally {
            lock.unlock();
        }

        return entity.id;
    }

    /**
     * 添加临时性质订阅
     */
    public void subscribe(
        String event,
        Integer aliveMilliseconds,
        Consumer<Object> consumer,
        Consumer<Object> perishCallback
    ) {
        subscribe(event, aliveMilliseconds, consumer, perishCallback, true);
    }

    /**
     * 添加临时性订阅，无超时回调
     */
    public void subscribe(String event, Integer aliveMilliseconds, Consumer<Object> consumer) {
        subscribe(event, aliveMilliseconds, consumer, null, true);
    }

    /**
     * 永久订阅
     */
    public Long subscribe(String event, Consumer<Object> consumer) {
        return subscribe(event, null, consumer, null, false);
    }

    /**
     * 解除订阅
     */
    public void unSubscribe(String event, Long id) {
        try {
            lock.lock();
            eventMap.get(event).remove(id);
        } finally {
            lock.unlock();
        }
    }

    /**
     * 发布事件
     */
    public void publish(String eventKey, Object data) {
        eventMap.putIfAbsent(eventKey, new ConcurrentHashMap<>());

        try {
            lock.lock();
            ConcurrentHashMap<Long, EventCallbackEntity> consumers = eventMap.get(eventKey);
            Iterator<EventCallbackEntity> iterator = consumers.values().iterator();
            while (iterator.hasNext()) {
                EventCallbackEntity value = iterator.next();
                executor.submit(() -> {
                    try {
                        value.callback.accept(data);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                });
                if (value.snapchat) {
                    iterator.remove();
                }
            }
            eventMap.put(eventKey, consumers);
        } finally {
            lock.unlock();
        }
    }

    @PreDestroy
    public void destroy() {
        executor.shutdown();
    }

    @Data
    @Accessors(chain = true)
    private static class EventCallbackEntity {

        private static AtomicLong idGenerator = new AtomicLong(0);

        private Long id = idGenerator.getAndIncrement();
        /**
         * 阅后就烧
         */
        private boolean snapchat;
        /**
         * 超时时间毫秒
         */
        private Integer aliveMilliseconds;

        private Consumer<Object> callback;

        private Consumer<Object> perishCallback;
    }
}
