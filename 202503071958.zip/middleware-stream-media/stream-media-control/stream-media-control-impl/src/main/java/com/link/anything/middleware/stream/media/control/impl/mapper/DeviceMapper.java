package com.link.anything.middleware.stream.media.control.impl.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.link.anything.middleware.stream.media.control.domain.Device;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DeviceMapper extends BaseMapper<Device> {

}
