package com.link.anything.middleware.stream.media.control.impl.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface VideoFragmentMapper extends BaseMapper<VideoFragment> {

}
