package com.link.anything.middleware.stream.media.control.impl;


import com.link.anything.middleware.stream.media.common.domain.StreamInfo;
import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.common.domain.StreamSessionApp;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;

public class StreamUtils {

  /**
   * 装载Stream信息
   *
   * @param mediaInfo
   * @param session
   * @param stream
   * @param token
   * @return
   */
  public static StreamInfo assembleStreamInfo(MediaServerInstance mediaInfo, StreamSession session, String stream, String token) {
    StreamInfo streamInfoResult = new StreamInfo();
    String addr = mediaInfo.getStreamIp();
    String callIdParam = "?token=" + token;
    String app = session.getApp().toString();
    streamInfoResult.setStreamId(session.getStreamId());
    if (session.getStreamSourceProtocol().equals(StreamSourceProtocol.JTT1078) || session.getStreamSourceProtocol().equals(StreamSourceProtocol.GB28181)) {
      app = "rtp";
    }
    //ZL 的 GB28181 的流ID 是16进制的所以这里要转换  GB28181 直播是用的单端口
    if (session.getStreamSourceProtocol().equals(StreamSourceProtocol.GB28181) && session.getApp().equals(StreamSessionApp.live)) {
      //SSRC 是4个字节
      StringBuilder streamBuilder = new StringBuilder(Integer.toHexString(Integer.parseInt(stream)).toUpperCase());
      for (int i = 0; i < 8 - streamBuilder.length(); i++) {
        streamBuilder.insert(0, "0");
      }
      stream = streamBuilder.toString();
      streamInfoResult.setStreamId(session.getStreamId());
    }
    streamInfoResult.setRtmp(addr, mediaInfo.getRtmpPort(), mediaInfo.getRtmpSslPort(), app, stream, callIdParam);
    streamInfoResult.setRtsp(addr, mediaInfo.getRtspPort(), mediaInfo.getRtspSsLPort(), app, stream, callIdParam);
    streamInfoResult.setFlv(addr, mediaInfo.getHttpPort(), mediaInfo.getHttpSslPort(), app, stream, callIdParam);
    streamInfoResult.setFmp4(addr, mediaInfo.getHttpPort(), mediaInfo.getHttpSslPort(), app, stream, callIdParam);
    streamInfoResult.setHls(addr, mediaInfo.getHttpPort(), mediaInfo.getHttpSslPort(), app, stream, callIdParam);
    streamInfoResult.setTs(addr, mediaInfo.getHttpPort(), mediaInfo.getHttpSslPort(), app, stream, callIdParam);
    streamInfoResult.setRtc(addr, mediaInfo.getHttpPort(), mediaInfo.getHttpSslPort(), app, stream, callIdParam);
    return streamInfoResult;
  }


}
