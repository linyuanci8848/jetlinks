package com.link.anything.middleware.stream.media.control.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.link.anything.middleware.stream.media.control.IVideoFragmentManager;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.control.impl.mapper.VideoFragmentMapper;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Component
public class VideoFragmentManagerImpl extends ServiceImpl<VideoFragmentMapper, VideoFragment> implements IVideoFragmentManager {

  @Resource
  private VideoFragmentMapper historyVideoFragmentMapper;

  @Transactional(rollbackFor = Exception.class)
  @Override
  public List<VideoFragment> submitHistoryVideoFragment(List<VideoFragment> videoFragmentList) {
    if (CollectionUtils.isEmpty(videoFragmentList)) {
      return Collections.emptyList();
    }
    Set<String> keys = new HashSet<>();
    videoFragmentList = videoFragmentList.stream().map(item -> {
      item.setKey(item.getDevice() + "_" + item.getChannel() + "_" + item.getStart().toEpochSecond(ZoneOffset.ofHours(8)) + "_" + item.getEnd().toEpochSecond(ZoneOffset.ofHours(8)));
      keys.add(item.getKey());
      return item;
    }).sorted(Comparator.comparing(VideoFragment::getStart)).collect(Collectors.toList());
    this.historyVideoFragmentMapper.delete(new LambdaQueryWrapper<VideoFragment>().in(VideoFragment::getKey, keys));
    this.saveBatch(videoFragmentList);
    return videoFragmentList;
  }

  @Override
  public VideoFragment findHistoryVideoFragment(String key) {
    return historyVideoFragmentMapper.selectOne(new LambdaQueryWrapper<VideoFragment>().eq(VideoFragment::getKey, key));
  }
}
