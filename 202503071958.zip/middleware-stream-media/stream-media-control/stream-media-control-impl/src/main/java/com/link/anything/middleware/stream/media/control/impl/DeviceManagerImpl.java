package com.link.anything.middleware.stream.media.control.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.link.anything.middleware.stream.media.common.GlobalConstant;
import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.GlobalDefinitionRedisKey;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.DeviceChannel;
import com.link.anything.middleware.stream.media.control.impl.mapper.DeviceChannelMapper;
import com.link.anything.middleware.stream.media.control.impl.mapper.DeviceMapper;

import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.AbstractMap.SimpleEntry;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.SipException;

import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Slf4j
@Component
public class DeviceManagerImpl implements IDeviceManager {


    @Resource
    private IStreamSessionManager streamSessionManager;

    @Resource
    private SubscribeManager subscribeManager;

    @Resource
    private DeviceMapper deviceMapper;
    @Resource
    private DeviceChannelMapper deviceChannelMapper;
    /**
     * 缓存设备连接状态.
     * <P>系统重新启动需要终端重新上报状态</P>
     * <p>终端断掉就把设备离线</p>
     * <p>1078转发程序断开会将相关设备全部断线，连上后会同步设备状态</p>
     */
    private final Set<String> onlineDevice = Collections.synchronizedSet(new HashSet<>());

    @Override
    public Map<String, Boolean> findDeviceStatus() {
        List<Device> devices = deviceMapper.selectList(new LambdaQueryWrapper<Device>());
        return devices.stream().collect(Collectors.toMap(Device::getTerminalNumber,device ->  onlineDevice.contains(device.getTerminalNumber())));
    }

    @Override
    public List<DeviceChannel> findDeviceChannel() {
        return deviceChannelMapper.selectList(new LambdaQueryWrapper<DeviceChannel>());
    }

    @Override
    public List<Device> findDeviceByProtocol(StreamSourceProtocol protocol) {
        return deviceMapper.selectList(new LambdaQueryWrapper<Device>().eq(Device::getProtocol, protocol));
    }

    @Override
    public void online(Device device) {
        LocalDateTime now = LocalDateTime.now();
        log.debug("设备{}上线", device.getTerminalNumber());
        Device cacheDevice = deviceMapper.selectOne(new LambdaQueryWrapper<Device>().eq(Device::getTerminalNumber, device.getTerminalNumber()));
        if (cacheDevice != null) {
            device.setKeepaliveTime(now);
            device.setUpdateAt(LocalDateTime.now());
            device.setKeepaliveTime(now);
            device.setId(cacheDevice.getId());
            deviceMapper.updateById(device);
        } else {
            device.setUpdateAt(now);
            device.setKeepaliveTime(now);
            if (device.getKeepaliveIntervalTime() == 0) {
                // 默认心跳间隔60
                device.setKeepaliveIntervalTime(60);
            }
            deviceMapper.insert(device);
        }
        if (!onlineDevice.contains(device.getTerminalNumber())) {
            Map<String, Boolean> deviceState = new HashMap<>();
            deviceState.put(device.getTerminalNumber(), true);
            subscribeManager.publish(StreamDefinitionEventKey.DeviceStateChange.name(), deviceState);
        }
        onlineDevice.add(device.getTerminalNumber());
    }


    @Override
    public void offline(String number) {
        log.debug("设备{}离线", number);
        streamSessionManager.removeSessionByDevice(number);
        if (onlineDevice.remove(number)){
            Map<String, Boolean> deviceState = new HashMap<>();
            deviceState.put(number, false);
            subscribeManager.publish(StreamDefinitionEventKey.DeviceStateChange.name(), deviceState);
        }
    }


    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateDeviceChanel(List<DeviceChannel> channels) {
        Map<String, List<DeviceChannel>> channelMap = channels.stream().collect(Collectors.groupingBy(DeviceChannel::getTerminalNumber));
        for (Entry<String, List<DeviceChannel>> entry : channelMap.entrySet()) {
            deviceChannelMapper.delete(new LambdaUpdateWrapper<DeviceChannel>().eq(DeviceChannel::getTerminalNumber, entry.getKey())
                    .in(DeviceChannel::getTerminalChannelNumber, entry.getValue().stream().map(DeviceChannel::getTerminalChannelNumber).collect(Collectors.toSet())));
            for (DeviceChannel channel : entry.getValue()) {
                deviceChannelMapper.insert(channel);
            }
        }
    }


    @Override
    public void deleteDeviceChannel(String device, List<String> channels) {

        deviceChannelMapper.delete(
                new LambdaQueryWrapper<DeviceChannel>().eq(DeviceChannel::getTerminalNumber, device).in(DeviceChannel::getTerminalChannelNumber, channels));
    }

    @Override
    public void deleteDeviceChannelByDevice(String device) {
        deviceChannelMapper.delete(new LambdaUpdateWrapper<DeviceChannel>().eq(DeviceChannel::getTerminalNumber, device));
    }


    @Override
    public Device findDevice(String number) {
        return deviceMapper.selectOne(new LambdaQueryWrapper<Device>().eq(Device::getTerminalNumber, number));
    }


    @Override
    public void updateDevice(Device device) {
        deviceMapper.updateById(device);
    }


    @Override
    public boolean isOnline(String device) {
        return onlineDevice.contains(device);
    }
}
