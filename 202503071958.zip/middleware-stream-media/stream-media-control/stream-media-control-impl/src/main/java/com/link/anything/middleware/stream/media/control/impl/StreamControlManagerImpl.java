package com.link.anything.middleware.stream.media.control.impl;


import com.link.anything.common.security.AESUtil;
import com.link.anything.middleware.stream.media.common.StreamServerProperties;
import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.GlobalDefinitionRedisKey;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.PTZStreamControl;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.IVideoFragmentManager;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.StreamInfo;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamPlayType;
import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.common.domain.StreamSessionApp;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import com.link.anything.middleware.stream.media.control.IStreamControlManager;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.protocol.IProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.ProtocolExecutorProvider;
import com.link.anything.middleware.stream.media.protocol.TalkStreamContainer;
import com.link.anything.middleware.stream.media.server.IMediaServerManager;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import com.link.anything.middleware.stream.media.server.request.OnPublishHookRequest;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

@Slf4j
@Component
public class StreamControlManagerImpl implements IStreamControlManager {


    private final IStreamSessionManager streamSessionManager;


    private final IMediaServerManager mediaServerManager;


    private final SubscribeManager subscribeManager;

    private final RedissonClient redissonClient;

    private final StreamServerProperties streamServerProperties;


    private final ProtocolExecutorProvider protocolExecutorProvider;
    private final IVideoFragmentManager historyVideoFragmentManager;

    private final TalkStreamContainer talkStreamContainer;
    private final IDeviceManager deviceManager;

    public StreamControlManagerImpl(
        IStreamSessionManager streamSessionManager,
        IMediaServerManager mediaServerManager,
        SubscribeManager subscribeManager,
        RedissonClient redissonClient,
        StreamServerProperties streamServerProperties,
        ProtocolExecutorProvider protocolExecutorProvider,
        IVideoFragmentManager historyVideoFragmentManager,
        TalkStreamContainer talkStreamContainer,
        IDeviceManager deviceManager
    ) {
        this.streamSessionManager = streamSessionManager;
        this.mediaServerManager = mediaServerManager;
        this.subscribeManager = subscribeManager;
        this.redissonClient = redissonClient;
        this.streamServerProperties = streamServerProperties;
        this.protocolExecutorProvider = protocolExecutorProvider;
        this.historyVideoFragmentManager = historyVideoFragmentManager;
        this.talkStreamContainer = talkStreamContainer;
        this.deviceManager = deviceManager;
    }

    @Override
    public StreamInfo createLiveStream(
        String deviceNumber,
        String channel,
        Integer bitStream,
        StreamSourceProtocol streamSourceProtocol,
        StreamTransferMethod streamTransferMethod
    ) {
        List<StreamSession> streamSessions = streamSessionManager.findSession(deviceNumber, channel);
        StreamSession streamSession = null;
        if (!CollectionUtils.isEmpty(streamSessions)) {
            Optional<StreamSession> sessionOptional = streamSessions.stream().filter(item -> item.getApp().equals(StreamSessionApp.live)).findFirst();
            if (sessionOptional.isPresent()) {
                streamSession = sessionOptional.get();
            }
        }
        try {
            if (streamSession != null) {
                MediaServerInstance instance = mediaServerManager.findMediaServerInstance(streamSession.getMediaServerId());
                String token = streamSession.addToken();
                return StreamUtils.assembleStreamInfo(instance, streamSession, streamSession.getStreamId(), token);
            }
            IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(streamSourceProtocol);
            Assert.notNull(protocolExecutor, streamSourceProtocol.name() + "协议无支持");
            MediaServerInstance instance = mediaServerManager.getMediaServerForMinimumLoad(false);
            Assert.notNull(instance, "无可分配流媒体服务器");
            streamSession = protocolExecutor.openLive(deviceNumber, channel, bitStream, streamSourceProtocol, streamTransferMethod, instance);
            StreamInfo streamInfo = StreamUtils.assembleStreamInfo(instance, streamSession, streamSession.getStreamId(), streamSession.addToken());
            String streamId = streamSession.getStreamId();
            subscribeManager.subscribe(
                StreamDefinitionEventKey.StreamPush + streamSession.getStreamId(),
                streamServerProperties.getCreateStreamTimeout(),
                o -> {
                    OnPublishHookRequest request = (OnPublishHookRequest) o;
                    log.info("流媒体服务器已接收到流源{}数据", request.getStream());
                    streamSessionManager.readyStream(streamId);
                },
                (Consumer<Object>) o -> {
                    log.info("流源{}无响应，删除当前会话", streamId);
                    this.controlLiveStream(streamId, LiveStreamControl.CloseAudioAndVideo, bitStream);
                }
            );
            return streamInfo;
        } catch (IllegalArgumentException e) {
            if (streamSession != null) {
                log.error("直播流创建失败," + streamSession, e);
                streamSessionManager.removeSession(streamSession.getStreamId());
            }
            throw new IllegalArgumentException(e.getMessage());
        }
    }

    @Override
    public void controlLiveStream(String stream, LiveStreamControl control, Integer bitStream) {
        StreamSession streamSession = streamSessionManager.getSession(stream);
        Assert.notNull(streamSession, "流不存在");
        IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(streamSession.getStreamSourceProtocol());
        Assert.notNull(protocolExecutor, streamSession.getStreamSourceProtocol().name() + "协议无支持");
        protocolExecutor.controlLiveStream(streamSession, control);
    }

    @Override
    public void findVideoHistory(
        String deviceNumber,
        String channel,
        StreamSourceProtocol sourceType,
        LocalDateTime start,
        LocalDateTime end,
        StreamType type,
        Integer bitStream,
        HistoryVideoSource source,
        Consumer<List<VideoFragment>> consumer,
        Consumer<Object> timeout
    ) {
        IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(sourceType);
        Assert.notNull(protocolExecutor, sourceType + "协议无支持");
        RAtomicLong rAtomicLong = redissonClient.getAtomicLong(GlobalDefinitionRedisKey.JTT1078_HISTORY_SN_KEY + deviceNumber);
        long sq = rAtomicLong.addAndGet(1);
        if (sq >= 65534) {
            sq = 0L;
            rAtomicLong.set(0);
        }
        List<VideoFragment> proxyFragments = protocolExecutor.findVideoHistory(deviceNumber, channel, sourceType, start, end, type, bitStream, source, sq);
        if (proxyFragments == null) {
            subscribeManager.subscribe(
                    StreamDefinitionEventKey.HistoryVideoFindCallback + deviceNumber + "_" + sq,
                    streamServerProperties.getCreateStreamTimeout(),
                    fragments -> {
                        List<VideoFragment> data = (List<VideoFragment>) fragments;
                        consumer.accept(historyVideoFragmentManager.submitHistoryVideoFragment(data));
                    },
                    timeout
            );
        } else {
            // 海康是直接查询得到片段
            consumer.accept(historyVideoFragmentManager.submitHistoryVideoFragment(proxyFragments));
        }
    }

    @Override
    public StreamInfo createAppointStream(
        String key,
        StreamTransferMethod method,
        HistoryStreamPlayType playType,
        Integer multiple
    ) {
        VideoFragment videoFragment = historyVideoFragmentManager.findHistoryVideoFragment(key);
        Assert.notNull(videoFragment, "录像文件不存在");
        String streamId = videoFragment.getDevice() + "_" + videoFragment.getChannel() + "_" + videoFragment.getStart()
            .toEpochSecond(ZoneOffset.ofHours(8)) + "_" + videoFragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8));
        StreamSession streamSession = streamSessionManager.getSession(streamId);
        Assert.isNull(streamSession, "当前录像正在被观看，请稍后再试。");
        try {
            IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(videoFragment.getSourceProtocol());
            Assert.notNull(protocolExecutor, videoFragment.getSourceProtocol().name() + "协议无支持");
            MediaServerInstance instance = mediaServerManager.getMediaServerForMinimumLoad(false);
            Assert.notNull(instance, "无可分配流媒体服务器");
            //设备同一个录像文件只能被一个人观看 其实设备推送这个类似直播流不过可以控制
            streamSession = protocolExecutor.openHistoryStream(videoFragment, instance, method, playType, multiple);
            StreamInfo streamInfo = StreamUtils.assembleStreamInfo(instance, streamSession, streamId, streamSession.addToken());
            subscribeManager.subscribe(
                StreamDefinitionEventKey.StreamPush + streamSession.getStreamId(),
                streamServerProperties.getCreateStreamTimeout(),
                o -> {
                    OnPublishHookRequest request = (OnPublishHookRequest) o;
                    log.debug("流媒体服务器已接收到流源{}数据", request.getStream());
                    streamSessionManager.readyStream(streamId);
                },
                o -> {
                    log.debug("流源{}无响应，删除当前会话", streamId);
                    this.controlAppointStream(key, HistoryStreamControl.Close, 0, null);
                }
            );
            return streamInfo;
        } catch (Exception e) {
            log.error(key + "录像文件播放异常", e);
            if (streamSession != null) {
                streamSessionManager.removeSession(streamId);
            }
            throw new IllegalArgumentException("点播异常");
        }
    }

    @Override
    public void controlAppointStream(String key, HistoryStreamControl control, Integer multiple, Long point) {
        VideoFragment videoFragment = historyVideoFragmentManager.findHistoryVideoFragment(key);
        String lockKey = videoFragment.getDevice() + "_" + videoFragment.getChannel() + "_" + videoFragment.getStart()
            .toEpochSecond(ZoneOffset.ofHours(8)) + "_" + videoFragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8));
        StreamSession streamSession = streamSessionManager.getSession(lockKey);
        IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(videoFragment.getSourceProtocol());
        Assert.notNull(protocolExecutor, videoFragment.getSourceProtocol().name() + "协议无支持");
        protocolExecutor.controlHistoryStream(streamSession, control, multiple, point);
    }

    @Override
    public String createTalkLink(
        String device,
        StreamSourceProtocol sourceProtocol,
        String audioChannel,
        StreamTransferMethod method
    ) {
        Assert.isTrue(deviceManager.isOnline(device), "当前设备可能存在信号不佳或已熄火的情况，请稍后重试。");
        RLock lock = redissonClient.getLock(GlobalDefinitionRedisKey.LOCK_KEY_AUDIO_STREAM + "_" + device + "_" + audioChannel);
        try {
            Assert.isTrue(lock.tryLock(), "当前对讲通道被占用，请稍后再试");
            subscribeManager.subscribe(
                StreamDefinitionEventKey.TalkStreamLinkUserTerminalJoin + device + "_" + audioChannel,
                20000,
                o -> {
                    IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(sourceProtocol);
                    Assert.notNull(protocolExecutor, sourceProtocol.name() + "协议无支持");
                    protocolExecutor.createTalkStream(device, audioChannel);
                    subscribeManager.subscribe(
                        StreamDefinitionEventKey.TalkStreamRegister + device + "_" + audioChannel,
                        streamServerProperties.getCreateStreamTimeout(),
                        o1 -> {
                        },
                        o12 -> {
                            log.info("语音对讲链路关闭，等待设备超时");
                            talkStreamContainer.kick(device, audioChannel);
                        }
                    );
                },
                o -> {
                    talkStreamContainer.removeMarkUserTerminal(device, audioChannel);
                    talkStreamContainer.kick(device, audioChannel);
                }
            );
            String token = device + "_" + audioChannel;
            talkStreamContainer.markUserTerminal(device, audioChannel);
            return new String(AESUtil.encrypt(token.getBytes(StandardCharsets.UTF_8), streamServerProperties.getSecret() + "_" + LocalDateTime.now().getMinute()));
        } catch (Exception e) {
            log.error(device + "_" + audioChannel + "点播异常", e);
            throw new IllegalArgumentException(e.getMessage());
        } finally {
            if (lock != null && lock.isLocked()) {
                lock.unlock();
            }
        }
    }

    @Override
    public void controlPTZStream(
        String stream,
        PTZStreamControl control,
        Integer horizonSpeed,
        Integer zoomSpeed,
        Integer verticalSpeed
    ) {
        StreamSession streamSession = streamSessionManager.getSession(stream);
        Assert.notNull(streamSession, "流不存在");
        IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(streamSession.getStreamSourceProtocol());
        Assert.notNull(protocolExecutor, streamSession.getStreamSourceProtocol().name() + "协议无支持");
        protocolExecutor.controlPTZStream(streamSession, control, horizonSpeed, zoomSpeed, verticalSpeed);
    }


    @Override
    public void screenshot(String streamKey) {

    }


}
