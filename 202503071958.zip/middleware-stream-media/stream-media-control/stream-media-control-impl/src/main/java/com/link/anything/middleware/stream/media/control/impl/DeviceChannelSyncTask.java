package com.link.anything.middleware.stream.media.control.impl;

import com.link.anything.middleware.stream.media.protocol.IProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.ProtocolExecutorProvider;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Resource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 设备通道同步任务
 */
@Component
public class DeviceChannelSyncTask {

  @Resource
  private ProtocolExecutorProvider protocolExecutorProvider;

  @Scheduled(initialDelay = 5, fixedDelay = 300, timeUnit = TimeUnit.SECONDS)
  public void sync() {
    List<IProtocolExecutor> protocolExecutors = protocolExecutorProvider.getAll();
    for (IProtocolExecutor protocolExecutor : protocolExecutors) {
      protocolExecutor.syncDeviceChannel();
    }
  }
}
