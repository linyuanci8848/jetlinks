package com.link.anything.middleware.stream.media.control.impl;

import com.link.anything.middleware.stream.media.control.IDeviceAlarmManager;
import com.link.anything.middleware.stream.media.control.domain.Alarm;
import org.springframework.stereotype.Component;

@Component
public class DeviceAlarmManagerImpl implements IDeviceAlarmManager {


  @Override
  public Long submitAlarm(Alarm alarm) {
    return -1L;
  }
}
