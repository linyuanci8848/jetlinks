package com.link.anything.middleware.stream.media.control.impl;

import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.common.domain.StreamSessionApp;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.IStreamControlManager;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.server.IMediaServerManager;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import com.link.anything.middleware.stream.media.server.response.MediaStreamResponse;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * 本地 session 和流媒体服务器的信息同步
 * <p>流媒体服务器那边推流器断开后不会执行回调 session 会一直存在 就不能从新给设备发指令 所以这这里要和流媒体服务器进行核对</p>
 */
@Slf4j
@Component
public class MediaSyncTask {

  @Resource
  private IStreamSessionManager streamSessionManager;

  @Resource
  private IMediaServerManager mediaServerManager;

  @Resource
  private IStreamControlManager streamControlManager;

  @Value("${middleware.stream.seconds-waiting-for-incoming-stream:3}")
  private long secondsWaitingForIncomingStream;

  @Scheduled(initialDelay = 3, fixedDelay = 1, timeUnit = TimeUnit.SECONDS)
  public void reconciliation() {
    try {
      List<StreamSession> streamSessionList = streamSessionManager.getAllReadyStreamSession();
      if (CollectionUtils.isEmpty(streamSessionList)) {
        return;
      }
      for (StreamSession streamSession : streamSessionList) {
        MediaServerInstance mediaServerInstance = mediaServerManager.findMediaServerInstance(streamSession.getMediaServerId());
        String streamId = streamSession.getStreamId();
        if (streamSession.getStreamSourceProtocol().equals(StreamSourceProtocol.GB28181) && streamSession.getApp().equals(StreamSessionApp.live)) {
          StringBuilder streamBuilder = new StringBuilder(Integer.toHexString(Integer.parseInt(streamId)).toUpperCase());
          for (int i = 0; i < 8 - streamBuilder.length(); i++) {
            streamBuilder.insert(0, "0");
          }
          streamId = streamBuilder.toString();
        }
        List<MediaStreamResponse> mediaStreamResponses = mediaServerManager.getMediaList(mediaServerInstance, null, null, null, streamId);
        if (CollectionUtils.isEmpty(mediaStreamResponses) && (System.currentTimeMillis() - streamSession.getCreateAt()) > secondsWaitingForIncomingStream * 1000) {
          log.info("信令服务和流媒体服务流信息对账，移除会话->{}", streamSession);
          if (streamSession.getApp().equals(StreamSessionApp.live)) {
            streamControlManager.controlLiveStream(streamSession.getStreamId(), LiveStreamControl.CloseAudioAndVideo, streamSession.getBitstream());
          } else {
            streamControlManager.controlAppointStream(streamSession.getStreamId(), HistoryStreamControl.Close, 0, null);
          }
        }
      }
    } catch (Exception e) {
      log.error("信令服务和流媒体服务流信息对账失败", e);
    }
  }

}
