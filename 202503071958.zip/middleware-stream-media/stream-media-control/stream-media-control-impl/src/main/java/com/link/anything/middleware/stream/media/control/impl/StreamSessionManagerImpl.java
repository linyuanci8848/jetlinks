package com.link.anything.middleware.stream.media.control.impl;


import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class StreamSessionManagerImpl implements IStreamSessionManager {

  private static final Map<String, StreamSession> streamSessionMap = new ConcurrentHashMap<>();

  @Override
  public StreamSession getSession(String key) {
    return streamSessionMap.get(key);
  }

  @Override
  public void readyStream(String key) {
    StreamSession streamSession = streamSessionMap.get(key);
    streamSession.setReady(true);
  }

  @Override
  public List<StreamSession> findSession(String device, String channel) {
    return streamSessionMap
            .values()
            .stream()
            .filter(
                    item -> item.getDevice().equals(device) && item.getChannel().equals(channel)
            ).collect(Collectors.toList());
  }

  public void registerStream(String streamId, int total) {
    StreamSession streamSession = streamSessionMap.get(streamId);
    streamSession.getStreamTotal().addAndGet(total);
  }

  public int unregisterStream(String streamId, int total) {
    StreamSession streamSession = streamSessionMap.get(streamId);
    return streamSession.getStreamTotal().addAndGet(-total);
  }

  @Override
  public void removeSessionByDevice(String device) {
    List<StreamSession> streamSessions = streamSessionMap
            .values()
            .stream()
            .filter(
                    item -> item.getDevice().equals(device)
            ).collect(Collectors.toList());
    for (StreamSession streamSession : streamSessions) {
      removeSession(streamSession.getStreamId());
    }
  }

  @Override
  public void removeSession(String streamId) {
    log.info("删除会话{}", streamId);
    streamSessionMap.remove(streamId);
  }

  @Override
  public StreamSession createSession(StreamSession session) {
    log.info("添加会话,{}", session);
    streamSessionMap.put(session.getStreamId(), session);
    return session;
  }

  @Override
  public void clear() {
    streamSessionMap.clear();
  }

  @Override
  public List<StreamSession> getAllReadyStreamSession() {
    return streamSessionMap.values().stream().filter(StreamSession::isReady).collect(Collectors.toList());
  }


}
