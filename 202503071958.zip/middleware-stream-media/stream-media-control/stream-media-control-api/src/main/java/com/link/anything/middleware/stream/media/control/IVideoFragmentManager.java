package com.link.anything.middleware.stream.media.control;

import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import java.util.List;

/**
 * 设备历史视频管理接口
 */
public interface IVideoFragmentManager {

  /**
   * 批量保存历史视频
   *
   * @param videoFragmentList
   */
  public List<VideoFragment> submitHistoryVideoFragment(List<VideoFragment> videoFragmentList);

  /**
   * 通过记录ID查询历史数据片段
   *
   * @param key
   * @return
   */
  public VideoFragment findHistoryVideoFragment(String key);

}
