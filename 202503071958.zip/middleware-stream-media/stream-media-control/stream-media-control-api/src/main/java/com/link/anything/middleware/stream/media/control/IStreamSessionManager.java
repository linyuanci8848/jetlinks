package com.link.anything.middleware.stream.media.control;


import com.link.anything.middleware.stream.media.common.domain.StreamSession;

import java.util.List;

public interface IStreamSessionManager {


  /**
   * 获取Session
   *
   * @param key
   * @return
   */
  StreamSession getSession(String key);

  /**
   * 流就绪 标记当前会话
   * @param key
   */
  void readyStream(String key);
  /**
   * 通过设备和通道查询流会话
   *
   * @param device
   * @param channel
   * @return
   */
  List<StreamSession> findSession(String device, String channel);

  void registerStream(String stream, int total);

  int unregisterStream(String stream, int total);

  /**
   * 通过设备删除会话
   *
   * @param device
   */
  void removeSessionByDevice(String device);

  /**
   * 移除session
   *
   * @param key
   */
  void removeSession(String key);

  /**
   * 创建Session
   *
   * @param session
   */
  StreamSession createSession(StreamSession session);

  /**
   * 清空 session
   */
  void clear();

  /**
   * 获取就绪的流的 session
   */
  List<StreamSession> getAllReadyStreamSession();
}
