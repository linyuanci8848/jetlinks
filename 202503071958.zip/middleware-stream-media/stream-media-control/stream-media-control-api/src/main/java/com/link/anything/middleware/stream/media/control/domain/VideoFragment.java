package com.link.anything.middleware.stream.media.control.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@TableName(value = "video_fragment", autoResultMap = true)
@Accessors(chain = true)
public class VideoFragment {

  /**
   * 当前片段ID
   */
  @TableId(type=IdType.AUTO)
  private String id;

  /**
   * 设备号
   */
  private String device;
  /**
   * 通道号
   */
  private String channel;
  /**
   * 开始时间
   */
  private LocalDateTime start;
  /**
   * 结束时间
   */
  private LocalDateTime end;
  /**
   * 报警标志
   */
  private String alarmMark;
  /**
   * 文件类型
   */
  private StreamType type;
  /**
   * 码流
   */
  private Integer bitStream;
  /**
   * 视频记录位置
   */
  private HistoryVideoSource source;
  /**
   * 文件大小KB
   */
  private long size;
  /**
   * 源流協議
   */
  private StreamSourceProtocol sourceProtocol;
  /**
   * 片段Key
   */
  @TableField(value = "`key`")
  private String key;


}
