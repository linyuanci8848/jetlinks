package com.link.anything.middleware.stream.media.control;

import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.DeviceChannel;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 设备管理
 */
public interface IDeviceManager {


  /**
   * 获取设备状态
   *
   * @return
   */
  public Map<String, Boolean> findDeviceStatus();

  /**
   * 获取设备通道数据
   *
   * @return
   */
  public List<DeviceChannel> findDeviceChannel();

  /**
   * 按照协议查询设备信息
   *
   * @param protocol
   * @return
   */
  public List<Device> findDeviceByProtocol(StreamSourceProtocol protocol);

  /**
   * 设备上线
   *
   * @param device
   */
  public void online(Device device);


  /**
   * 设备离线
   *
   * @param number
   */
  public void offline(String number);


  /**
   * 注册通道
   *
   * @param channels
   */
  public void updateDeviceChanel(List<DeviceChannel> channels);


  /**
   * 删除设备通道
   *
   * @param channels
   */
  public void deleteDeviceChannel(String device, List<String> channels);

  /**
   * 通过设备号删除通道
   *
   * @param device
   */
  public void deleteDeviceChannelByDevice(String device);

  /**
   * 查询设备
   *
   * @param deviceId
   * @return
   */
  public Device findDevice(String deviceId);


  /**
   * 更新设备信息
   *
   * @param device
   */
  void updateDevice(Device device);


  /**
   * 设备是否在线
   *
   * @param device
   * @return
   */
  public boolean isOnline(String device);
}
