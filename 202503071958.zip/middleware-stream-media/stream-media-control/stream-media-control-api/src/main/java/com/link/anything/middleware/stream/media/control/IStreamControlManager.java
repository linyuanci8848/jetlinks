package com.link.anything.middleware.stream.media.control;


import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.PTZStreamControl;
import com.link.anything.middleware.stream.media.common.domain.StreamInfo;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamPlayType;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Consumer;

/**
 * 流控制管理器
 */
public interface IStreamControlManager {

  /**
   * 创建直播流.
   *
   * @param deviceNumber         设备SIM卡号
   * @param channel              通道号
   * @param bitStream            码流
   * @param transmissionProtocol 流源头传输协议
   * @param streamTransferMethod 网络协议
   */
  public StreamInfo createLiveStream(String deviceNumber, String channel, Integer bitStream, StreamSourceProtocol transmissionProtocol, StreamTransferMethod streamTransferMethod);

  /**
   * 控制直播流.
   *
   * @param stream
   * @param control
   * @param bitStream
   */
  public void controlLiveStream(String stream, LiveStreamControl control, Integer bitStream);


  /**
   * 查询历史视频.
   *
   * @param deviceNumber
   * @param channel
   * @param sourceType
   * @param start
   * @param end
   * @param type
   * @param bitStream
   * @param source
   */
  public void findVideoHistory(String deviceNumber, String channel, StreamSourceProtocol sourceType, LocalDateTime start, LocalDateTime end, StreamType type, Integer bitStream,
      HistoryVideoSource source, Consumer<List<VideoFragment>> consumer, Consumer<Object> timeout);

  /**
   * 创建点播流.
   *
   * @param id       历史视频流片段
   * @param playType 播放方式
   * @param multiple 倍数
   */
  public StreamInfo createAppointStream(String id, StreamTransferMethod method, HistoryStreamPlayType playType, Integer multiple);


  /**
   * 控制点播流.
   *
   * @param key      片段ID
   * @param control  控制指令
   * @param multiple 倍数
   * @param point    时间点 秒
   */
  public void controlAppointStream(String key, HistoryStreamControl control, Integer multiple, Long point);

  /**
   * 创建对讲流.
   *
   * @param device         设备
   * @param sourceProtocol 设备协议
   * @param audioChannel   对讲通道号
   * @param method         传输方法
   */
  public String createTalkLink(String device, StreamSourceProtocol sourceProtocol, String audioChannel, StreamTransferMethod method);


  /**
   * 摄像头云台控制.
   *
   * @param stream        直播流ID
   * @param control       控制指令
   * @param horizonSpeed  水平速度
   * @param zoomSpeed     缩放速度
   * @param verticalSpeed 垂直速度
   */
  public void controlPTZStream(String stream, PTZStreamControl control, Integer horizonSpeed, Integer zoomSpeed, Integer verticalSpeed);

  /**
   * 截图.
   *
   * @param streamKey 流标识
   */
  public void screenshot(String streamKey);

}
