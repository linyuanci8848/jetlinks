package com.link.anything.middleware.stream.media.control;

import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.domain.Alarm;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.DeviceChannel;
import java.util.List;
import java.util.Map;

/**
 * 设备报警管理
 */
public interface IDeviceAlarmManager {

  /**
   * 提交报警数据
   *
   * @param alarm
   * @return
   */
  public Long submitAlarm(Alarm alarm);
}
