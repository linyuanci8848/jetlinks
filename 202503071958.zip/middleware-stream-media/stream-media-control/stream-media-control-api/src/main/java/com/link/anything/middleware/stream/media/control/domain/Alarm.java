package com.link.anything.middleware.stream.media.control.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import com.link.anything.common.constant.AlarmVariable;
import com.link.anything.middleware.stream.media.common.constant.Attachment;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@TableName(value = "device_alarm", autoResultMap = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Schema(description = "设备报警")
public class Alarm {

  //数据 ID
  private Long id;
  //报警项目
  private AlarmVariable variable;
  //设备编号
  private String number;
  //警报状态
  private Integer state;
  //警报消息
  private String message;
  //数据发生时间
  private LocalDateTime date;
  //拍照是否完成 0 为未进行 1为已完成 2为执行超时 3 设备返回失败 4 设备通道不支持
  @Builder.Default
  private int snapshot = 0;
  //附件上传状态
  @Builder.Default
  private boolean attachmentsReport = false;
  //上报是否完成
  @Builder.Default
  private boolean report = false;
  //数据创建时间
  private LocalDateTime createAt;


  private List<Attachment> attachments;

}
