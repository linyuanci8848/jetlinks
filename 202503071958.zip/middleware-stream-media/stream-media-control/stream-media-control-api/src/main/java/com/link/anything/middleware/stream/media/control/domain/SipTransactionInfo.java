package com.link.anything.middleware.stream.media.control.domain;

import gov.nist.javax.sip.message.SIPResponse;
import lombok.Getter;

@Getter
public class SipTransactionInfo {

    private String callId;
    private String fromTag;
    private String toTag;
    private String viaBranch;

    public SipTransactionInfo(SIPResponse response) {
        this.callId = response.getCallIdHeader().getCallId();
        this.fromTag = response.getFromTag();
        this.toTag = response.getToTag();
        this.viaBranch = response.getTopmostViaHeader().getBranch();
    }

    public SipTransactionInfo() {
    }

    public void setCallId(String callId) {
        this.callId = callId;
    }

    public void setFromTag(String fromTag) {
        this.fromTag = fromTag;
    }

    public void setToTag(String toTag) {
        this.toTag = toTag;
    }

    public void setViaBranch(String viaBranch) {
        this.viaBranch = viaBranch;
    }
}
