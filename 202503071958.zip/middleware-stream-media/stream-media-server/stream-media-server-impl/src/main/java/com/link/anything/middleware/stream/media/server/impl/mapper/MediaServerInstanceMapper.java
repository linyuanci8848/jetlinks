package com.link.anything.middleware.stream.media.server.impl.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MediaServerInstanceMapper extends BaseMapper<MediaServerInstance> {

}
