package com.link.anything.middleware.stream.media.server;

public class MediaException extends RuntimeException{

  public MediaException() {
    super();
  }

  public MediaException(String message) {
    super(message);
  }

  public MediaException(String message, Throwable cause) {
    super(message, cause);
  }
}
