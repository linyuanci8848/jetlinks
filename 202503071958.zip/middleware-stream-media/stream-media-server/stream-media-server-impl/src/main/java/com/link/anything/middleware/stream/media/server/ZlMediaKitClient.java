package com.link.anything.middleware.stream.media.server;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.link.anything.middleware.stream.media.server.domain.ZlMediaKitInstanceProperties;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import com.link.anything.middleware.stream.media.server.request.AddFFmpegSourceRequest;
import com.link.anything.middleware.stream.media.server.request.AddStreamProxyRequest;
import com.link.anything.middleware.stream.media.server.request.AddStreamPusherProxyRequest;
import com.link.anything.middleware.stream.media.server.request.BaseRequest;
import com.link.anything.middleware.stream.media.server.request.CloseRtpServerRequest;
import com.link.anything.middleware.stream.media.server.request.CloseStreamsRequest;
import com.link.anything.middleware.stream.media.server.request.DelFFmpegSourceRequest;
import com.link.anything.middleware.stream.media.server.request.DelStreamProxyRequest;
import com.link.anything.middleware.stream.media.server.request.DelStreamPusherProxyRequest;
import com.link.anything.middleware.stream.media.server.request.GetMp4RecordFileRequest;
import com.link.anything.middleware.stream.media.server.request.GetRTPInfoRequest;
import com.link.anything.middleware.stream.media.server.request.GetSnapRequest;
import com.link.anything.middleware.stream.media.server.request.IsRecordingRequest;
import com.link.anything.middleware.stream.media.server.request.MediaListRequest;
import com.link.anything.middleware.stream.media.server.request.OpenRtpServerRequest;
import com.link.anything.middleware.stream.media.server.request.StartRecordRequest;
import com.link.anything.middleware.stream.media.server.request.StartSendRtpPassiveRequest;
import com.link.anything.middleware.stream.media.server.request.StartSendRtpRequest;
import com.link.anything.middleware.stream.media.server.request.StopRecordRequest;
import com.link.anything.middleware.stream.media.server.request.StopSendRtpRequest;
import com.link.anything.middleware.stream.media.server.response.AddFFmpegResponse;
import com.link.anything.middleware.stream.media.server.response.AddStreamProxyResponse;
import com.link.anything.middleware.stream.media.server.response.CloseRtpServerResponse;
import com.link.anything.middleware.stream.media.server.response.DelFFmpegResponse;
import com.link.anything.middleware.stream.media.server.response.DelStreamProxyResponse;
import com.link.anything.middleware.stream.media.server.response.GetMp4RecordFileResponse;
import com.link.anything.middleware.stream.media.server.response.GetRtpInfoResponse;
import com.link.anything.middleware.stream.media.server.response.IsRecordingResponse;
import com.link.anything.middleware.stream.media.server.response.ListRtpServerResponse;
import com.link.anything.middleware.stream.media.server.response.MediaStreamResponse;
import com.link.anything.middleware.stream.media.server.response.OpenRtpServerResponse;
import com.link.anything.middleware.stream.media.server.response.StartRecordResponse;
import com.link.anything.middleware.stream.media.server.response.StartSendRtpResponse;
import com.link.anything.middleware.stream.media.server.response.StopSendRtpResponse;
import com.link.anything.middleware.stream.media.server.response.ZLMediaKitResponse;
import java.util.List;
import java.util.Objects;
import javax.annotation.Resource;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

/**
 * ZlMediaKit 主动交互终端
 */
@Component
public class ZlMediaKitClient {

  private final Logger logger = LoggerFactory.getLogger(ZlMediaKitClient.class);

  @Resource
  private OkHttpClient defaultHttpClient;

  @Resource
  private ObjectMapper objectMapper;

  private <T> T requestData(MediaServerInstance instance, String url, BaseRequest data, TypeReference<T> typeReference, String defaultData) {
    return this.requestData(instance, url, data, typeReference, false, defaultData);
  }

  private <T> T requestData(MediaServerInstance instance, String url, BaseRequest data, TypeReference<T> typeReference, boolean dataIsNull, String defaultData) {
    Response response = null;
    String responseStr = null;
    try {
      data.setSecret(instance.getSecret());
      String requestUrl = String.format("http://%s:%s%s", instance.getControlIp(), instance.getHttpPort(), url);
      MediaType JSON = MediaType.parse("application/json;charset=utf-8");
      RequestBody requestBody = RequestBody.create(JSON, objectMapper.writeValueAsString(data));
      Request request = new Request.Builder().url(requestUrl).post(requestBody).build();
      response = defaultHttpClient.newCall(request).execute();
      if (response.isSuccessful()) {
        ResponseBody responseBody = response.body();
        responseStr = responseBody.string();
        ZLMediaKitResponse result = objectMapper.readValue(responseStr, ZLMediaKitResponse.class);
        if (result.getCode() != 0) {
          logger.error("{}-{}:{}", url, data, responseStr);
        }
        if (result.getCode() == 0 && typeReference != null && !dataIsNull) {
          if (result.getData() != null) {
            defaultData = objectMapper.writeValueAsString(result.getData());
          }
          return objectMapper.readValue(defaultData, typeReference);
        }
        if (result.getCode() == 0 && typeReference != null && dataIsNull) {
          return objectMapper.readValue(responseStr, typeReference);
        }
        logger.error("ZLMediaKit 返回失败, responseStr:" + responseStr);
      } else {
        logger.error("ZLMediaKit 返回失败, message:" + response.message());
      }
    } catch (Exception e) {
      logger.error("ZLMediaKit 交互异常,responseStr:" + responseStr, e);
    } finally {
      if (response != null) {
        response.close();
      }
    }

    return null;
  }

  /**
   * 获取服务器配置
   *
   * @param instance
   * @return
   */
  public ZlMediaKitInstanceProperties getServerConfig(MediaServerInstance instance) {
    String path = "/index/api/getServerConfig";
    BaseRequest baseRequest = new BaseRequest();
    baseRequest.setSecret(instance.getSecret());
    List<ZlMediaKitInstanceProperties> zlMediaKitInstanceProperties = requestData(instance, path, baseRequest, new TypeReference<List<ZlMediaKitInstanceProperties>>() {
    }, "[]");
    if (CollectionUtils.isEmpty(zlMediaKitInstanceProperties)) {
      return null;
    }
    return zlMediaKitInstanceProperties.get(0);
  }


  /**
   * 获取当前在线播放流
   *
   * @param instance 当前流媒体服务器实例
   * @param schema   流协议
   * @param vhost    流虚拟主机
   * @param app      流APP
   * @param stream   流动标识
   * @return
   */
  public List<MediaStreamResponse> getMediaList(MediaServerInstance instance, String schema, String vhost, String app, String stream) {
    MediaListRequest request = new MediaListRequest();
    if (StringUtils.hasLength(schema)) {
      request.setSchema(schema);
    }
    if (StringUtils.hasLength(vhost)) {
      request.setVhost(vhost);
    }
    if (StringUtils.hasLength(app)) {
      request.setApp(app);
    }
    if (StringUtils.hasLength(stream)) {
      request.setStream(stream);
    }
    String path = "/index/api/getMediaList";
    return requestData(instance, path, request, new TypeReference<List<MediaStreamResponse>>() {
    }, "[]");
  }

  /**
   * 关闭指定流
   *
   * @param instance
   * @param schema
   * @param vhost
   * @param app
   * @param stream
   * @param force
   */
  public void closeStreams(MediaServerInstance instance, String schema, String vhost, String app, String stream, Integer force) {
    CloseStreamsRequest request = new CloseStreamsRequest();
    if (StringUtils.hasLength(schema)) {
      request.setSchema(schema);
    }
    if (StringUtils.hasLength(vhost)) {
      request.setVhost(vhost);
    }
    if (StringUtils.hasLength(app)) {
      request.setApp(app);
    }
    if (StringUtils.hasLength(stream)) {
      request.setStream(stream);
    }
    if (!Objects.isNull(force)) {
      request.setForce(force);
    }
    String path = "/index/api/close_streams";
    requestData(instance, path, request, null, true, "{}");
  }

  //获取所有TcpSession列表(获取所有tcp客户端相关信息)
  //TODO /index/api/getAllSession
  //断开tcp连接，比如说可以断开rtsp、rtmp播放器等
  //TODO /index/api/kick_session

  /**
   * 添加拉流代理
   * <p>动态添加rtsp/rtmp/hls/http-ts/http-flv拉流代理(只支持H264/H265/aac/G711/opus负载)</p>
   *
   * @param instance
   * @param request
   */
  public AddStreamProxyResponse addStreamProxy(MediaServerInstance instance, AddStreamProxyRequest request) {
    String path = "/index/api/addStreamProxy";
    return requestData(instance, path, request, new TypeReference<AddStreamProxyResponse>() {
    }, "{}");
  }

  /**
   * 删除拉流代理
   * <p>/index/api/delStreamProxy(流注册成功后，也可以使用close_streams接口替代)</p>
   *
   * @param instance
   * @param key
   * @return
   */
  public DelStreamProxyResponse delStreamProxy(MediaServerInstance instance, String key) {
    String path = "/index/api/delStreamProxy";
    DelStreamProxyRequest.DelStreamProxyRequestBuilder request = DelStreamProxyRequest.builder();
    request.key(key);
    return requestData(instance, path, request.build(), new TypeReference<DelStreamProxyResponse>() {
    }, "{}");
  }

  /**
   * 添加FFmpeg 拉流代理
   * <p>：通过fork FFmpeg进程的方式拉流代理，支持任意协议 </p>
   *
   * @param instance
   * @param request
   * @return
   */
  public AddFFmpegResponse addFFmpegSource(MediaServerInstance instance, AddFFmpegSourceRequest request) {
    String path = "/index/api/addFFmpegSource";
    return requestData(instance, path, request, new TypeReference<AddFFmpegResponse>() {
    }, "{}");
  }

  /**
   * 关闭ffmpeg拉流代理
   *
   * @param instance
   * @param key
   * @return
   */
  public DelFFmpegResponse delFFmpegSource(MediaServerInstance instance, String key) {
    String path = "/index/api/delFFmpegSource";
    DelFFmpegSourceRequest.DelFFmpegSourceRequestBuilder request = DelFFmpegSourceRequest.builder();
    request.key(key);
    return requestData(instance, path, request.build(), new TypeReference<DelFFmpegResponse>() {
    }, "{}");
  }
///index/api/getRtpInfo

  /**
   * 获取rtp代理时的某路ssrc rtp信息
   *
   * @param instance
   * @param stream_id
   * @return
   */
  public GetRtpInfoResponse getRtpInfo(MediaServerInstance instance, String stream_id) {
    String path = "/index/api/getRtpInfo";
    GetRTPInfoRequest.GetRTPInfoRequestBuilder request = GetRTPInfoRequest.builder();
    request.stream_id(stream_id);
    return requestData(instance, path, request.build(), new TypeReference<GetRtpInfoResponse>() {
    }, true, "{}");
  }

  /**
   * 搜索文件系统，获取流对应的录像文件列表或日期文件夹列表
   *
   * @param instance
   * @param request
   * @return
   */
  public GetMp4RecordFileResponse getMp4RecordFile(MediaServerInstance instance, GetMp4RecordFileRequest request) {
    String path = "/index/api/getMp4RecordFile";
    return requestData(instance, path, request, new TypeReference<GetMp4RecordFileResponse>() {
    }, "{}");
  }

  /**
   * 开始录制hls或MP4
   *
   * @param instance
   * @param request
   * @return
   */
  public Boolean startRecord(MediaServerInstance instance, StartRecordRequest request) {
    String path = "/index/api/startRecord";
    StartRecordResponse response = requestData(instance, path, request, new TypeReference<StartRecordResponse>() {
    }, true, "{}");
    return response.getResult();
  }

  /**
   * 开始录制hls或MP4
   *
   * @param instance
   * @param request
   * @return
   */
  public Boolean stopRecord(MediaServerInstance instance, StopRecordRequest request) {
    String path = "/index/api/stopRecord";
    StartRecordResponse response = requestData(instance, path, request, new TypeReference<StartRecordResponse>() {
    }, true, "{}");
    return response.getResult();
  }

  /**
   * 获取流录制状态
   *
   * @param instance
   * @param request
   * @return
   */
  public Boolean isRecording(MediaServerInstance instance, IsRecordingRequest request) {
    String path = "/index/api/isRecording";
    IsRecordingResponse response = requestData(instance, path, request, new TypeReference<IsRecordingResponse>() {
    }, true, "{}");
    return response.getStatus();
  }

  /**
   * 获取截图
   *
   * @param instance
   * @param data
   * @return
   */
  public byte[] getSnap(MediaServerInstance instance, GetSnapRequest data) {
    String path = "/index/api/getSnap";
    Response response = null;
    try {
      data.setSecret(instance.getSecret());
      String requestUrl = String.format("http://%s:%s%s", instance.getControlIp(), instance.getHttpPort(), path);
      MediaType JSON = MediaType.parse("application/json;charset=utf-8");
      RequestBody requestBody = RequestBody.create(JSON, objectMapper.writeValueAsString(data));
      Request request = new Request.Builder().url(requestUrl).post(requestBody).build();
      response = defaultHttpClient.newCall(request).execute();
      if (response.isSuccessful()) {
        return response.body().bytes();
      }
    } catch (Exception e) {
      throw new MediaException("ZLMediaKit 交互异常", e);
    } finally {
      if (response != null) {
        response.close();
      }
    }
    return null;
  }

  /**
   * 创建GB28181 RTP接收端口，如果该端口接收数据超时，则会自动被回收(不用调用closeRtpServer接口)
   *
   * @param instance
   * @param request
   * @return 创建端口号
   */
  public Integer openRtpServer(MediaServerInstance instance, OpenRtpServerRequest request) {
    String path = "/index/api/openRtpServer";
    OpenRtpServerResponse response = requestData(instance, path, request, new TypeReference<OpenRtpServerResponse>() {
    }, true, "{}");
    if (request.getPort() != 0) {
      return request.getPort();
    }
    return response.getPort();
  }

  /**
   * 关闭GB28181 RTP接收端口
   *
   * @param instance
   * @param streamId
   * @return 是否找到记录并关闭
   */
  public Integer closeRtpServer(MediaServerInstance instance, String streamId) {
    String path = "/index/api/closeRtpServer";
    CloseRtpServerRequest.CloseRtpServerRequestBuilder builder = CloseRtpServerRequest.builder();
    builder.streamId(streamId);
    CloseRtpServerResponse response = requestData(instance, path, builder.build(), new TypeReference<CloseRtpServerResponse>() {
    }, true, "{}");
    return response.getHit();
  }

  /**
   * 获取openRtpServer接口创建的所有RTP服务器
   *
   * @param instance
   * @return
   */
  public List<ListRtpServerResponse> listRtpServer(MediaServerInstance instance) {
    String path = "/index/api/listRtpServer";
    BaseRequest baseRequest = new BaseRequest();
    baseRequest.setSecret(instance.getSecret());
    return requestData(instance, path, baseRequest, new TypeReference<List<ListRtpServerResponse>>() {
    }, "[]");
  }

  /**
   * 作为GB28181客户端，启动ps-rtp推流，支持rtp/udp方式；该接口支持rtsp/rtmp等协议转ps-rtp推流。第一次推流失败会直接返回错误，成功一次后，后续失败也将无限重试。
   *
   * @param instance
   * @param request
   * @return
   */
  public Integer startSendRtp(MediaServerInstance instance, StartSendRtpRequest request) {
    String path = "/index/api/startSendRtp";
    StartSendRtpResponse response = requestData(instance, path, request, new TypeReference<StartSendRtpResponse>() {
    }, true, "{}");
    return response.getLocalPort();
  }

  /**
   * 作为GB28181 Passive TCP服务器；该接口支持rtsp/rtmp等协议转ps-rtp被动推流。调用该接口，zlm会启动tcp服务器等待连接请求，
   * <p>连接建立后，zlm会关闭tcp服务器，然后源源不断的往客户端推流。第一次推流失败会直接返回错误，成功一次后，后续失败也将无限重试(不停地建立tcp监听，超时后再关闭)。</p>
   *
   * @param instance
   * @param request
   * @return
   */
  public Integer startSendRtpPassive(MediaServerInstance instance, StartSendRtpPassiveRequest request) {
    String path = "/index/api/startSendRtp";
    StartSendRtpResponse response = requestData(instance, path, request, new TypeReference<StartSendRtpResponse>() {
    }, true, "{}");
    return response.getLocalPort();
  }

  /**
   * 停止GB28181 ps-rtp推流
   *
   * @param instance
   * @param request
   */
  public boolean stopSendRtp(MediaServerInstance instance, StopSendRtpRequest request) {
    String path = "/index/api/stopSendRtp";
    StopSendRtpResponse data = requestData(instance, path, request, new TypeReference<StopSendRtpResponse>() {
    }, true, "{\"code\":0}");
    if (data == null) {
      return false;
    }
    return true;
  }

  /**
   * 添加rtsp/rtmp主动推流(把本服务器的直播流推送到其他服务器去)
   *
   * @param instance
   * @param request
   * @return
   */
  public List<String> addStreamPusherProxy(MediaServerInstance instance, AddStreamPusherProxyRequest request) {
    String path = "/index/api/addStreamPusherProxy";
    return requestData(instance, path, request, new TypeReference<List<String>>() {
    }, "[]");
  }

  /**
   * 关闭推流
   *
   * @param instance
   * @param key      addStreamPusherProxy接口返回的key
   * @return
   */
  public boolean delStreamPusherProxy(MediaServerInstance instance, String key) {

    String path = "/index/api/delStreamPusherProxy";
    DelStreamPusherProxyRequest.DelStreamPusherProxyRequestBuilder builder = DelStreamPusherProxyRequest.builder();
    DelStreamProxyResponse response = requestData(instance, path, builder.key(key).build(), new TypeReference<DelStreamProxyResponse>() {
    }, "{}");
    return response.getFlag();
  }


}
