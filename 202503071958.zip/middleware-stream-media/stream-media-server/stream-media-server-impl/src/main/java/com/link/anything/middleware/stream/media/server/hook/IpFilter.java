package com.link.anything.middleware.stream.media.server.hook;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@Slf4j
public class IpFilter implements Filter {

    @Value("${stream.media.server.ipList}")
    private List<String> ipList;
    // 允许访问的IP列表
 
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        String ip = httpServletRequest.getRemoteAddr();

        if (ipList.isEmpty() || ipList.contains(ip)) {
            filterChain.doFilter(servletRequest, servletResponse);
        } else {
            // 返回错误信息或者重定向到错误页面
            log.warn("白名单校验失败,非法IP:{}", ip);
             ((HttpServletResponse) servletResponse).sendError(HttpServletResponse.SC_FORBIDDEN);
        }
    }
}