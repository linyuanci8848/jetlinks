package com.link.anything.middleware.stream.media.server.hook;

import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.common.domain.StreamSessionApp;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.protocol.IProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.ProtocolExecutorProvider;
import com.link.anything.middleware.stream.media.server.IMediaServerManager;
import com.link.anything.middleware.stream.media.server.domain.ZlMediaKitInstanceProperties;
import com.link.anything.middleware.stream.media.server.request.OnPlayHookRequest;
import com.link.anything.middleware.stream.media.server.request.OnPublishHookRequest;
import com.link.anything.middleware.stream.media.server.request.OnRtpServerTimeoutHookRequest;
import com.link.anything.middleware.stream.media.server.request.OnSendRtpStoppedHookRequest;
import com.link.anything.middleware.stream.media.server.request.OnServerKeepAliveHookRequest;
import com.link.anything.middleware.stream.media.server.request.OnStreamChangedHookRequest;
import com.link.anything.middleware.stream.media.server.request.OnStreamNoneReaderHookRequest;
import com.link.anything.middleware.stream.media.server.request.OnStreamNotFoundHookRequest;
import com.link.anything.middleware.stream.media.server.response.HookResponse;
import com.link.anything.middleware.stream.media.server.response.HookResponseForOnPublish;
import com.link.anything.middleware.stream.media.server.response.HookStreamNoneReaderResponse;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.async.DeferredResult;

@RestController
@RequestMapping("/index/hook")
public class ZLMHttpHookListener {

  private final static Logger logger = LoggerFactory.getLogger(ZLMHttpHookListener.class);

  @Resource
  private ProtocolExecutorProvider protocolExecutorProvider;
  @Resource
  private SubscribeManager subscribeManager;

  @Resource
  private IMediaServerManager mediaServerManager;
  @Resource
  private IStreamSessionManager streamSessionManager;


  /**
   * 服务器定时上报时间，上报间隔可配置，默认10s上报一次
   */
  @ResponseBody
  @PostMapping(value = "/on_server_keepalive", produces = "application/json;charset=UTF-8")
  public HookResponse onServerKeepAlive(@RequestBody OnServerKeepAliveHookRequest param) {
    mediaServerManager.keepAlive(param.getMediaServerId(), param.getData());
    return HookResponse.SUCCESS();
  }

  /**
   * 播放器鉴权事件，rtsp/rtmp/http-flv/ws-flv/hls的播放都将触发此鉴权事件。
   */
  @ResponseBody
  @PostMapping(value = "/on_play", produces = "application/json;charset=UTF-8")
  public HookResponse onPlay(@RequestBody OnPlayHookRequest param) {

    Map<String, String> paramMap = urlRequestToMap(param.getParams());
    String token = paramMap.get("token");
    String streamId = param.getStream();
    if (!streamId.contains("_")) {
      //是GB28181  stream id 是16进制的
      streamId = String.format("%010d", Integer.parseInt(streamId, 16));
    }
    StreamSession streamSession = streamSessionManager.getSession(streamId);
    if (streamSession == null) {
      logger.info("[ZLM HOOK] 播放鉴权,流[{}]会话不存在", param.getStream());
      return HookResponse.Fail("流不存在");
    }
    if (!streamSession.verifyToken(token)) {
      logger.info("[ZLM HOOK] 播放鉴权,流[{}]播放鉴权不通过,token:{},tokens:{}", param.getStream(), token, streamSession.getPlayTokens());
      return new HookResponse(401, "Unauthorized");
    }
    logger.info("[ZLM HOOK] 播放鉴权,流[{}]播放鉴权通过：{}->{}", param.getStream(), param.getMediaServerId(), param);
    return HookResponse.SUCCESS();
  }

  /**
   * rtsp/rtmp/rtp推流鉴权事件。
   */
  @ResponseBody
  @PostMapping(value = "/on_publish", produces = "application/json;charset=UTF-8")
  public HookResponseForOnPublish onPublish(@RequestBody OnPublishHookRequest param) {
    logger.info("[ZLM HOOK]推流鉴权：{}->{}", param.getMediaServerId(), param);
    String streamId = param.getStream();
    if (!streamId.contains("_")) {
      //是GB28181  stream id 是16进制的
      streamId = String.format("%010d", Integer.parseInt(streamId, 16));
    }
    StreamSession streamSession = streamSessionManager.getSession(streamId);
    if (streamSession == null) {
      logger.warn("[ZLM HOOK]推流鉴权,流[{}]会话不存在", param.getStream());
      return new HookResponseForOnPublish(401, "会话不存在");
    }
    subscribeManager.publish(StreamDefinitionEventKey.StreamPush + streamId, param);
    return HookResponseForOnPublish.SUCCESS();
  }


  /**
   * rtsp/rtmp流注册或注销时触发此事件；此事件对回复不敏感。
   */
  @ResponseBody
  @PostMapping(value = "/on_stream_changed", produces = "application/json;charset=UTF-8")
  public HookResponse onStreamChanged(@RequestBody OnStreamChangedHookRequest param) {

    String stream = param.getStream();
    if (!stream.contains("_")) {
      //是GB28181  stream id 是16进制的
      stream = String.format("%010d", Integer.parseInt(stream, 16));
    }
    StreamSession streamSession = streamSessionManager.getSession(stream);
    if (streamSession == null) {
      logger.info("[ZLM HOOK] 流变化，流会话不存在:{}", param);
      return HookResponse.SUCCESS();
    }
    if (param.isRegist()) {
      logger.info("[ZLM HOOK] 流注册, {}->{}->{}/{} {}", param.getMediaServerId(), param.getSchema(), param.getApp(), param.getStream(), param);
      streamSessionManager.registerStream(stream, 1);
    } else {
      logger.info("[ZLM HOOK] 流注销, {}->{}->{}/{} {}", param.getMediaServerId(), param.getSchema(), param.getApp(), param.getStream(), param);
//      if (streamSessionManager.unregisterStream(stream, 1) <= 0) {
//        IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(streamSession.getStreamSourceProtocol());
//        if (streamSession.getApp().equals(StreamSessionApp.live)) {
//          //protocolExecutor.controlLiveStream(streamSession, LiveStreamControl.CloseAudioAndVideo);
//        } else {
//          // protocolExecutor.controlHistoryStream(streamSession, HistoryStreamControl.Close, 0, null);
//        }
//      }
    }
    return HookResponse.SUCCESS();
  }

  /**
   * 流无人观看时事件，用户可以通过此事件选择是否关闭无人看的流。
   */
  @ResponseBody
  @PostMapping(value = "/on_stream_none_reader", produces = "application/json;charset=UTF-8")
  public HookStreamNoneReaderResponse onStreamNoneReader(@RequestBody OnStreamNoneReaderHookRequest param) {
    String stream = param.getStream();
    if (!stream.contains("_")) {
      //是GB28181  stream id 是16进制的
      stream = String.format("%010d", Integer.parseInt(stream, 16));
    }
    StreamSession streamSession = streamSessionManager.getSession(stream);
    if (streamSession == null) {
      logger.info("[ZLM HOOK] 流无人观看,流会话不存在:{}", param);
      return HookStreamNoneReaderResponse.Close();
    }
    logger.info("[ZLM HOOK] 流无人观看, 流{}对应的所有播放流均无人观看 关闭流源,{}", param.getStream(), param);
    IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(streamSession.getStreamSourceProtocol());
    if (streamSession.getApp().equals(StreamSessionApp.live)) {
      protocolExecutor.controlLiveStream(streamSession, LiveStreamControl.CloseAudioAndVideo);
    } else {
      protocolExecutor.controlHistoryStream(streamSession, HistoryStreamControl.Close, 0, null);
    }
    return HookStreamNoneReaderResponse.Close();
  }

  /**
   * 流未找到事件，用户可以在此事件触发时，立即去拉流，这样可以实现按需拉流；此事件对回复不敏感。
   */
  @ResponseBody
  @PostMapping(value = "/on_stream_not_found", produces = "application/json;charset=UTF-8")
  public DeferredResult<HookResponse> onStreamNotFound(@RequestBody OnStreamNotFoundHookRequest param) {
    logger.info("[ZLM HOOK] 流未找到：{}->{}->{}/{}", param.getMediaServerId(), param.getSchema(), param.getApp(), param.getStream());
    String stream = param.getStream();
    if (!stream.contains("_")) {
      //是GB28181  stream id 是16进制的
      stream = String.format("%010d", Integer.parseInt(stream, 16));
    }
    StreamSession streamSession = streamSessionManager.getSession(stream);
    if (streamSession == null) {
      DeferredResult<HookResponse> defaultResult = new DeferredResult<>();
      defaultResult.setResult(new HookResponse(404, "流不存在"));
      return defaultResult;
    }
    logger.info("[ZLM HOOK] 流未找到，会话已存在：{}", streamSession);
    if (StreamSourceProtocol.HKV == streamSession.getStreamSourceProtocol()) {
      logger.info("海康协议的要重新拉流");
      IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(streamSession.getStreamSourceProtocol());
      protocolExecutor.controlLiveStream(streamSession, LiveStreamControl.ContinueStream);
    }
    DeferredResult<HookResponse> defaultResult = new DeferredResult<>();
    defaultResult.setResult(new HookResponse(404, "流不存在"));
    return defaultResult;
  }

  /**
   * 服务器启动事件，可以用于监听服务器崩溃重启；此事件对回复不敏感。
   */
  @ResponseBody
  @PostMapping(value = "/on_server_started", produces = "application/json;charset=UTF-8")
  public HookResponse onServerStarted(HttpServletRequest request, @RequestBody ZlMediaKitInstanceProperties zlmServerConfig) {
    zlmServerConfig.setIp(request.getRemoteAddr());
    logger.info("[ZLM HOOK on_server_started] zlm 启动 " + zlmServerConfig.getGeneralMediaServerId());
    mediaServerManager.online(zlmServerConfig);
    return HookResponse.SUCCESS();
  }

  /**
   * 发送rtp(startSendRtp)被动关闭时回调
   */
  @ResponseBody
  @PostMapping(value = "/on_send_rtp_stopped", produces = "application/json;charset=UTF-8")
  public HookResponse onSendRtpStopped(HttpServletRequest request, @RequestBody OnSendRtpStoppedHookRequest param) {
    String stream = param.getStream();
    if (!stream.contains("_")) {
      //是GB28181  stream id 是16进制的
      stream = String.format("%010d", Integer.parseInt(stream, 16));
    }
    StreamSession streamSession = streamSessionManager.getSession(stream);
    if (streamSession == null) {
      return HookResponse.SUCCESS();
    }
    return HookResponse.SUCCESS();
  }

  /**
   * rtpServer收流超时
   */
  @ResponseBody
  @PostMapping(value = "/on_rtp_server_timeout", produces = "application/json;charset=UTF-8")
  public HookResponse onRtpServerTimeout(HttpServletRequest request, @RequestBody OnRtpServerTimeoutHookRequest param) {
    String stream = param.getStream_id();
    if (!stream.contains("_")) {
      //是GB28181  stream id 是16进制的
      stream = String.format("%010d", Integer.parseInt(stream, 16));
    }
    logger.info("[ZLM HOOK on_rtp_server_timeout] 收流超时 {}", param);
    StreamSession streamSession = streamSessionManager.getSession(stream);
    if (streamSession == null) {
      return HookResponse.SUCCESS();
    }
    IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(streamSession.getStreamSourceProtocol());
    if (streamSession.getApp().equals(StreamSessionApp.live)) {
      protocolExecutor.controlLiveStream(streamSession, LiveStreamControl.CloseAudioAndVideo);
    } else {
      protocolExecutor.controlHistoryStream(streamSession, HistoryStreamControl.Close, 0, null);
    }
    return HookResponse.SUCCESS();
  }

  private Map<String, String> urlRequestToMap(String params) {
    HashMap<String, String> map = new HashMap<>();
    if (ObjectUtils.isEmpty(params)) {
      return map;
    }
    String[] paramsArray = params.split("&");
      for (String param : paramsArray) {
      String[] paramArray = param.split("=");
      if (paramArray.length == 2) {
        map.put(paramArray[0], paramArray[1]);
      }
    }
    return map;
  }

}
