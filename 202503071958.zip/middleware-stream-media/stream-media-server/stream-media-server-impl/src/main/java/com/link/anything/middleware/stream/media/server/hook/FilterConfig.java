package com.link.anything.middleware.stream.media.server.hook;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Configuration;
 
@Configuration
public class FilterConfig {
 

    public FilterRegistrationBean<IpFilter> ipFilter() {
        FilterRegistrationBean<IpFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(new IpFilter());
        registrationBean.addUrlPatterns("/index/*"); // 设置应用过滤器的URL模式
        registrationBean.setOrder(1);
        return registrationBean;
    }
}