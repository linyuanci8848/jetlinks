package com.link.anything.middleware.stream.media.server.impl;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.link.anything.middleware.stream.media.common.DynamicTask;
import com.link.anything.middleware.stream.media.common.StreamServerProperties;
import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.GlobalDefinitionRedisKey;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.server.IMediaServerManager;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import com.link.anything.middleware.stream.media.server.domain.ZlMediaKitInstanceProperties;
import com.link.anything.middleware.stream.media.server.impl.mapper.MediaServerInstanceMapper;
import com.link.anything.middleware.stream.media.server.request.AddStreamProxyRequest;
import com.link.anything.middleware.stream.media.server.request.ServerKeepAliveData;
import com.link.anything.middleware.stream.media.server.ZlMediaKitClient;
import com.link.anything.middleware.stream.media.server.request.OpenRtpServerRequest;
import com.link.anything.middleware.stream.media.server.request.StartSendRtpRequest;
import com.link.anything.middleware.stream.media.server.request.StopSendRtpRequest;
import com.link.anything.middleware.stream.media.server.response.AddStreamProxyResponse;
import com.link.anything.middleware.stream.media.server.response.DelStreamProxyResponse;
import com.link.anything.middleware.stream.media.server.response.GetRtpInfoResponse;
import com.link.anything.middleware.stream.media.server.response.MediaStreamResponse;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.redisson.api.RScoredSortedSet;
import org.redisson.api.RedissonClient;
import org.redisson.client.protocol.ScoredEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

@Component
public class MediaServerManagerImpl implements IMediaServerManager {

  private final Logger logger = LoggerFactory.getLogger(MediaServerManagerImpl.class);
  private final String zlmKeepaliveKeyPrefix = "zlm-keepalive_";
  @Resource
  private MediaServerInstanceMapper mediaServerInstanceMapper;

  @Resource
  private StreamServerProperties streamServerProperties;
  @Resource
  private RedissonClient redissonClient;
  @Resource
  private ZlMediaKitClient zlMediaKitClient;

  @Resource
  private DynamicTask dynamicTask;

  @Resource
  private SubscribeManager subscribeManager;

  @Override
  public List<MediaServerInstance> findMediaServerInstances(String controlServerId) {
    return mediaServerInstanceMapper.selectList(new LambdaQueryWrapper<MediaServerInstance>().eq(MediaServerInstance::getControlServerId, controlServerId));
  }

  @Override
  public MediaServerInstance findMediaServerInstance(String mediaServerId) {
    return mediaServerInstanceMapper.selectOne(new LambdaQueryWrapper<MediaServerInstance>().eq(MediaServerInstance::getInstanceId, mediaServerId));
  }

  @Transactional(rollbackFor = Exception.class)
  @Override
  public void join(ZlMediaKitInstanceProperties properties) {
    try {
      MediaServerInstance mediaServerInstance = new MediaServerInstance();
      mediaServerInstance.setInstanceId(properties.getGeneralMediaServerId());
      mediaServerInstance.setControlIp(streamServerProperties.getCurrentControlHost());
      mediaServerInstance.setStreamIp(streamServerProperties.getCurrentControlHost());
      mediaServerInstance.setHttpPort(properties.getHttpPort());
      mediaServerInstance.setSecret(properties.getApiSecret());
      mediaServerInstance.setHookAliveInterval(properties.getHookAliveInterval());
      mediaServerInstance.setRecordAssistPort(0);
      mediaServerInstance.setRtmpPort(properties.getRtmpPort());
      mediaServerInstance.setHttpSslPort(properties.getHttpSSLport());
      mediaServerInstance.setRtmpSslPort(properties.getRtmpSslPort());
      mediaServerInstance.setRtpEnable(true);
      mediaServerInstance.setRtpProxyPort(properties.getRtpProxyPort());
      mediaServerInstance.setControlServerId(streamServerProperties.getId());
      mediaServerInstance.setRtpPortRange(properties.getPortRange());
      mediaServerInstanceMapper.insert(mediaServerInstance);
    } catch (DuplicateKeyException e) {
      throw new IllegalArgumentException("流媒体实例标识重复");
    }
  }

  @Transactional(rollbackFor = Exception.class)
  @Override
  public boolean online(ZlMediaKitInstanceProperties properties) {
    if (ObjectUtils.isEmpty(properties.getGeneralMediaServerId())) {
      logger.warn("[未注册的zlm] mediaServerInstance缺少ID， 无法接入：{}：{}", properties.getIp(), properties.getHttpPort());
      return false;
    }
    MediaServerInstance mediaServerInstance = mediaServerInstanceMapper.selectOne(new LambdaQueryWrapper<MediaServerInstance>().eq(MediaServerInstance::getInstanceId,properties.getGeneralMediaServerId()));
    if (mediaServerInstance == null) {
      logger.warn("[未注册的zlm] 接入系统：{}来自{}：{}", properties.getGeneralMediaServerId(), properties.getSdpIp(), properties.getHttpPort());
      join(properties);
      return false;
    } else {
      logger.info("[ZLM] 正在连接 : {} -> {}:{}", properties.getGeneralMediaServerId(), properties.getSdpIp(), properties.getHttpPort());
    }
    try {
      mediaServerInstance.setHookAliveInterval(properties.getHookAliveInterval());
      if (mediaServerInstance.getHttpPort() == 0) {
        mediaServerInstance.setHttpPort(properties.getHttpPort());
      }
      if (mediaServerInstance.getHttpSslPort() == 0) {
        mediaServerInstance.setHttpSslPort(properties.getHttpSSLport());
      }
      if (mediaServerInstance.getRtmpPort() == 0) {
        mediaServerInstance.setRtmpPort(properties.getRtmpPort());
      }
      if (mediaServerInstance.getRtmpSslPort() == 0) {
        mediaServerInstance.setRtmpSslPort(properties.getRtmpSslPort());
      }
      if (mediaServerInstance.getRtspPort() == 0) {
        mediaServerInstance.setRtspPort(properties.getRtspPort());
      }
      if (mediaServerInstance.getRtspSsLPort() == 0) {
        mediaServerInstance.setRtspSsLPort(properties.getRtspSSlport());
      }
      if (mediaServerInstance.getRtpProxyPort() == 0) {
        mediaServerInstance.setRtpProxyPort(properties.getRtpProxyPort());
      }
      mediaServerInstanceMapper.updateById(mediaServerInstance);
      resetMediaServerInstance(mediaServerInstance);
      final String zlmKeepaliveKey = zlmKeepaliveKeyPrefix + mediaServerInstance.getInstanceId();
      dynamicTask.stop(zlmKeepaliveKey);
      dynamicTask.startDelay(zlmKeepaliveKey, new KeepAliveTimeoutRunnable(mediaServerInstance), 20 * 1000);
      logger.info("[ZLM] 连接成功 {} - {}:{} ", properties.getGeneralMediaServerId(), properties.getIp(), properties.getHttpPort());
      RScoredSortedSet<String> onlineSet = redissonClient.getScoredSortedSet(GlobalDefinitionRedisKey.MEDIA_SERVER_ONLINE_LIST + ":" + streamServerProperties.getId());
      onlineSet.add(0, mediaServerInstance.getInstanceId());
      subscribeManager.publish(StreamDefinitionEventKey.MediaServerStart.name(), mediaServerInstance.getInstanceId());
      return true;
    } catch (Exception e) {
      logger.error(e.getMessage(), e);
      return false;
    }
  }


  @Override
  public void offline(String mediaServerId) {
    final String zlmKeepaliveKey = zlmKeepaliveKeyPrefix + mediaServerId;
    dynamicTask.stop(zlmKeepaliveKey);
    RScoredSortedSet<String> onlineSet = redissonClient.getScoredSortedSet(GlobalDefinitionRedisKey.MEDIA_SERVER_ONLINE_LIST + ":" + streamServerProperties.getId());
    onlineSet.remove(mediaServerId);
  }

  @Override
  public MediaServerInstance getMediaServerForMinimumLoad(boolean hasAssist) {
    RScoredSortedSet<String> onlineSet = redissonClient.getScoredSortedSet(GlobalDefinitionRedisKey.MEDIA_SERVER_ONLINE_LIST + ":" + streamServerProperties.getId());
    int size = onlineSet.size();
    if (size == 0) {
      logger.info("获取负载最低的节点时无在线节点");
      return null;
    }
    // 获取分数最低的，及并发最低的
    Collection<ScoredEntry<String>> mediaServerObjectS = onlineSet.entryRange(0, -1);
    MediaServerInstance MediaServerInstance = null;
    if (!hasAssist) {
      String mediaServerId = mediaServerObjectS.stream().sorted(Comparator.comparing(ScoredEntry::getScore)).findFirst().get().getValue().toString();
      MediaServerInstance = findMediaServerInstance(mediaServerId);
    } else if (hasAssist) {
      //TODO 没有实现排名
      for (Object mediaServerObject : mediaServerObjectS) {
        String mediaServerId = (String) mediaServerObject;
        MediaServerInstance serverItem = findMediaServerInstance(mediaServerId);
        if (serverItem.getRecordAssistPort() > 0) {
          MediaServerInstance = serverItem;
          break;
        }
      }
    }
    return MediaServerInstance;
  }


  @Override
  public void clearMediaServerForOnline() {
    RScoredSortedSet<String> onlineSet = redissonClient.getScoredSortedSet(GlobalDefinitionRedisKey.MEDIA_SERVER_ONLINE_LIST + ":" + streamServerProperties.getId());
    onlineSet.clear();
  }

  @Override
  public int openRTPServer(MediaServerInstance instance, String streamId, Integer port, StreamTransferMethod method) {
    int result = -1;
    OpenRtpServerRequest.OpenRtpServerRequestBuilder builder = OpenRtpServerRequest.builder();
    builder.stream_id(streamId).port(port);
    // 0 udp 模式，1 tcp 被动模式, 2 tcp 主动模式
    builder.tcpMode(0);
    if (method.equals(StreamTransferMethod.TCP_PASSIVE)) {
      builder.tcpMode(1);
    }
    if (method.equals(StreamTransferMethod.TCP_ACTIVE)) {
      builder.tcpMode(2);
    }

    GetRtpInfoResponse rtpInfo = zlMediaKitClient.getRtpInfo(instance, streamId);
    if (rtpInfo.getCode() == 0) {
      if (rtpInfo.isExist()) {
        result = rtpInfo.getLocalPort();
        if (result == 0) {
          // 此时说明rtpServer已经创建但是流还没有推上来
          // 此时重新打开rtpServer
          Integer hit = zlMediaKitClient.closeRtpServer(instance, streamId);
          if (hit == 1) {
            return openRTPServer(instance, streamId, port, method);
          } else {
            logger.warn("[开启rtpServer], 重启RtpServer错误");
          }
        }
        return result;
      }
    } else if (rtpInfo.getCode() == -2) {
      return result;
    }
    Integer openRtpServerResult = zlMediaKitClient.openRtpServer(instance, builder.build());
    if (openRtpServerResult != null) {
      result = openRtpServerResult;
    } else {
      //  检查ZLM状态
      logger.error("创建RTP Server 失败 {}: 请检查ZLM服务", port);
    }
    return result;
  }


  @Override
  public void closeRTPServer(String instanceId, String streamId) {
    MediaServerInstance instance = this.findMediaServerInstance(instanceId);
    zlMediaKitClient.closeRtpServer(instance, streamId);
  }

  @Override
  public List<MediaStreamResponse> getMediaList(MediaServerInstance instance, String schema, String vhost, String app, String stream) {
    return zlMediaKitClient.getMediaList(instance, schema, vhost, app, stream);
  }

  @Override
  public Integer startSendRtp(MediaServerInstance instance, StartSendRtpRequest request) {
    return zlMediaKitClient.startSendRtp(instance, request);
  }

  @Override
  public boolean stopSendRtp(MediaServerInstance instance, StopSendRtpRequest request) {
    return zlMediaKitClient.stopSendRtp(instance, request);
  }

  @Override
  public Boolean isStreamReady(MediaServerInstance mediaServerItem, String app, String streamId) {
    List<MediaStreamResponse> mediaInfo = zlMediaKitClient.getMediaList(mediaServerItem, null, null, app, streamId);
    if (mediaInfo == null || (mediaInfo.size() < 1)) {
      return false;
    }
    return true;
  }

  @Override
  public String addStreamProxy(MediaServerInstance instance, AddStreamProxyRequest request) {
    AddStreamProxyResponse response = zlMediaKitClient.addStreamProxy(instance, request);
    if (response == null) {
      throw new RuntimeException("zlMediaKit addStreamProxy error");
    }
    return response.getKey();
  }

  @Override
  public boolean delStreamProxy(MediaServerInstance instance, String key) {
    DelStreamProxyResponse response = zlMediaKitClient.delStreamProxy(instance, key);
    if (response == null) {
      return false;
    }
    return response.getFlag();
  }

  @Override
  public boolean delStreamProxy(String instanceId, String key) {
    MediaServerInstance instance = this.findMediaServerInstance(instanceId);
    return delStreamProxy(instance, key);
  }

  @Override
  public void resetMediaServerInstance(MediaServerInstance instance) {
    RScoredSortedSet<String> onlineSet = redissonClient.getScoredSortedSet(GlobalDefinitionRedisKey.MEDIA_SERVER_ONLINE_LIST + ":" + streamServerProperties.getId());
    // 使用zset的分数作为当前并发量， 默认值设置为0
    if (!onlineSet.contains(instance.getId())) {
      // 不存在则设置默认值 已存在则重置
      onlineSet.add(0, instance.getInstanceId());
      try {
        List<MediaStreamResponse> mediaList = zlMediaKitClient.getMediaList(instance, null, null, "rtsp", null);
        onlineSet.add(mediaList.size(), instance.getInstanceId());
      } catch (Exception e) {
        logger.error(e.getMessage(), e);
      }
    }
  }


  @Override
  public void keepAlive(String mediaServerId, ServerKeepAliveData data) {
    MediaServerInstance mediaServerInstance = findMediaServerInstance(mediaServerId);
    if (mediaServerInstance == null) {
      logger.warn("[更新ZLM 保活信息] 流媒体{}尚未加入使用,请检查节点中是否含有此流媒体 ", mediaServerId);
      return;
    }
    final String zlmKeepaliveKey = zlmKeepaliveKeyPrefix + mediaServerInstance.getId();
    dynamicTask.stop(zlmKeepaliveKey);
    dynamicTask.startDelay(zlmKeepaliveKey, new KeepAliveTimeoutRunnable(mediaServerInstance), (mediaServerInstance.getHookAliveInterval().intValue() + 5) * 1000);

    RScoredSortedSet<String> onlineSet = redissonClient.getScoredSortedSet(GlobalDefinitionRedisKey.MEDIA_SERVER_ONLINE_LIST + ":" + streamServerProperties.getId());
    if (!onlineSet.contains(mediaServerId)) {
      onlineSet.add(0, mediaServerId);
    }
  }

  class KeepAliveTimeoutRunnable implements Runnable {

    private MediaServerInstance serverItem;

    public KeepAliveTimeoutRunnable(MediaServerInstance serverItem) {
      this.serverItem = serverItem;
    }

    @Override
    public void run() {
      logger.info("[zlm心跳到期]：" + serverItem.getId());
      // 发起http请求验证zlm是否确实无法连接，如果确实无法连接则发送离线事件，否则不作处理
      ZlMediaKitInstanceProperties serverConfigJson = zlMediaKitClient.getServerConfig(serverItem);
      if (serverConfigJson != null) {
        logger.info("[zlm心跳到期]：{}验证后zlm仍在线，恢复心跳信息,请检查zlm是否可以正常向SIP发送心跳", serverItem.getId());
        // 添加zlm信息
        keepAlive(serverItem.getInstanceId(), null);
      } else {
        offline(serverItem.getInstanceId());
      }
    }
  }
}
