package com.link.anything.middleware.stream.media.server;


import com.link.anything.middleware.stream.media.common.DynamicTask;
import com.link.anything.middleware.stream.media.common.StreamServerProperties;
import com.link.anything.middleware.stream.media.server.domain.ZlMediaKitInstanceProperties;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.SmartLifecycle;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class MediaServerRunner implements CommandLineRunner {

  private final Logger logger = LoggerFactory.getLogger(MediaServerRunner.class);

  @Resource
  private ZlMediaKitClient zlMediaKitClient;
  private Set<String> waitReconnectMediaServerInstance = Collections.synchronizedSet(new HashSet<>());
  @Resource
  private IMediaServerManager mediaServerManager;

  @Resource
  private DynamicTask dynamicTask;

  @Resource
  private StreamServerProperties streamServiceProperties;

  @Async("scheduledExecutorService")
  public void connectZlmServer(MediaServerInstance mediaServerInstance) {
    if (!waitReconnectMediaServerInstance.contains(mediaServerInstance.getId())) {
      return;
    }
    String connectZlmServerTaskKey = "connect-zlm-" + mediaServerInstance.getId();
    ZlMediaKitInstanceProperties zlmServerConfig = zlMediaKitClient.getServerConfig(mediaServerInstance);

    if (zlmServerConfig != null) {
      zlmServerConfig.setIp(mediaServerInstance.getControlIp());
      zlmServerConfig.setSdpIp(mediaServerInstance.getControlIp());
      zlmServerConfig.setStreamIp(mediaServerInstance.getStreamIp());
      zlmServerConfig.setHttpPort(mediaServerInstance.getHttpPort());
      if (mediaServerManager.online(zlmServerConfig)) {
        dynamicTask.stop(connectZlmServerTaskKey);
        waitReconnectMediaServerInstance.remove(zlmServerConfig.getGeneralMediaServerId());
        return;
      }
    }

    logger.info("[ZLM {} ]-[ {}:{} ]主动连接失败, 清理相关资源， 开始尝试重试连接", mediaServerInstance.getId(), mediaServerInstance.getControlIp(), mediaServerInstance.getHttpPort());
    dynamicTask.startDelay(connectZlmServerTaskKey, () -> {
      connectZlmServer(mediaServerInstance);
    }, 2000);
  }


  @Override
  public void run(String... args) {
    logger.info("清除遗留ZLM实例数据...");
    mediaServerManager.clearMediaServerForOnline();
    List<MediaServerInstance> mediaServerInstances = mediaServerManager.findMediaServerInstances(streamServiceProperties.getId());
    for (MediaServerInstance mediaServerInstance : mediaServerInstances) {
      if (mediaServerInstance.getStatus() != 2) {
        continue;
      }
      waitReconnectMediaServerInstance.add(mediaServerInstance.getInstanceId());
      connectZlmServer(mediaServerInstance);
    }
  }
}
