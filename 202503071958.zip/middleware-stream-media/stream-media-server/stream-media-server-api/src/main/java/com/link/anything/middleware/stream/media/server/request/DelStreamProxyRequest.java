package com.link.anything.middleware.stream.media.server.request;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Builder
@EqualsAndHashCode(callSuper = true)
@Data
public class DelStreamProxyRequest extends BaseRequest {
  private String key;

}
