package com.link.anything.middleware.stream.media.server.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * zlm hook事件中的on_send_rtp_stopped事件的参数
 * @author lin
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OnSendRtpStoppedHookRequest extends OnHookRequest{

    private String app;
    private String stream;



    @Override
    public String toString() {
        return "OnSendRtpStoppedHookParam{" +
                "app='" + app + '\'' +
                ", stream='" + stream + '\'' +
                '}';
    }
}
