package com.link.anything.middleware.stream.media.server.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class StartRecordRequest extends BaseRequest {

  /**
   * 0为hls，1为mp4	0/1
   */
  private Integer type;

  private String vhost;

  private String app;

  private String stream;
  /**
   * 录像保存目录
   */
  @JsonProperty(value = "customized_path")
  private String customizedPath;
  /**
   * mp4录像切片时间大小,单位秒，置0则采用配置项
   */
  @JsonProperty(value = "max_second")
  private int maxSecond;

}
