package com.link.anything.middleware.stream.media.server.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class StartSendRtpResponse {
  /**
   * #接收端口，方便获取随机端口号
   */
  @JsonProperty(value = "local_port")
  private Integer localPort;

}
