package com.link.anything.middleware.stream.media.server.constant;

/**
 * 简介
 *
 * @author linyuanci
 */
public interface HikvisionStreamType {

    int PRIMARY = 0;
    int SECONDARY = 1;
    int THIRDLY = 2;
}
