package com.link.anything.middleware.stream.media.server.response;

import lombok.Data;

@Data
public class HookStreamNoneReaderResponse {

    private int code;
    private Boolean close;


    public HookStreamNoneReaderResponse() {
    }

    public HookStreamNoneReaderResponse(int code, Boolean close) {
        this.code = code;
        this.close = close;
    }

    public static HookStreamNoneReaderResponse Close(){
        return new HookStreamNoneReaderResponse(0, true);
    }

    public static HookStreamNoneReaderResponse Place(){
        return new HookStreamNoneReaderResponse(0, false);
    }

}
