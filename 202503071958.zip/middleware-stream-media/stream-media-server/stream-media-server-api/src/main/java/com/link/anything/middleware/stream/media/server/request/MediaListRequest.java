package com.link.anything.middleware.stream.media.server.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class MediaListRequest extends BaseRequest {

  /**
   * 筛选协议，例如 rtsp或rtmp
   */
  private String schema;
  /**
   * 筛选虚拟主机
   */
  private String vhost ;
  /**
   * 筛选应用名
   */
  private String app;
  /**
   * 筛选流id
   */
  private String stream;


}
