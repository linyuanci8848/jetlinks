package com.link.anything.middleware.stream.media.server.request;

import lombok.Data;

@Data
public class OnHookRequest {
  private String mediaServerId;
}
