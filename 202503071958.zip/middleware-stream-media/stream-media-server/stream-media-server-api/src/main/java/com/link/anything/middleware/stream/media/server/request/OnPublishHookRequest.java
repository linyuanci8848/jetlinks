package com.link.anything.middleware.stream.media.server.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * zlm hook事件中的on_publish事件的参数
 * @author lin
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OnPublishHookRequest extends OnHookRequest{

    private String id;
    private String app;
    private String stream;
    private String ip;
    private String params;
    private int port;
    private String schema;
    private String vhost;



    @Override
    public String toString() {
        return "OnPublishHookParam{" +
                "id='" + id + '\'' +
                ", app='" + app + '\'' +
                ", stream='" + stream + '\'' +
                ", ip='" + ip + '\'' +
                ", params='" + params + '\'' +
                ", port=" + port +
                ", schema='" + schema + '\'' +
                ", vhost='" + vhost + '\'' +
                '}';
    }
}
