package com.link.anything.middleware.stream.media.server.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class CloseRtpServerRequest extends BaseRequest {

  /**
   * 接收端口，0则为随机端口
   */
  @JsonProperty(value = "stream_id")
  private String streamId;



}
