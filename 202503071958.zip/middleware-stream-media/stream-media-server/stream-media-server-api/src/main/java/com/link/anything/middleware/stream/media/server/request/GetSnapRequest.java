package com.link.anything.middleware.stream.media.server.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Builder
@Data
public class GetSnapRequest extends BaseRequest {

  /**
   * 需要截图的url，可以是本机的，也可以是远程主机的
   */
  private String url;

  /**
   * 截图失败超时时间，防止FFmpeg一直等待截图
   */
  @JsonProperty(value = "timeout_sec")
  private Integer timeoutSec;
  /**
   * 截图的过期时间，该时间内产生的截图都会作为缓存返回
   */
  @JsonProperty(value = "expire_sec")
  private Integer expireSec;

}
