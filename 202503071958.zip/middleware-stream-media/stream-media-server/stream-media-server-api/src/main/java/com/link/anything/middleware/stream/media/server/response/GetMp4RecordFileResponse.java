package com.link.anything.middleware.stream.media.server.response;

import java.util.List;
import lombok.Data;

@Data
public class GetMp4RecordFileResponse {

  private List<String> paths;

  private String rootPath;

}
