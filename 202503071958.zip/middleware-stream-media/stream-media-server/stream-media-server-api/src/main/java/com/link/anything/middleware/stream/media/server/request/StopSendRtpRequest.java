package com.link.anything.middleware.stream.media.server.request;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class StopSendRtpRequest extends BaseRequest{

  /**
   * 筛选虚拟主机
   */
  @Builder.Default
  private String vhost="__defaultVhost__";
  /**
   * 筛选应用名
   */
  private String app;
  /**
   * 筛选流id
   */
  private String stream;

  /**
   * 推流的rtp的ssrc,指定不同的ssrc可以同时推流到多个服务器
   */
  private String ssrc;

}
