package com.link.anything.middleware.stream.media.server.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * zlm hook事件中的on_rtp_server_timeout事件的参数
 * @author lin
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OnRtpServerTimeoutHookRequest  extends OnHookRequest{

    private int local_port;
    private String stream_id;
    private int tcpMode;
    private boolean re_use_port;
    private String ssrc;

    @Override
    public String toString() {
        return "OnRtpServerTimeoutHookParam{" +
                "local_port=" + local_port +
                ", stream_id='" + stream_id + '\'' +
                ", tcpMode=" + tcpMode +
                ", re_use_port=" + re_use_port +
                ", ssrc='" + ssrc + '\'' +
                '}';
    }
}
