package com.link.anything.middleware.stream.media.server.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * zlm hook事件中的on_play事件的参数
 * @author lin
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OnServerKeepAliveHookRequest extends OnHookRequest {

    private ServerKeepAliveData data;



    @Override
    public String toString() {
        return "OnServerKeepAliveHookParam{" +
                "data=" + data +
                '}';
    }
}
