package com.link.anything.middleware.stream.media.server.response;

import lombok.Data;

@Data
public class GetRtpInfoResponse {

  private Integer code;
  /**
   * 是否存在
   */
  private boolean exist;
  /**
   * 推流客户端
   */
  private String peerIp;
  /**
   * 客户端端口号
   */
  private Integer peerPort;
  /**
   * 本地监听的网卡ip
   */
  private String localIp;
  /**
   * 本地监听的网卡ip
   */
  private Integer localPort;

}
