package com.link.anything.middleware.stream.media.server.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class IsRecordingRequest extends BaseRequest {

  /**
   * 0为hls，1为mp4
   */
  private String type;
  /**
   * 筛选虚拟主机
   */
  private String vhost ;
  /**
   * 筛选应用名
   */
  private String app;
  /**
   * 筛选流id
   */
  private String stream;


}
