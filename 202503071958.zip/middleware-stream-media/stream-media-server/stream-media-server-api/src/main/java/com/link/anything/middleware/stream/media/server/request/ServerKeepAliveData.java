package com.link.anything.middleware.stream.media.server.request;

public class ServerKeepAliveData {

  private Integer buffer;
  private Integer bufferLikeString;
  private Integer bufferList;
  private Integer bufferRaw;
  private Integer frame;
  private Integer frameImp;
  private Integer mediaSource;
  private Integer multiMediaSourceMuxer;
  private Integer rtmpPacket;
  private Integer rtpPacket;
  private Integer socket;
  private Integer tcpClient;
  private Integer tcpServer;
  private Integer tcpSession;
  private Integer udpServer;
  private Integer udpSession;

}
