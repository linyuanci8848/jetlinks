package com.link.anything.middleware.stream.media.server.constant;

/**
 * 简介
 *
 * @author linyuanci
 */
public interface HikvisionTransmode {
    int TCP = 1;

    int UDP = 0;
}
