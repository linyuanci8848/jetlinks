package com.link.anything.middleware.stream.media.server.request;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BaseRequest implements Serializable {

  /**
   * 交互秘钥
   */
  private String secret;
}
