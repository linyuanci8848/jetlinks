package com.link.anything.middleware.stream.media.server.response;

import com.link.anything.middleware.stream.media.server.request.BaseRequest;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Builder
@EqualsAndHashCode(callSuper = true)
@Data
public class IsRecordingResponse extends BaseRequest {

  /**
   * 是否成功
   */
  private Boolean status;

}
