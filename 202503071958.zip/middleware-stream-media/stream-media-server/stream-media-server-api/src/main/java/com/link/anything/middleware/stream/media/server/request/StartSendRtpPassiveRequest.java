package com.link.anything.middleware.stream.media.server.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class StartSendRtpPassiveRequest extends BaseRequest{

  /**
   * 筛选虚拟主机
   */
  private String vhost;
  /**
   * 筛选应用名
   */
  private String app;
  /**
   * 筛选流id
   */
  private String stream;

  /**
   * 推流的rtp的ssrc,指定不同的ssrc可以同时推流到多个服务器
   */
  private String ssrc;

  /**
   * 使用的本机端口，为0或不传时默认为随机端口
   */
  @JsonProperty("src_port")
  private Integer srcPort;
  /**
   * 发送时，rtp的pt（uint8_t）,不传时默认为96
   */
  private Integer pt;
  /**
   * 发送时，rtp的负载类型。为1时，负载为ps；为0时，为es；不传时默认为1
   */
  @JsonProperty("usePs")
  private Integer use_ps;

  /**
   * 当use_ps 为0时，有效。为1时，发送音频；为0时，发送视频；不传时默认为0
   */
  @JsonProperty("only_audio")
  private Integer onlyAudio;

}
