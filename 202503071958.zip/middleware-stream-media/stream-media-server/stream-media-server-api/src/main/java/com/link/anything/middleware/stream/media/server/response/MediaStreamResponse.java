package com.link.anything.middleware.stream.media.server.response;

import com.link.anything.middleware.stream.media.common.domain.MediaTrack;
import com.link.anything.middleware.stream.media.common.domain.OriginSock;
import io.swagger.v3.oas.models.security.SecurityScheme.In;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

/**
 * 媒体流信息
 *
 */
@Data
public class MediaStreamResponse implements Serializable {

  /**
   * 应用名称
   */
  private String app;
  /**
   * 本协议观看人数
   */
  private Integer readerCount;
  /**
   * 观看总人数，包括hls/rtsp/rtmp/http-flv/ws-flv
   */
  private Integer totalReaderCount;
  /**
   * 协议
   */
  private String schema;
  /**
   * 流id
   */
  private String stream;

  /**
   * 客户端和服务器网络信息，可能为null类型
   */
  private OriginSock originSock;
  /**
   * 产生源类型，包括 unknown = 0,rtmp_push=1,rtsp_push=2,rtp_push=3,pull=4,ffmpeg_pull=5,mp4_vod=6,device_chn=7
   */
  private Integer originType;
  /**
   * MediaOriginType::rtmp_push
   */
  private String originTypeStr;
  /**
   * 产生源的url
   */
  private String originUrl;
  /**
   * GMT unix系统时间戳，单位秒
   */
  private Integer createStamp;
  /**
   * 存活时间，单位秒
   */
  private Integer aliveSecond;
  /**
   * 数据产生速度，单位byte/s
   */
  private Integer bytesSpeed;
  /**
   * 音视频轨道
   */
  private List<MediaTrack> tracks;
  /**
   * 虚拟主机名
   */
  private String vhost;


}
