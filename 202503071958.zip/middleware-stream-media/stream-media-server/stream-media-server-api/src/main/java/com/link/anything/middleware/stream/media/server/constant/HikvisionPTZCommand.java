package com.link.anything.middleware.stream.media.server.constant;

import com.link.anything.middleware.stream.media.common.domain.PTZStreamControl;

/**
 * 简介
 *
 * @author linyuanci
 */
public enum HikvisionPTZCommand {
    LEFT,
    LEFT_UP,
    LEFT_DOWN,
    RIGHT,
    RIGHT_UP,
    RIGHT_DOWN,
    UP,
    DOWN,
    FOCUS_NEAR, // 焦点前移
    FOCUS_FAR, // 焦点后移
    IRIS_ENLARGE, // 光圈扩大
    IRIS_REDUCE, // 光圈缩小
    WIPER_SWITCH, // 接通雨刷开关
    START_RECORD_TRACK, // 开始记录路线
    STOP_RECORD_TRACK, // 停止记录路线
    START_TRACK, // 开始路线
    STOP_TRACK, // 停止路线
    ZOOM_IN, // 焦距变大
    ZOOM_OUT, // 焦距变小
    GOTO_PRESET; // 到预置点

    public static HikvisionPTZCommand of(PTZStreamControl ptzStreamControl) {
        switch (ptzStreamControl) {
            case Left:
                return LEFT;
            case Right:
                return RIGHT;
            case Up:
                return UP;
            case Down:
                return DOWN;
            case UpLeft:
                return LEFT_UP;
            case UpRight:
                return RIGHT_UP;
            case DownLeft:
                return LEFT_DOWN;
            case DownRight:
                return RIGHT_DOWN;
            case ZooMin:
                return ZOOM_IN;
            case ZoomOut:
                return ZOOM_OUT;
            case Stop:
                return STOP_TRACK;
            default:
                return null;
        }
    }
}
