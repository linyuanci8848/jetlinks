package com.link.anything.middleware.stream.media.server.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class OnServerStartedHookRequest extends OnHookRequest {
//TODO 字段太多了 先用JSON 去搞
}
