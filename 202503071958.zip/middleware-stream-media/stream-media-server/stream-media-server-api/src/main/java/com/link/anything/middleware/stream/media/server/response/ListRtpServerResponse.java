package com.link.anything.middleware.stream.media.server.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ListRtpServerResponse {

  /**
   * #绑定的端口号
   */
  private Integer port;
  /**
   * 绑定的流ID
   */
  @JsonProperty(value = "stream_id")
  private String streamId;


}
