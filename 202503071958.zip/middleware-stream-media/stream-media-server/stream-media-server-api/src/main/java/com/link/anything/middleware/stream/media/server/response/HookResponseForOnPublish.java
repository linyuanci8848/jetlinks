package com.link.anything.middleware.stream.media.server.response;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class HookResponseForOnPublish extends HookResponse {

    private boolean enable_audio;
    private boolean enable_mp4;
    private int mp4_max_second;
    private String mp4_save_path;
    private String stream_replace;

    public HookResponseForOnPublish() {
    }

    public static HookResponseForOnPublish SUCCESS(){
        return new HookResponseForOnPublish(0, "success");
    }

    public HookResponseForOnPublish(int code, String msg) {
        setCode(code);
        setMsg(msg);
    }

    @Override
    public String toString() {
        return "HookResultForOnPublish{" +
                "enable_audio=" + enable_audio +
                ", enable_mp4=" + enable_mp4 +
                ", mp4_max_second=" + mp4_max_second +
                ", mp4_save_path='" + mp4_save_path + '\'' +
                '}';
    }
}
