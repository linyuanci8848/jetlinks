package com.link.anything.middleware.stream.media.server.request;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class DelStreamPusherProxyRequest extends BaseRequest{

  private String key;

}
