package com.link.anything.middleware.stream.media.server.response;

import lombok.Data;

/**
 * ZLMediaKit Restfull 接口响应对象
 * <pre>
 *     Exception = -400,//代码抛异常
 *     InvalidArgs = -300,//参数不合法
 *     SqlFailed = -200,//sql执行失败
 *     AuthFailed = -100,//鉴权失败
 *     OtherFailed = -1,//业务代码执行失败，
 *     Success = 0//执行成功
 *  </pre>
 */
@Data
public class ZLMediaKitResponse {

  /**
   * 代表业务代码执行失败
   */
  private Integer code = 0;
  /**
   * 失败提示
   */
  private String msg = "操作成功";
  /**
   * 业务代码执行失败具体原因
   */
  private Integer result = -1;
  /**
   * 携带数据
   */
  private Object data;

}
