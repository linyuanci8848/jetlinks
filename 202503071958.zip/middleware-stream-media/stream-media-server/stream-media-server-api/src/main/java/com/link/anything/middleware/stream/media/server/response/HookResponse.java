package com.link.anything.middleware.stream.media.server.response;

import lombok.Data;

@Data
public class HookResponse {

    private int code;
    private String msg;


    public HookResponse() {
    }

    public HookResponse(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public static HookResponse SUCCESS(){
        return new HookResponse(0, "success");
    }

    public static HookResponse Fail(){
        return new HookResponse(-1, "fail");
    }
    public static HookResponse Fail(String msg){
        return new HookResponse(-1, msg);
    }
}
