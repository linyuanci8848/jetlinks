package com.link.anything.middleware.stream.media.server.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DelStreamProxyResponse{

  /**
   * 是否成功
   */
  private Boolean flag;

}
