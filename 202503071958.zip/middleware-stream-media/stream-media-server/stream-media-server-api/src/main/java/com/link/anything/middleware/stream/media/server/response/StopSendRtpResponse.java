package com.link.anything.middleware.stream.media.server.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class StopSendRtpResponse {

  private Integer code;

}
