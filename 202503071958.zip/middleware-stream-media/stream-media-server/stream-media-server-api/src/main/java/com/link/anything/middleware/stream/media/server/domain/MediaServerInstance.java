package com.link.anything.middleware.stream.media.server.domain;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDateTime;
import lombok.Data;

@Data
@Schema(description = "流媒体服务实例")
@TableName(value = "media_server_instance", autoResultMap = true)
public class MediaServerInstance {

  @Schema(description = "ZL实例ID")
  private String instanceId;
  @Schema(description = "ID")
  @TableId
  private Long id;

  @Schema(description = "控制IP地址")
  private String controlIp;


  @Schema(description = "流IP地址")
  private String streamIp;


  @Schema(description = "HTTP端口")
  private int httpPort;

  @Schema(description = "HTTPS端口")
  private int httpSslPort;

  @Schema(description = "RTMP端口")
  private int rtmpPort;

  @Schema(description = "RTMPS端口")
  private int rtmpSslPort;

  @Schema(description = "RTP收流端口（单端口模式有用）")
  private int rtpProxyPort;

  @Schema(description = "RTSP端口")
  private int rtspPort;

  @Schema(description = "RTSPS端口")
  @TableField("rtsp_ssl_port")
  private int rtspSsLPort;

  @Schema(description = "ZLM鉴权参数")
  private String secret;

  @Schema(description = "keepalive hook触发间隔,单位秒")
  private Float hookAliveInterval;

  @Schema(description = "是否使用多端口模式")
  private boolean rtpEnable;

  @Schema(description = "多端口RTP收流端口范围")
  private String rtpPortRange;

  @Schema(description = "RTP发流端口范围")
  private String sendRtpPortRange;

  @Schema(description = "assist服务端口")
  private int recordAssistPort;

  @Schema(description = "创建时间")
  private LocalDateTime createTime = LocalDateTime.now();

  @Schema(description = "更新时间")
  private LocalDateTime updateTime = LocalDateTime.now();

  @Schema(description = "控制服务器ID")
  private String controlServerId;

  @Schema(description = "服务器状态")
  private int status = 1;
}
