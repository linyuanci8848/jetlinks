package com.link.anything.middleware.stream.media.server.response;

import lombok.Data;

@Data
public class OpenRtpServerResponse {
  /**
   * #接收端口，方便获取随机端口号
   */
  private Integer port;

}
