package com.link.anything.middleware.stream.media.server.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class AddStreamPusherProxyRequest extends BaseRequest {

  /**
   * 筛选虚拟主机
   */
  private String vhost;
  /**
   * 筛选应用名
   */
  private String app;
  /**
   * 筛选流id
   */
  private String stream;

  /**
   * 推流的rtp的ssrc,指定不同的ssrc可以同时推流到多个服务器
   */
  private String ssrc;

  /**
   * 目标转推url，带参数需要自行url转义
   */
  @JsonProperty("dst_url")
  private String dstUrl;
  /**
   * 转推失败重试次数，默认无限重试
   */
  @JsonProperty("retry_count")
  private Integer retryCount;
  /**
   * rtsp推流时，推流方式，0：tcp，1：udp
   */
  @JsonProperty("rtp_type")
  private Integer rtpType;

  /**
   * 协议，例如 rtsp或rtmp
   */
  private String schema;
  /**
   * 推流超时时间，单位秒，float类型
   */
  @JsonProperty("timeout_sec")
  private Integer timeoutSec;

}
