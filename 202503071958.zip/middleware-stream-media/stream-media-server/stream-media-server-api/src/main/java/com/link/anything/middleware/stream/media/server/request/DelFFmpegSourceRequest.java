package com.link.anything.middleware.stream.media.server.request;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Builder
@EqualsAndHashCode(callSuper = true)
@Data
public class DelFFmpegSourceRequest extends BaseRequest {
  private String key;

}
