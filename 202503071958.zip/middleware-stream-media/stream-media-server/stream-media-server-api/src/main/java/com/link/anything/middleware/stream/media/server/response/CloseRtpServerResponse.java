package com.link.anything.middleware.stream.media.server.response;

import lombok.Data;

@Data
public class CloseRtpServerResponse {
  /**
   * #是否找到记录并关闭
   */
  private Integer hit;

}
