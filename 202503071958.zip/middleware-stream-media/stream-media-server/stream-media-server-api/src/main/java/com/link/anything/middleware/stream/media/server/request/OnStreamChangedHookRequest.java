package com.link.anything.middleware.stream.media.server.request;



import com.link.anything.middleware.stream.media.common.domain.MediaTrack;
import com.link.anything.middleware.stream.media.common.domain.OriginSock;
import com.link.anything.middleware.stream.media.common.domain.StreamContent;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lin
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class OnStreamChangedHookRequest extends OnHookRequest {

  /**
   * 注册/注销
   */
  private boolean regist;

  /**
   * 应用名
   */
  private String app;

  /**
   * 流id
   */
  private String stream;


  /**
   * 观看总人数，包括hls/rtsp/rtmp/http-flv/ws-flv
   */
  private String totalReaderCount;

  /**
   * 协议 包括hls/rtsp/rtmp/http-flv/ws-flv
   */
  private String schema;


  /**
   * 产生源类型， unknown = 0, rtmp_push=1, rtsp_push=2, rtp_push=3, pull=4, ffmpeg_pull=5, mp4_vod=6, device_chn=7
   */
  private int originType;

  /**
   * 客户端和服务器网络信息，可能为null类型
   */
  private OriginSock originSock;

  /**
   * 产生源类型的字符串描述
   */
  private String originTypeStr;

  /**
   * 产生源的url
   */
  private String originUrl;

  /**
   * 服务器id
   */
  private String severId;

  /**
   * GMT unix系统时间戳，单位秒
   */
  private Long createStamp;

  /**
   * 存活时间，单位秒
   */
  private Long aliveSecond;

  /**
   * 数据产生速度，单位byte/s
   */
  private Long bytesSpeed;

  /**
   * 音视频轨道
   */
  private List<MediaTrack> tracks;

  /**
   * 音视频轨道
   */
  private String vhost;

  private StreamContent streamInfo;

  private String callId;
  @Override
  public String toString() {
    return "OnStreamChangedHookParam{" +
        "regist=" + regist +
        ", app='" + app + '\'' +
        ", stream='" + stream + '\'' +
        ", severId='" + severId + '\'' +
        '}';
  }
}
