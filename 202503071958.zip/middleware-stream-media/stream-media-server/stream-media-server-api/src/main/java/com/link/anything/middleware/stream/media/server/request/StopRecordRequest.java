package com.link.anything.middleware.stream.media.server.request;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class StopRecordRequest extends BaseRequest {

  /**
   * 0为hls，1为mp4	0/1
   */
  private Integer type;

  private String vhost;

  private String app;

  private String stream;

}
