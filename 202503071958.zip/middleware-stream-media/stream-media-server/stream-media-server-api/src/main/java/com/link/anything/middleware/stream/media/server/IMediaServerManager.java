package com.link.anything.middleware.stream.media.server;


import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import com.link.anything.middleware.stream.media.server.domain.ZlMediaKitInstanceProperties;
import com.link.anything.middleware.stream.media.server.request.AddStreamProxyRequest;
import com.link.anything.middleware.stream.media.server.request.ServerKeepAliveData;
import com.link.anything.middleware.stream.media.server.request.StartSendRtpRequest;
import com.link.anything.middleware.stream.media.server.request.StopSendRtpRequest;
import com.link.anything.middleware.stream.media.server.response.AddStreamProxyResponse;
import com.link.anything.middleware.stream.media.server.response.MediaStreamResponse;
import java.util.List;

/**
 * 流媒体服务器管理
 */
public interface IMediaServerManager {


  /**
   * 查询所有服务器实例
   *
   * @return
   */
  List<MediaServerInstance> findMediaServerInstances(String controlServerId);

  /**
   * 查询当个流媒体服务实例
   *
   * @param mediaServerId
   * @return
   */
  MediaServerInstance findMediaServerInstance(String mediaServerId);


  /**
   * 新的节点加入
   * <p>必须先主动添加节点 然后等待节点连接过来</p>
   *
   * @param properties
   */
  void join(ZlMediaKitInstanceProperties properties);

  /**
   * 节点上线
   *
   * @param properties
   */
  boolean online(ZlMediaKitInstanceProperties properties);

  /**
   * 节点离线
   *
   * @param mediaServerId
   * @return
   */
  void offline(String mediaServerId);

  /**
   * 获取负载最小的节点
   *
   * @param hasAssist
   * @return
   */
  MediaServerInstance getMediaServerForMinimumLoad(boolean hasAssist);


  /**
   * 重新设置流媒体服务器实例
   *
   * @param instance
   */
  void resetMediaServerInstance(MediaServerInstance instance);

  /**
   * 服务实例保活
   *
   * @param mediaServerId
   * @param data
   */
  void keepAlive(String mediaServerId, ServerKeepAliveData data);

  /**
   * 重置所有流媒体服务器实例
   */
  void clearMediaServerForOnline();

  /**
   * 打开RTP服务器 用于接收 RTP流  这里只能用 随机端口 这样才能使用自定义streamId
   *
   * @param instance
   * @param streamId
   * @param port
   * @param method
   */
  int openRTPServer(MediaServerInstance instance, String streamId, Integer port, StreamTransferMethod method);


  /**
   * 关闭RTP服务
   *
   * @param instance
   * @param streamId
   */
  void closeRTPServer(String instance, String streamId);


  /**
   * 获取所有媒体流信息
   *
   * @param instance
   * @param schema
   * @param vhost
   * @param app
   * @param stream
   * @return
   */
  public List<MediaStreamResponse> getMediaList(MediaServerInstance instance, String schema, String vhost, String app, String stream);

  /**
   * 启动主动推流
   *
   * @param instance
   * @param request
   * @return
   */
  public Integer startSendRtp(MediaServerInstance instance, StartSendRtpRequest request);

  /**
   * 关闭推流
   * @param instance
   * @param request
   */
  public boolean stopSendRtp(MediaServerInstance instance, StopSendRtpRequest request);
  /**
   * 查询流是否就绪
   *
   * @param mediaServerItem
   * @param app
   * @param streamId
   * @return
   */
  public Boolean isStreamReady(MediaServerInstance mediaServerItem, String app, String streamId);

  /**
   * 添加流代理
   * @param instance
   * @param request
   * @return
   */
  public String addStreamProxy(MediaServerInstance instance, AddStreamProxyRequest request);

  /**
   * 删除流代理
   * @param instance
   * @param key addStreamProxy接口返回的key
   * @return
   */
  public boolean delStreamProxy(MediaServerInstance instance, String key);

  /**
   * 删除流代理
   *
   * @param instanceId
   * @param key addStreamProxy接口返回的key
   */
  boolean delStreamProxy(String instanceId, String key);
}
