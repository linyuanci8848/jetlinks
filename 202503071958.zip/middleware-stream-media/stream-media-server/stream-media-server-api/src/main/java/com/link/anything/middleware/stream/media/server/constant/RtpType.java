package com.link.anything.middleware.stream.media.server.constant;

/**
 * 简介
 *
 * @author linyuanci
 */
public interface RtpType {
    int TCP = 0;

    int UDP = 1;
}
