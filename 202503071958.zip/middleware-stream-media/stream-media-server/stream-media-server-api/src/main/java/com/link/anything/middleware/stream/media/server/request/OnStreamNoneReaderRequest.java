package com.link.anything.middleware.stream.media.server.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class OnStreamNoneReaderRequest extends OnHookRequest {

  /**
   * 流应用名
   */
  private String app;
  /**
   * rtsp或rtmp
   */
  private String schema;
  /**
   * 流ID
   */
  private String stream;
  /**
   * 流虚拟主机
   */
  private String vhost;


}
