package com.link.anything.middleware.stream.media.server.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class OnStreamNoneReaderHookRequest extends OnHookRequest{

    private String schema;
    private String app;
    private String stream;
    private String vhost;


    @Override
    public String toString() {
        return "OnStreamNoneReaderHookParam{" +
                "schema='" + schema + '\'' +
                ", app='" + app + '\'' +
                ", stream='" + stream + '\'' +
                ", vhost='" + vhost + '\'' +
                '}';
    }
}
