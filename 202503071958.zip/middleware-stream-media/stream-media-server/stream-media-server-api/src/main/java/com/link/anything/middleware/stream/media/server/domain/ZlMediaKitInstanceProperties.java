package com.link.anything.middleware.stream.media.server.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;

/**
 * 实际ZlMediaKit 服务器的配置
 */
@Data
@Getter
public class ZlMediaKitInstanceProperties {

  @JsonProperty("api.apiDebug")
  private String apiDebug;

  @JsonProperty("api.secret")
  private String apiSecret;

  @JsonProperty("api.snapRoot")
  private String apiSnapRoot;

  @JsonProperty("api.defaultSnap")
  private String apiDefaultSnap;

  @JsonProperty("ffmpeg.bin")
  private String ffmpegBin;

  @JsonProperty("ffmpeg.cmd")
  private String ffmpegCmd;

  @JsonProperty("ffmpeg.snap")
  private String ffmpegSnap;

  @JsonProperty("ffmpeg.log")
  private String ffmpegLog;

  @JsonProperty("ffmpeg.restart_sec")
  private String ffmpegRestartSec;

  @JsonProperty("protocol.modify_stamp")
  private String protocolModifyStamp;

  @JsonProperty("protocol.enable_audio")
  private String protocolEnableAudio;

  @JsonProperty("protocol.add_mute_audio")
  private String protocolAddMuteAudio;

  @JsonProperty("protocol.continue_push_ms")
  private String protocolContinuePushMs;

  @JsonProperty("protocol.enable_hls")
  private String protocolEnableHls;

  @JsonProperty("protocol.enable_mp4")
  private String protocolEnableMp4;

  @JsonProperty("protocol.enable_rtsp")
  private String protocolEnableRtsp;

  @JsonProperty("protocol.enable_rtmp")
  private String protocolEnableRtmp;

  @JsonProperty("protocol.enable_ts")
  private String protocolEnableTs;

  @JsonProperty("protocol.enable_fmp4")
  private String protocolEnableFmp4;

  @JsonProperty("protocol.mp4_as_player")
  private String protocolMp4AsPlayer;

  @JsonProperty("protocol.mp4_max_second")
  private String protocolMp4MaxSecond;

  @JsonProperty("protocol.mp4_save_path")
  private String protocolMp4SavePath;

  @JsonProperty("protocol.hls_save_path")
  private String protocolHlsSavePath;

  @JsonProperty("protocol.hls_demand")
  private String protocolHlsDemand;

  @JsonProperty("protocol.rtsp_demand")
  private String protocolRtspDemand;

  @JsonProperty("protocol.rtmp_demand")
  private String protocolRtmpDemand;

  @JsonProperty("protocol.ts_demand")
  private String protocolTsDemand;

  @JsonProperty("protocol.fmp4_demand")
  private String protocolFmp4Demand;

  @JsonProperty("general.enableVhost")
  private String generalEnableVhost;

  @JsonProperty("general.flowThreshold")
  private String generalFlowThreshold;

  @JsonProperty("general.maxStreamWaitMS")
  private String generalMaxStreamWaitMS;

  @JsonProperty("general.streamNoneReaderDelayMS")
  private int generalStreamNoneReaderDelayMS;

  @JsonProperty("general.resetWhenRePlay")
  private String generalResetWhenRePlay;

  @JsonProperty("general.mergeWriteMS")
  private String generalMergeWriteMS;

  @JsonProperty("general.mediaServerId")
  private String generalMediaServerId;

  @JsonProperty("general.wait_track_ready_ms")
  private String generalWaitTrackReadyMs;

  @JsonProperty("general.wait_add_track_ms")
  private String generalWaitAddTrackMs;

  @JsonProperty("general.unready_frame_cache")
  private String generalUnreadyFrameCache;


  @JsonProperty("ip")
  private String ip;

  private String sdpIp;

  private String streamIp;

  private String hookIp;

  private String updateTime;

  private String createTime;

  @JsonProperty("hls.fileBufSize")
  private String hlsFileBufSize;

  @JsonProperty("hls.filePath")
  private String hlsFilePath;

  @JsonProperty("hls.segDur")
  private String hlsSegDur;

  @JsonProperty("hls.segNum")
  private String hlsSegNum;

  @JsonProperty("hls.segRetain")
  private String hlsSegRetain;

  @JsonProperty("hls.broadcastRecordTs")
  private String hlsBroadcastRecordTs;

  @JsonProperty("hls.deleteDelaySec")
  private String hlsDeleteDelaySec;

  @JsonProperty("hls.segKeep")
  private String hlsSegKeep;

  @JsonProperty("hook.access_file_except_hls")
  private String hookAccessFileExceptHLS;

  @JsonProperty("hook.admin_params")
  private String hookAdminParams;

  @JsonProperty("hook.alive_interval")
  private Float hookAliveInterval;

  @JsonProperty("hook.enable")
  private String hookEnable;

  @JsonProperty("hook.on_flow_report")
  private String hookOnFlowReport;

  @JsonProperty("hook.on_http_access")
  private String hookOnHttpAccess;

  @JsonProperty("hook.on_play")
  private String hookOnPlay;

  @JsonProperty("hook.on_publish")
  private String hookOnPublish;

  @JsonProperty("hook.on_record_mp4")
  private String hookOnRecordMp4;

  @JsonProperty("hook.on_rtsp_auth")
  private String hookOnRtspAuth;

  @JsonProperty("hook.on_rtsp_realm")
  private String hookOnRtspRealm;

  @JsonProperty("hook.on_shell_login")
  private String hookOnShellLogin;

  @JsonProperty("hook.on_stream_changed")
  private String hookOnStreamChanged;

  @JsonProperty("hook.on_stream_none_reader")
  private String hookOnStreamNoneReader;

  @JsonProperty("hook.on_stream_not_found")
  private String hookOnStreamNotFound;

  @JsonProperty("hook.on_server_started")
  private String hookOnServerStarted;

  @JsonProperty("hook.on_server_keepalive")
  private String hookOnServerKeepalive;

  @JsonProperty("hook.on_send_rtp_stopped")
  private String hookOnSendRtpStopped;

  @JsonProperty("hook.on_rtp_server_timeout")
  private String hookOnRtpServerTimeout;

  @JsonProperty("hook.timeoutSec")
  private String hookTimeoutSec;

  @JsonProperty("http.charSet")
  private String httpCharSet;

  @JsonProperty("http.keepAliveSecond")
  private String httpKeepAliveSecond;

  @JsonProperty("http.maxReqCount")
  private String httpMaxReqCount;

  @JsonProperty("http.maxReqSize")
  private String httpMaxReqSize;

  @JsonProperty("http.notFound")
  private String httpNotFound;

  @JsonProperty("http.port")
  private int httpPort;

  @JsonProperty("http.rootPath")
  private String httpRootPath;

  @JsonProperty("http.sendBufSize")
  private String httpSendBufSize;

  @JsonProperty("http.sslport")
  private int httpSSLport;

  @JsonProperty("multicast.addrMax")
  private String multicastAddrMax;

  @JsonProperty("multicast.addrMin")
  private String multicastAddrMin;

  @JsonProperty("multicast.udpTTL")
  private String multicastUdpTTL;

  @JsonProperty("record.appName")
  private String recordAppName;

  @JsonProperty("record.filePath")
  private String recordFilePath;

  @JsonProperty("record.fileSecond")
  private String recordFileSecond;

  @JsonProperty("record.sampleMS")
  private String recordFileSampleMS;

  @JsonProperty("rtmp.handshakeSecond")
  private String rtmpHandshakeSecond;

  @JsonProperty("rtmp.keepAliveSecond")
  private String rtmpKeepAliveSecond;

  @JsonProperty("rtmp.modifyStamp")
  private String rtmpModifyStamp;

  @JsonProperty("rtmp.port")
  private int rtmpPort;

  @JsonProperty("rtmp.sslport")
  private int rtmpSslPort;

  @JsonProperty("rtp.audioMtuSize")
  private String rtpAudioMtuSize;

  @JsonProperty("rtp.clearCount")
  private String rtpClearCount;

  @JsonProperty("rtp.cycleMS")
  private String rtpCycleMS;

  @JsonProperty("rtp.maxRtpCount")
  private String rtpMaxRtpCount;

  @JsonProperty("rtp.videoMtuSize")
  private String rtpVideoMtuSize;

  @JsonProperty("rtp_proxy.checkSource")
  private String rtpProxyCheckSource;

  @JsonProperty("rtp_proxy.dumpDir")
  private String rtpProxyDumpDir;

  @JsonProperty("rtp_proxy.port")
  private int rtpProxyPort;

  @JsonProperty("rtp_proxy.port_range")
  private String portRange;

  @JsonProperty("rtp_proxy.timeoutSec")
  private String rtpProxyTimeoutSec;

  @JsonProperty("rtsp.authBasic")
  private String rtspAuthBasic;

  @JsonProperty("rtsp.handshakeSecond")
  private String rtspHandshakeSecond;

  @JsonProperty("rtsp.keepAliveSecond")
  private String rtspKeepAliveSecond;

  @JsonProperty("rtsp.port")
  private int rtspPort;

  @JsonProperty("rtsp.sslport")
  private int rtspSSlport;

  @JsonProperty("shell.maxReqSize")
  private String shellMaxReqSize;

  @JsonProperty("shell.shell")
  private String shellPhell;


}
