package com.link.anything.middleware.stream.media.server.response;

import lombok.Data;

@Data
public class AddFFmpegResponse {

  private String key;

}
