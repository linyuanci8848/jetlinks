package com.link.anything.middleware.stream.media.sdk;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.junit.jupiter.api.Test;

class StreamMediaClientTest {

  @Test
  void init() throws InterruptedException {
    String deviceChannels = StreamMediaClient.synchronizeChannel("http://61.147.246.9:8081/stream/control", "aInDdmwPAK5mRkCl");
    System.out.println(deviceChannels);
  }

}