package com.link.anything.middleware.stream.media.sdk;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StreamMediaClient {


  protected static String secret = "aInDdmwPAK5mRkCl";
  protected static String deviceChannelUrl = "/sdk/device/channel";


  public static String synchronizeChannel(String host, String secret) {
    try {
      URL url = new URL(host + deviceChannelUrl);
      HttpURLConnection con = (HttpURLConnection) url.openConnection();
      con.setRequestMethod("POST");
      try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
        String inputLine;
        StringBuffer content = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
          content.append(inputLine);
        }
        String data = content.toString();
        if (!data.isEmpty()) {
          data = new String(decrypt(data.getBytes(StandardCharsets.UTF_8), secret), StandardCharsets.UTF_8);
        }
        return data;
      } catch (Exception e) {
        throw new SynchronizeChannelException(e.getMessage(), e);
      }
    } catch (Exception e) {
      throw new SynchronizeChannelException(e.getMessage(), e);
    }
  }


  public static byte[] decrypt(byte[] source, String password) {
    try {
      byte[] key = password.getBytes(StandardCharsets.UTF_8);
      key = Arrays.copyOf(key, 16);
      SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
      cipher.init(2, secretKey);
      return cipher.doFinal(Base64.getDecoder().decode(source));
    } catch (Exception var5) {
      throw new SecurityException("AES 解密异常：" + var5.getLocalizedMessage(), var5);
    }
  }
}
