package com.link.anything.middleware.stream.media.sdk;

/**
 * 同步通道异常
 */
public class SynchronizeChannelException extends RuntimeException{

  public SynchronizeChannelException() {
  }

  public SynchronizeChannelException(String message) {
    super(message);
  }

  public SynchronizeChannelException(String message, Throwable cause) {
    super(message, cause);
  }
}
