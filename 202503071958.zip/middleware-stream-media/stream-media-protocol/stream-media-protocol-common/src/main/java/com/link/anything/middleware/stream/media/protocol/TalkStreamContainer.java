package com.link.anything.middleware.stream.media.protocol;


import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.GlobalDefinitionRedisKey;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.protocol.codec.AudioCodec;
import com.link.anything.middleware.stream.media.protocol.entity.AudioInfo;
import com.link.anything.middleware.stream.media.protocol.entity.MediaEncoding;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.AttributeKey;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.annotation.Resource;
import javax.websocket.CloseReason;
import javax.websocket.CloseReason.CloseCodes;
import javax.websocket.Session;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;

/**
 * 对讲流容器.
 */
@Slf4j
@Component
public class TalkStreamContainer {

  @Resource
  private SubscribeManager subscribeManager;
  /**
   * WEB会话缓存MAP.
   */
  private static final Map<String, Session> sessionMap = new ConcurrentHashMap<>();
  /**
   * TCP会话缓存.
   */
  private static final Map<String, ChannelHandlerContext> contentMap = new ConcurrentHashMap<>();
  /**
   * 待加入的用户端
   */
  private static final List<String> streamLinkUserTerminalJoinList = new CopyOnWriteArrayList<>();

  private static final AttributeKey<AudioCodec> AUDIOCODECKEY = AttributeKey.valueOf("audio-codec-key");

  private static final AttributeKey<Boolean> HAISIKEY = AttributeKey.valueOf("haisi-key");

  @Resource
  private RedissonClient redissonClient;

  /**
   * 标记这个设备是等待连接防止非法连接
   *
   * @param device
   * @param channel
   */
  public void markUserTerminal(String device, String channel) {
    streamLinkUserTerminalJoinList.add(device.concat("_").concat(channel));
  }

  /**
   * 移除标记
   *
   * @param device
   * @param channel
   */
  public void removeMarkUserTerminal(String device, String channel) {
    streamLinkUserTerminalJoinList.remove(device.concat("_").concat(channel));
  }

  public void join(String device, String channel, Session session) {
    if (!streamLinkUserTerminalJoinList.contains(device.concat("_").concat(channel))) {
      kick(device, channel);
    }
    streamLinkUserTerminalJoinList.remove(device.concat("_").concat(channel));
    sessionMap.put(device.concat("_").concat(channel), session);
    log.info("语音对讲用户端连接建立: {}-{}", device, channel);
    subscribeManager.publish(StreamDefinitionEventKey.TalkStreamLinkUserTerminalJoin + device + "_" + channel, null);
  }

  public void kick(String device, String channel) {
    RLock lock = redissonClient.getLock(GlobalDefinitionRedisKey.LOCK_KEY_AUDIO_STREAM + "_" + device + "_" + channel);
    try {
      Session session = sessionMap.remove(device.concat("_").concat(channel));
      if (session != null) {
        session.close(new CloseReason(CloseCodes.NORMAL_CLOSURE, ""));
        log.info("语音对讲用户端连接关闭: {}-{}", device, channel);
      }
      ChannelHandlerContext context = contentMap.remove(device.concat("_").concat(channel));
      if (context != null) {
       context.close();
        log.info("语音对讲设备端连接关闭: {}-{}", device, channel);
      }
    } catch (Exception e) {
      log.info("关闭对讲失败", e);
    } finally {
      if (lock != null && lock.isLocked()) {
        lock.forceUnlock();
      }
    }
  }

  public void join(String device, String channel, ChannelHandlerContext context) {
    String key = device.concat("_").concat(channel);
    contentMap.put(key, context);
    log.info("语音对讲设备端连接建立: {}-{}", device, channel);
    subscribeManager.publish(StreamDefinitionEventKey.TalkStreamRegister + device.concat("_").concat(channel), null);
  }


  public void downRedirect(String device, String channel,Integer squeue, Integer time,byte[] data) {
    String key = device.concat("_").concat(channel);
    ChannelHandlerContext context = contentMap.get(key);

    AudioCodec audioCodec;
    if (context.channel().hasAttr(AUDIOCODECKEY)){
      audioCodec = context.channel().attr(AUDIOCODECKEY).get();
    } else {
      // 默认G711A
      audioCodec = AudioCodec.getCodec(MediaEncoding.Encoding.G711A.ordinal());
    }

    byte[] output;
    byte[] translatedData = audioCodec.fromPCM(data);
    if (!isHISI(data) && context.channel().hasAttr(HAISIKEY) && context.channel().attr(HAISIKEY).get()) {
      output = new byte[translatedData.length + 4];
      output[0] = 0x00;
      output[1] = 0x01;
      output[2] = (byte)(translatedData.length / 2);
      output[3] = 0x00;
      System.arraycopy(translatedData, 0, output, 4, translatedData.length);
    } else {
      output = translatedData;
    }
    AudioInfo audioInfo = AudioInfo.builder()
            .simNo(device)
            .channelNo(Integer.valueOf(channel))
            .data(output)
            .sequence(squeue)
            .timeStamp(Long.valueOf(time))
            .build();
    context.writeAndFlush(audioInfo).addListener(future -> {
      if (!future.isSuccess()) {
        log.error("[device:{}]语音对讲下发失败：{}", device, future.cause().getMessage());
      }
    });
  }

  public void upRedirect(String device, String channel, byte[] data) {
    try {
      Session context = sessionMap.get(device.concat("_").concat(channel));
      if (context != null) {
        if (context.isOpen()) {
          //System.out.println("UP:"+ ByteBufUtil.hexDump(data));
          context.getBasicRemote().sendBinary(ByteBuffer.wrap(data));
        }
      } else {
        log.warn("语音对讲设备端连接已建立但用户端未建立:{}-{},将关闭链路", device, channel);
        this.kick(device, channel);
      }
    } catch (Exception e) {
      log.error(e.getMessage(), e);

    }
  }

  private boolean isHISI(byte[] data) {
    return data[0] == 0x00 && data[1] == 0x01 && (data[2] & 0xff) == (data.length - 4) / 2 && data[3] == 0x00;
  }

}
