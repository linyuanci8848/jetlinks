package com.link.anything.middleware.stream.media.protocol;

import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;

/**
 * 协议执行对象工厂
 */
@Component
public class ProtocolExecutorProvider {

  @Resource
  private ApplicationContext applicationContext;


  public IProtocolExecutor getProtocolExecutor(StreamSourceProtocol sourceProtocol) {
    Map<String, Object> protocolExecutors = applicationContext.getBeansWithAnnotation(ProtocolExecutor.class);
    for (Object object : protocolExecutors.values()) {
      ProtocolExecutor protocolExecutor = AnnotationUtils.findAnnotation(object.getClass(), ProtocolExecutor.class);
      if (sourceProtocol.equals(protocolExecutor.value())) {
        return (IProtocolExecutor) object;
      }
    }
    return null;
  }

  /**
   * 获取所有协议解析类
   *
   * @return
   */
  public List<IProtocolExecutor> getAll() {
    Map<String, Object> protocolExecutors = applicationContext.getBeansWithAnnotation(ProtocolExecutor.class);
    return protocolExecutors.values().stream().map(item -> (IProtocolExecutor) item).collect(Collectors.toList());
  }
}
