package com.link.anything.middleware.stream.media.protocol.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AudioInfo {
    /** 负载类型 */
    private Integer loadType;

    /** 时间戳 */
    private Long timeStamp;

    /** 序号 */
    private Integer sequence;

    /** sim卡号 */
    private String simNo;

    /** 通道号 */
    private Integer channelNo;

    /** 由pcm转换好的音频数据 */
    private byte[] data;
}
