package com.link.anything.middleware.stream.media.protocol;

import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamPlayType;
import com.link.anything.middleware.stream.media.common.domain.PTZStreamControl;
import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import org.springframework.core.io.Resource;

import javax.sip.InvalidArgumentException;
import javax.sip.SipException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.List;

public interface IProtocolExecutor {

  /**
   * 开启直播流
   *
   * @param deviceNumber
   * @param channel
   * @param bitStream
   * @param streamSourceProtocol
   * @param streamTransferMethod
   * @param instance
   * @return
   */
  public StreamSession openLive(String deviceNumber, String channel, Integer bitStream, StreamSourceProtocol streamSourceProtocol, StreamTransferMethod streamTransferMethod,
      MediaServerInstance instance);

  /**
   * 控制直播流
   *
   * @param streamSession
   * @param control
   */
  public void controlLiveStream(StreamSession streamSession, LiveStreamControl control);


  /**
   * 查询设备历史视频
   *
   * @param deviceNumber
   * @param channel
   * @param sourceType
   * @param start
   * @param end
   * @param type
   * @param bitStream
   * @param source
   * @param sq           查询流水号
   * @return
   */
  public List<VideoFragment> findVideoHistory(String deviceNumber, String channel, StreamSourceProtocol sourceType, LocalDateTime start, LocalDateTime end, StreamType type, Integer bitStream,
                                              HistoryVideoSource source, Long sq);


  /**
   * 打开历史视频流
   *
   * @param fragment
   * @param instance
   * @param playType
   * @param multiple
   */
  public StreamSession openHistoryStream(VideoFragment fragment, MediaServerInstance instance, StreamTransferMethod method, HistoryStreamPlayType playType, Integer multiple);


  /**
   * 控制点播流
   *
   * @param session  会话
   * @param control  控制指令
   * @param multiple 倍数
   * @param point    拖动点位
   */
  public void controlHistoryStream(StreamSession session, HistoryStreamControl control, Integer multiple, Long point);

  /**
   * 创建对讲流
   *
   * @param device
   * @param channel
   */
  public void createTalkStream(String device, String channel);



  /**
   * 同步设备通道
   */
  public void syncDeviceChannel();


  /**
   * 云台控制
   *
   * @param session
   * @param control
   * @param horizonSpeed
   * @param zoomSpeed
   * @param verticalSpeed
   */
  public void controlPTZStream(StreamSession session, PTZStreamControl control, Integer horizonSpeed, Integer zoomSpeed, Integer verticalSpeed);

  default Resource captureAsResource(String channelNo) throws MalformedURLException, InvalidArgumentException, ParseException, SipException, InterruptedException {
    throw new UnsupportedOperationException("暂时不支持");
  };
}
