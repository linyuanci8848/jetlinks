package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.notify.cmd;

import com.link.anything.middleware.stream.media.common.DynamicTask;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.gb28181.common.VideoManagerConstants;
import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.GB28181TranslationProperties;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.RemoteAddressInfo;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.notify.NotifyMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.SipUtils;
import com.link.anything.middleware.stream.media.protocol.gb28181.utils.DateUtil;
import gov.nist.javax.sip.message.SIPRequest;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.header.ViaHeader;
import javax.sip.message.Response;

import org.apache.commons.lang3.ObjectUtils;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * 状态信息(心跳)报送
 */
@Component
public class KeepaliveNotifyMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

    private final static Logger logger = LoggerFactory.getLogger(KeepaliveNotifyMessageHandler.class);
    private final static String cmdType = "Keepalive";

    @Resource
    private NotifyMessageHandler notifyMessageHandler;

    @Resource
    private IDeviceManager deviceManager;

    @Resource
    private GB28181TranslationProperties gb28181TranslationProperties;

    @Resource
    private DynamicTask dynamicTask;

    @Override
    public void afterPropertiesSet() throws Exception {
        notifyMessageHandler.addHandler(cmdType, this);
    }

    @Override
    public void handForDevice(RequestEvent evt, Device device, Element element) {
        if (device == null) {
            // 未注册的设备不做处理
            return;
        }
        SIPRequest request = (SIPRequest) evt.getRequest();
        logger.debug("[收到心跳]， device: {}, callId: {}", device.getTerminalNumber(), request.getCallIdHeader().getCallId());

        // 回复200 OK
        try {
            responseAck(request, Response.OK);
        } catch (SipException | InvalidArgumentException | ParseException e) {
            logger.error("[命令发送失败] 心跳回复: {}", e.getMessage());
        }
        if (!ObjectUtils.isEmpty(device.getKeepaliveTime()) && DateUtil.getDifferenceForNow(device.getKeepaliveTime()) <= 3000L) {
            logger.debug("[收到心跳] 心跳发送过于频繁，已忽略 device: {}, callId: {}", device.getTerminalNumber(), request.getCallIdHeader().getCallId());
            return;
        }
        RemoteAddressInfo remoteAddressInfo = SipUtils.getRemoteAddressFromRequest(request, gb28181TranslationProperties.getSipUseSourceIpAsRemoteAddress());
        if (!device.getIp().equalsIgnoreCase(remoteAddressInfo.getIp()) || device.getPort() != remoteAddressInfo.getPort()) {
            logger.info("[心跳] 设备{}地址变化, 远程地址为: {}:{}", device.getTerminalNumber(), remoteAddressInfo.getIp(), remoteAddressInfo.getPort());
            device.setPort(remoteAddressInfo.getPort());
            device.setHostAddress(remoteAddressInfo.getIp().concat(":").concat(String.valueOf(remoteAddressInfo.getPort())));
            device.setIp(remoteAddressInfo.getIp());
        }
        long lastTime = device.getKeepaliveTime().toEpochSecond(ZoneOffset.ofHours(8));
        if (System.currentTimeMillis() / 1000 - lastTime > 10) {
            device.setKeepaliveIntervalTime(Long.valueOf(System.currentTimeMillis() / 1000 - lastTime).intValue());
        }
        ViaHeader reqViaHeader = (ViaHeader) request.getHeader(ViaHeader.NAME);
        String transport = reqViaHeader.getTransport();
        device.setTransport("TCP".equalsIgnoreCase(transport) ? "TCP" : "UDP");
        device.setStreamMode(device.getTransport());
        device.setKeepaliveTime(LocalDateTime.now());
        //心跳过来直接更新设备信息
        deviceManager.updateDevice(device);
        if (!deviceManager.isOnline(device.getTerminalNumber())) {
            //如果设备离线但是心跳过来了就把设备上线
            device.setSipTransactionInfo(null);
            device.setProtocol(StreamSourceProtocol.GB28181);
            deviceManager.online(device);
        }
        // 开启心跳监测，如果超过 3 次心跳时间都没有收到心跳数据就把设备弄成离线
        String registerExpireTaskKey = VideoManagerConstants.REGISTER_EXPIRE_TASK_KEY_PREFIX + device.getTerminalNumber();
        // 如果三次心跳失败，则设置设备离线
        dynamicTask.startDelay(registerExpireTaskKey, () -> {
            logger.warn("三次心跳失败{}", device);
            deviceManager.offline(device.getTerminalNumber());
        }, device.getKeepaliveIntervalTime() * 1000 * 3);
    }

    @Override
    public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element element) {
        // 个别平台保活不回复200OK会判定离线
        try {
            responseAck((SIPRequest) evt.getRequest(), Response.OK);
        } catch (SipException | InvalidArgumentException | ParseException e) {
            logger.error("[命令发送失败] 心跳回复: {}", e.getMessage());
        }
    }
}
