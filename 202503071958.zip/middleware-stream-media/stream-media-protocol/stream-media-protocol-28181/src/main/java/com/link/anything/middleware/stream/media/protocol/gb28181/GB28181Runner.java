package com.link.anything.middleware.stream.media.protocol.gb28181;

import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import javax.annotation.Resource;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * 注册事件监听
 */
@Component
public class GB28181Runner implements CommandLineRunner {

  @Resource
  private SubscribeManager subscribeManager;


  @Resource
  private SSRCManager ssrcManager;

  @Resource
  private IStreamSessionManager streamSessionManager;

  @Override
  public void run(String... args) {
    //注册流媒体服务器启动处理事件
    subscribeManager.subscribe(StreamDefinitionEventKey.MediaServerStart.toString(), mediaServerId -> {
      ssrcManager.reset(mediaServerId.toString());
    });
    //注册流媒体服务器关闭事件
    subscribeManager.subscribe(StreamDefinitionEventKey.MediaServerStop.toString(), mediaServerId -> {
      streamSessionManager.clear();
    });
  }
}
