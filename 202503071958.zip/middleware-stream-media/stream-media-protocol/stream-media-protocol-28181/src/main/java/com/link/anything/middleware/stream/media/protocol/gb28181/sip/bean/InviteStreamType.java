package com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean;

public enum InviteStreamType {

    PLAY,PLAYBACK,DOWNLOAD,PUSH,PROXY,CLOUD_RECORD_PUSH,CLOUD_RECORD_PROXY


}
