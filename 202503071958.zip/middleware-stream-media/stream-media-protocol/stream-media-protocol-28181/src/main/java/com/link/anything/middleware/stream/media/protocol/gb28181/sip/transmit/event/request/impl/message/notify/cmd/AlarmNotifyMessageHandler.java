package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.notify.cmd;

import static com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil.getText;

import com.alibaba.fastjson2.JSON;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.GB28181TranslationProperties;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.AlarmChannelMessage;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.DeviceAlarm;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.DeviceAlarmMethod;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.SipMsgInfo;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.EventPublisher;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.notify.NotifyMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.NumericUtil;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil;
import com.link.anything.middleware.stream.media.protocol.gb28181.utils.DateUtil;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.message.Response;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

/**
 * 报警事件的处理，参考：9.4
 */
@Component
public class AlarmNotifyMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

  private final Logger logger = LoggerFactory.getLogger(AlarmNotifyMessageHandler.class);
  private final String cmdType = "Alarm";

  @Resource
  private NotifyMessageHandler notifyMessageHandler;

  @Resource
  private EventPublisher publisher;

  private volatile boolean isHandling = false;

  private final ConcurrentLinkedQueue<SipMsgInfo> taskQueue = new ConcurrentLinkedQueue<>();

  @Qualifier("taskExecutor")
  @Resource
  private ThreadPoolTaskExecutor taskExecutor;

  @Resource
  private IDeviceManager deviceManager;

  @Resource
  private GB28181TranslationProperties gb28181TranslationProperties;
  @Override
  public void afterPropertiesSet() throws Exception {
    notifyMessageHandler.addHandler(cmdType, this);
  }

  @Override
  public void handForDevice(RequestEvent evt, Device device, Element rootElement) {
    // 回复200 OK
    try {
      responseAck((SIPRequest) evt.getRequest(), Response.OK);
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[命令发送失败] 报警通知回复: {}", e.getMessage());
    }

    if (!gb28181TranslationProperties.getAlarm()) {
      return;
    }

    logger.debug("[收到报警通知]设备：{}", device.getTerminalNumber());
    taskQueue.offer(new SipMsgInfo(evt, device, rootElement));

    synchronized (this) {
      if (isHandling) {
        return;
      }
      isHandling = true;
    }

    taskExecutor.execute(() -> {
      logger.debug("[处理报警通知]待处理数量：{}", taskQueue.size());

      SipMsgInfo sipMsgInfo;
      while ((sipMsgInfo = taskQueue.poll()) != null) {
        try {
          String alarmTime = XmlUtil.getText(sipMsgInfo.getRootElement(), "AlarmTime");
          if (alarmTime == null) {
            continue;
          }

          Element deviceIdElement = sipMsgInfo.getRootElement().element("DeviceID");

          String alarmDescription = getText(sipMsgInfo.getRootElement(), "AlarmDescription");
          if (alarmDescription == null) {
            alarmDescription = "";
          }

          double longitude = 0.00;
          String longitudeStr = getText(sipMsgInfo.getRootElement(), "Longitude");
          if (longitudeStr != null && NumericUtil.isDouble(longitudeStr)) {
            longitude = Double.parseDouble(longitudeStr);
          }

          double latitude = 0.00;
          String latitudeStr = getText(sipMsgInfo.getRootElement(), "Latitude");
          if (latitudeStr != null && NumericUtil.isDouble(latitudeStr)) {
            latitude = Double.parseDouble(latitudeStr);
          }

          DeviceAlarm deviceAlarm = new DeviceAlarm();
          deviceAlarm.setCreateTime(DateUtil.getNow());
          deviceAlarm.setDeviceId(sipMsgInfo.getDevice().getTerminalNumber());
          deviceAlarm.setChannelId(deviceIdElement.getText());
          deviceAlarm.setAlarmPriority(getText(sipMsgInfo.getRootElement(), "AlarmPriority"));
          deviceAlarm.setAlarmMethod(getText(sipMsgInfo.getRootElement(), "AlarmMethod"));
          deviceAlarm.setAlarmTime(DateUtil.ISO8601Toyyyy_MM_dd_HH_mm_ss(alarmTime));
          deviceAlarm.setAlarmDescription(alarmDescription);
          deviceAlarm.setLongitude(longitude);
          deviceAlarm.setLatitude(latitude);

          /* 代码并没有往redis推送数据。因为对这块业务的了解不够，暂时先注释掉。
          if (!ObjectUtils.isEmpty(deviceAlarm.getAlarmMethod())) {
            if (deviceAlarm.getAlarmMethod().contains(DeviceAlarmMethod.GPS.getVal() + "")) {
              MobilePosition mobilePosition = new MobilePosition();
              mobilePosition.setCreateTime(DateUtil.getNow());
              mobilePosition.setDeviceId(deviceAlarm.getDeviceId());
              mobilePosition.setChannelId(deviceAlarm.getChannelId());
              mobilePosition.setTime(deviceAlarm.getAlarmTime());
              mobilePosition.setLongitude(deviceAlarm.getLongitude());
              mobilePosition.setLatitude(deviceAlarm.getLatitude());
              mobilePosition.setReportSource("GPS Alarm");

              // 更新device channel 的经纬度
              DeviceChannel deviceChannel = new DeviceChannel();
              deviceChannel.setTerminalNumber(sipMsgInfo.getDevice().getTerminalNumber());
              deviceChannel.setTerminalChannelNumber(deviceAlarm.getChannelId());
              deviceChannel.setLongitude(mobilePosition.getLongitude());
              deviceChannel.setLatitude(mobilePosition.getLatitude());
              deviceChannel.setGpsTime(LocalDateTime.now());

              mobilePosition.setLongitudeWgs84(deviceChannel.getLongitudeWgs84());
              mobilePosition.setLatitudeWgs84(deviceChannel.getLatitudeWgs84());
              mobilePosition.setLongitudeGcj02(deviceChannel.getLongitudeGcj02());
              mobilePosition.setLatitudeGcj02(deviceChannel.getLatitudeGcj02());


              // 发送redis消息。 通知位置信息的变化
              JSONObject jsonObject = new JSONObject();
              jsonObject.put("time", DateUtil.yyyy_MM_dd_HH_mm_ssToISO8601(mobilePosition.getTime()));
              jsonObject.put("serial", deviceChannel.getTerminalNumber());
              jsonObject.put("code", deviceChannel.getTerminalChannelNumber());
              jsonObject.put("longitude", mobilePosition.getLongitude());
              jsonObject.put("latitude", mobilePosition.getLatitude());
              jsonObject.put("altitude", mobilePosition.getAltitude());
              jsonObject.put("direction", mobilePosition.getDirection());
              jsonObject.put("speed", mobilePosition.getSpeed());
              // redisCatchStorage.sendMobilePositionMsg(jsonObject);

            }
          }
          */
          if (!ObjectUtils.isEmpty(deviceAlarm.getDeviceId())) {
            if (deviceAlarm.getAlarmMethod().contains(DeviceAlarmMethod.Video.getVal() + "")) {
              deviceAlarm.setAlarmType(getText(sipMsgInfo.getRootElement().element("Info"), "AlarmType"));
            }
          }
          logger.debug("[收到报警通知]内容：{}", JSON.toJSONString(deviceAlarm));
          /* 看起来是调试用的东西，暂时应该没啥用，注释掉避免影响理解业务。
          // 作者自用判断，其他小伙伴需要此消息可以自行修改，但是不要提在pr里
          if (DeviceAlarmMethod.Other.getVal() == Integer.parseInt(deviceAlarm.getAlarmMethod())) {
            // 发送给平台的报警信息。 发送redis通知
            logger.info("[发送给平台的报警信息]内容：{}", JSONObject.toJSONString(deviceAlarm));
            AlarmChannelMessage alarmChannelMessage = new AlarmChannelMessage();
            if (deviceAlarm.getAlarmMethod() != null) {
              alarmChannelMessage.setAlarmSn(Integer.parseInt(deviceAlarm.getAlarmMethod()));
            }
            alarmChannelMessage.setAlarmDescription(deviceAlarm.getAlarmDescription());
            if (deviceAlarm.getAlarmType() != null) {
              alarmChannelMessage.setAlarmType(Integer.parseInt(deviceAlarm.getAlarmType()));
            }
            alarmChannelMessage.setGbId(deviceAlarm.getChannelId());
            //TODO
            //redisCatchStorage.sendAlarmMsg(alarmChannelMessage);
            continue;
          }
          */

          logger.debug("存储报警信息、报警分类");
          // 存储报警信息、报警分类
//          if (gb28181TranslationProperties.getAlarm()) {
//
//            //TODO 报警消息处理
//
//          }

          if (deviceManager.isOnline(sipMsgInfo.getDevice().getTerminalNumber())) {
            publisher.deviceAlarmEventPublish(deviceAlarm);
          }
        } catch (Exception e) {
          logger.error("未处理的异常 ", e);
          logger.warn("[收到报警通知] 发现未处理的异常, {}\r\n{}", e.getMessage(), evt.getRequest());
        }
      }
      isHandling = false;
    });
  }

  @Override
  public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element rootElement) {
    // 回复200 OK
    try {
      responseAck((SIPRequest) evt.getRequest(), Response.OK);
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[命令发送失败] 国标级联 平台[{}] 报警通知回复: {}", parentPlatform.getServerGBId(), e.getMessage());
    }

    if (!gb28181TranslationProperties.getAlarm()) {
      return;
    }

    logger.debug("收到来自平台[{}]的报警通知", parentPlatform.getServerGBId());

    Element deviceIdElement = rootElement.element("DeviceID");
    String channelId = deviceIdElement.getText();

    DeviceAlarm deviceAlarm = new DeviceAlarm();
    deviceAlarm.setCreateTime(DateUtil.getNow());
    deviceAlarm.setDeviceId(parentPlatform.getServerGBId());
    deviceAlarm.setChannelId(channelId);
    deviceAlarm.setAlarmPriority(getText(rootElement, "AlarmPriority"));
    deviceAlarm.setAlarmMethod(getText(rootElement, "AlarmMethod"));
    String alarmTime = XmlUtil.getText(rootElement, "AlarmTime");
    if (alarmTime == null) {
      return;
    }
    deviceAlarm.setAlarmTime(DateUtil.ISO8601Toyyyy_MM_dd_HH_mm_ss(alarmTime));
    String alarmDescription = getText(rootElement, "AlarmDescription");
    if (alarmDescription == null) {
      deviceAlarm.setAlarmDescription("");
    } else {
      deviceAlarm.setAlarmDescription(alarmDescription);
    }
    String longitude = getText(rootElement, "Longitude");
    if (longitude != null && NumericUtil.isDouble(longitude)) {
      deviceAlarm.setLongitude(Double.parseDouble(longitude));
    } else {
      deviceAlarm.setLongitude(0.00);
    }
    String latitude = getText(rootElement, "Latitude");
    if (latitude != null && NumericUtil.isDouble(latitude)) {
      deviceAlarm.setLatitude(Double.parseDouble(latitude));
    } else {
      deviceAlarm.setLatitude(0.00);
    }

    if (!ObjectUtils.isEmpty(deviceAlarm.getAlarmMethod())) {

      if (deviceAlarm.getAlarmMethod().contains(DeviceAlarmMethod.Video.getVal() + "")) {
        deviceAlarm.setAlarmType(getText(rootElement.element("Info"), "AlarmType"));
      }
    }

    if (channelId.equals(parentPlatform.getDeviceGBId())) {
      // 发送给平台的报警信息。 发送redis通知
      AlarmChannelMessage alarmChannelMessage = new AlarmChannelMessage();
      if (deviceAlarm.getAlarmMethod() != null) {
        alarmChannelMessage.setAlarmSn(Integer.parseInt(deviceAlarm.getAlarmMethod()));
      }
      alarmChannelMessage.setAlarmDescription(deviceAlarm.getAlarmDescription());
      alarmChannelMessage.setGbId(channelId);
      if (deviceAlarm.getAlarmType() != null) {
        alarmChannelMessage.setAlarmType(Integer.parseInt(deviceAlarm.getAlarmType()));
      }
      //TODO
      // redisCatchStorage.sendAlarmMsg(alarmChannelMessage);
    }
  }
}
