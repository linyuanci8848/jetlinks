package com.link.anything.middleware.stream.media.protocol.gb28181.sip.session;

import com.link.anything.middleware.stream.media.common.StreamServerProperties;
import com.link.anything.middleware.stream.media.control.domain.SipTransactionInfo;
import com.link.anything.middleware.stream.media.protocol.gb28181.common.InviteSessionType;
import com.link.anything.middleware.stream.media.protocol.gb28181.common.VideoManagerConstants;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.SsrcTransaction;
import com.link.anything.middleware.stream.media.protocol.gb28181.utils.redis.RedisUtil;
import gov.nist.javax.sip.message.SIPResponse;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

/**
 * 视频流session管理器，管理视频预览、预览回放的通信句柄
 */
@Component
public class VideoStreamSessionManager {



  @Resource
  private StreamServerProperties streamServerProperties;
  @Resource
  private RedisTemplate<Object, Object> redisTemplate;

  /**
   * 添加一个点播/回放的事务信息 后续可以通过流Id/callID
   *
   * @param deviceId      设备ID
   * @param channelId     通道ID
   * @param callId        一次请求的CallID
   * @param stream        流名称
   * @param mediaServerId 所使用的流媒体ID
   * @param response      回复
   */
  public void put(String deviceId, String channelId, String callId, String stream, String ssrc, String mediaServerId, SIPResponse response, InviteSessionType type) {
    SsrcTransaction ssrcTransaction = new SsrcTransaction();
    ssrcTransaction.setDeviceId(deviceId);
    ssrcTransaction.setChannelId(channelId);
    ssrcTransaction.setStream(stream);
    ssrcTransaction.setSipTransactionInfo(new SipTransactionInfo(response));
    ssrcTransaction.setCallId(callId);
    ssrcTransaction.setSsrc(ssrc);
    ssrcTransaction.setMediaServerId(mediaServerId);
    ssrcTransaction.setType(type);

    redisTemplate.opsForValue().set(VideoManagerConstants.MEDIA_TRANSACTION_USED_PREFIX + streamServerProperties.getId()
        + "_" + deviceId + "_" + channelId + "_" + callId + "_" + stream, ssrcTransaction);
  }

  public SsrcTransaction getSsrcTransaction(String deviceId, String channelId, String callId, String stream) {

    if (ObjectUtils.isEmpty(deviceId)) {
      deviceId = "*";
    }
    if (ObjectUtils.isEmpty(channelId)) {
      channelId = "*";
    }
    if (ObjectUtils.isEmpty(callId)) {
      callId = "*";
    }
    if (ObjectUtils.isEmpty(stream)) {
      stream = "*";
    }
    String key = VideoManagerConstants.MEDIA_TRANSACTION_USED_PREFIX + streamServerProperties.getId() + "_" + deviceId + "_" + channelId + "_" + callId + "_" + stream;
    List<Object> scanResult = RedisUtil.scan(redisTemplate, key);
    if (scanResult.size() == 0) {
      return null;
    }
    return (SsrcTransaction) redisTemplate.opsForValue().get(scanResult.get(0));
  }


  public String getMediaServerId(String deviceId, String channelId, String stream) {
    SsrcTransaction ssrcTransaction = getSsrcTransaction(deviceId, channelId, null, stream);
    if (ssrcTransaction == null) {
      return null;
    }
    return ssrcTransaction.getMediaServerId();
  }


  public void remove(String deviceId, String channelId, String stream) {
    SsrcTransaction ssrcTransaction = getSsrcTransaction(deviceId, channelId, null, stream);
    if (ssrcTransaction == null) {
      return;
    }
    redisTemplate.delete(VideoManagerConstants.MEDIA_TRANSACTION_USED_PREFIX + streamServerProperties.getId() + "_"
        + deviceId + "_" + channelId + "_" + ssrcTransaction.getCallId() + "_" + ssrcTransaction.getStream());
  }


}
