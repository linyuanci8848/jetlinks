package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl;

import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.SipTransactionInfo;
import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.GB28181TranslationProperties;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.auth.DigestServerAuthenticationHelper;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.GbSipDate;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.RemoteAddressInfo;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.SIPProcessorObserver;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.SIPSender;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.ISIPRequestProcessor;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.SipUtils;
import gov.nist.javax.sip.address.AddressImpl;
import gov.nist.javax.sip.address.SipUri;
import gov.nist.javax.sip.header.SIPDateHeader;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import javax.annotation.Resource;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.header.AuthorizationHeader;
import javax.sip.header.ContactHeader;
import javax.sip.header.FromHeader;
import javax.sip.header.ViaHeader;
import javax.sip.message.Request;
import javax.sip.message.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

/**
 * SIP命令类型： REGISTER请求
 */
@Component
public class RegisterRequestProcessor extends SIPRequestProcessorParent implements InitializingBean, ISIPRequestProcessor {

  private final Logger logger = LoggerFactory.getLogger(RegisterRequestProcessor.class);

  public final String method = "REGISTER";


  @Resource
  private SIPProcessorObserver sipProcessorObserver;

  @Resource
  private IDeviceManager deviceManager;

  @Resource
  private SIPSender sipSender;
  @Resource
  private GB28181TranslationProperties gb28181TranslationProperties;

  @Override
  public void afterPropertiesSet() throws Exception {
    // 添加消息处理的订阅
    sipProcessorObserver.addRequestProcessor(method, this);
  }

  /**
   * 收到注册请求 处理
   *
   * @param evt ''
   */
  @Override
  public void process(RequestEvent evt) {
    try {
      SIPRequest request = (SIPRequest) evt.getRequest();
      logger.info("请求数据{}",request);
      Response response;
      // 注册标志
      boolean registerFlag = request.getExpires().getExpires() != 0;
      // 注销成功
      String title = registerFlag ? "[注册请求]" : "[注销请求]";
      FromHeader fromHeader = (FromHeader) request.getHeader(FromHeader.NAME);
      AddressImpl address = (AddressImpl) fromHeader.getAddress();
      SipUri uri = (SipUri) address.getURI();
      String deviceId = uri.getUser();
      RemoteAddressInfo remoteAddressInfo = SipUtils.getRemoteAddressFromRequest(request, gb28181TranslationProperties.getSipUseSourceIpAsRemoteAddress());
      String requestAddress = remoteAddressInfo.getIp() + ":" + remoteAddressInfo.getPort();
      List<String> password =  gb28181TranslationProperties.getPassword();
      AuthorizationHeader authHead = (AuthorizationHeader) request.getHeader(AuthorizationHeader.NAME);
      if (authHead == null && !ObjectUtils.isEmpty(password)) {
        logger.info(title+" 设备：{}, 回复401: {}", deviceId, requestAddress);
        response = getMessageFactory().createResponse(Response.UNAUTHORIZED, request);
        new DigestServerAuthenticationHelper().generateChallenge(getHeaderFactory(), response, gb28181TranslationProperties.getDomain());
        sipSender.transmitRequest(request.getLocalAddress().getHostAddress(), response);
        return;
      }
      // 校验密码是否正确
      boolean passwordCorrect = true;
      if (!ObjectUtils.isEmpty(password)) {
        DigestServerAuthenticationHelper helper = new DigestServerAuthenticationHelper();
        passwordCorrect = false;
        for (String p : password) {
          if (helper.doAuthenticatePlainTextPassword(request, p)) {
            passwordCorrect = true;
            break;
          }
        }
      }
      if (!passwordCorrect) {
        // 注册失败
        response = getMessageFactory().createResponse(Response.FORBIDDEN, request);
        response.setReasonPhrase("wrong password");
        logger.info(title+" 设备：{}, 密码/SIP服务器ID错误, 回复403: {}", deviceId, requestAddress);
        sipSender.transmitRequest(request.getLocalAddress().getHostAddress(), response);
        return;
      }
      Device device = deviceManager.findDevice(deviceId);
      logger.info(title + "设备：{}, 开始处理: {}", deviceId, requestAddress);
      // 判断TCP还是UDP
      ViaHeader reqViaHeader = (ViaHeader) request.getHeader(ViaHeader.NAME);
      String transport = reqViaHeader.getTransport();
      //设备存在就进行信息更新
      if (device != null && device.getSipTransactionInfo() != null && request.getCallIdHeader().getCallId().equals(device.getSipTransactionInfo().getCallId())) {
        logger.info(title + "设备：{}, 注册续订: {}", device.getTerminalNumber(), device.getTerminalNumber());
        device.setExpires(request.getExpires().getExpires());
        device.setIp(remoteAddressInfo.getIp());
        device.setPort(remoteAddressInfo.getPort());
        device.setHostAddress(remoteAddressInfo.getIp().concat(":").concat(String.valueOf(remoteAddressInfo.getPort())));
        device.setLocalIp(request.getLocalAddress().getHostAddress());
        Response registerOkResponse = getRegisterOkResponse(request);
        device.setTransport("TCP".equalsIgnoreCase(transport) ? "TCP" : "UDP");
        sipSender.transmitRequest(request.getLocalAddress().getHostAddress(), registerOkResponse);
        device.setRegisterAt(LocalDateTime.now());
        SipTransactionInfo sipTransactionInfo = new SipTransactionInfo((SIPResponse) registerOkResponse);
        device.setSipTransactionInfo(sipTransactionInfo);
        device.setProtocol(StreamSourceProtocol.GB28181);
        //设备上线了 并进行信息更新
        deviceManager.online(device);
        return;
      }
      //设备未注册进行注册
      // 携带授权头并且密码正确
      response = getMessageFactory().createResponse(Response.OK, request);
      // 添加date头
      SIPDateHeader dateHeader = new SIPDateHeader();
      // 使用自己修改的
      GbSipDate gbSipDate = new GbSipDate(Calendar.getInstance(Locale.ENGLISH).getTimeInMillis());
      dateHeader.setDate(gbSipDate);
      response.addHeader(dateHeader);
      //异常的处理情况
      if (request.getExpires() == null) {
        response = getMessageFactory().createResponse(Response.BAD_REQUEST, request);
        sipSender.transmitRequest(request.getLocalAddress().getHostAddress(), response);
        return;
      }
      // 添加Contact头
      response.addHeader(request.getHeader(ContactHeader.NAME));
      // 添加Expires头
      response.addHeader(request.getExpires());
      // =0注销成功 / !=0注册成功
      registerFlag = request.getExpires().getExpires() != 0;
      //先发指令在看后续
      sipSender.transmitRequest(request.getLocalAddress().getHostAddress(), response);
      // 注册成功
      if (registerFlag) {
        device = new Device();
        device.setExpires(request.getExpires().getExpires());
        device.setTransport("TCP".equalsIgnoreCase(transport) ? "TCP" : "UDP");
        device.setStreamMode(device.getTransport());
        device.setExpires(request.getExpires().getExpires());
        device.setPort(remoteAddressInfo.getPort());
        device.setLocalIp(request.getLocalAddress().getHostAddress());
        device.setCharset("GB2312");
        device.setGeoCoordSys("WGS84");
        device.setTerminalNumber(deviceId);
        device.setProtocol(StreamSourceProtocol.GB28181);
        device.setIp(remoteAddressInfo.getIp());
        device.setHostAddress(remoteAddressInfo.getIp().concat(":").concat(String.valueOf(remoteAddressInfo.getPort())));
        logger.info("[注册成功] deviceId: {}->{}", deviceId, requestAddress);
        device.setRegisterAt(LocalDateTime.now());
        SipTransactionInfo sipTransactionInfo = new SipTransactionInfo((SIPResponse) response);
        device.setSipTransactionInfo(sipTransactionInfo);
        deviceManager.online(device);
      } else {
        logger.info("[注销成功] deviceId: {}->{}", deviceId, requestAddress);
        deviceManager.offline(deviceId);
      }
    } catch (SipException | NoSuchAlgorithmException | ParseException e) {
      logger.error("未处理的异常 ", e);
    }
  }

  private Response getRegisterOkResponse(Request request) throws ParseException {
    // 携带授权头并且密码正确
    Response response = getMessageFactory().createResponse(Response.OK, request);
    // 添加date头
    SIPDateHeader dateHeader = new SIPDateHeader();
    // 使用自己修改的
    GbSipDate gbSipDate = new GbSipDate(Calendar.getInstance(Locale.ENGLISH).getTimeInMillis());
    dateHeader.setDate(gbSipDate);
    response.addHeader(dateHeader);

    // 添加Contact头
    response.addHeader(request.getHeader(ContactHeader.NAME));
    // 添加Expires头
    response.addHeader(request.getExpires());

    return response;

  }
}
