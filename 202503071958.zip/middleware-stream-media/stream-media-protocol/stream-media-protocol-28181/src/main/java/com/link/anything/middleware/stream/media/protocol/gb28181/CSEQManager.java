package com.link.anything.middleware.stream.media.protocol.gb28181;

import com.link.anything.middleware.stream.media.common.StreamServerProperties;
import com.link.anything.middleware.stream.media.common.constant.GlobalDefinitionRedisKey;
import javax.annotation.Resource;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;

@Component
public class CSEQManager {

  @Resource
  private RedissonClient redisson;


  @Resource
  private StreamServerProperties streamServerProperties;

  /**
   * 获取CSEQ GB28181 需要的
   *
   * @return
   */
  public Long getCSEQ() {
    String key = GlobalDefinitionRedisKey.SIP_CSEQ_PREFIX + streamServerProperties.getId();
    RAtomicLong atomicLong = redisson.getAtomicLong(key);
    Long result = atomicLong.addAndGet(1);
    if (result != null && result > Integer.MAX_VALUE) {
      atomicLong.set(1);
      result = 1L;
    }
    return result;
  }

  /**
   * 重置计数
   */
  public void rest() {
    String key = GlobalDefinitionRedisKey.SIP_CSEQ_PREFIX + streamServerProperties.getId();
    RAtomicLong atomicLong = redisson.getAtomicLong(key);
    atomicLong.set(1);
  }
}
