package com.link.anything.middleware.stream.media.protocol.gb28181.zlm;

import com.alibaba.fastjson2.JSONObject;
import com.link.anything.middleware.stream.media.protocol.gb28181.zlm.dto.HookType;
import com.link.anything.middleware.stream.media.protocol.gb28181.zlm.dto.IHookSubscribe;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import com.link.anything.middleware.stream.media.server.request.OnHookRequest;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * ZLMediaServer的hook事件订阅
 * @author lin
 */
@Component
public class ZlmHttpHookSubscribe {

    private final static Logger logger = LoggerFactory.getLogger(ZlmHttpHookSubscribe.class);

    @FunctionalInterface
    public interface Event{
        void response(MediaServerInstance mediaServerItem, OnHookRequest hookParam);
    }

    private Map<HookType, Map<IHookSubscribe, Event>> allSubscribes = new ConcurrentHashMap<>();

    public void addSubscribe(IHookSubscribe hookSubscribe, Event event) {
        if (hookSubscribe.getExpires() == null) {
            // 默认5分钟过期
            Instant expiresInstant = Instant.now().plusSeconds(TimeUnit.MINUTES.toSeconds(5));
            hookSubscribe.setExpires(expiresInstant);
        }
        allSubscribes.computeIfAbsent(hookSubscribe.getHookType(), k -> new ConcurrentHashMap<>()).put(hookSubscribe, event);
    }

    public void removeSubscribe(IHookSubscribe hookSubscribe) {
        Map<IHookSubscribe, Event> eventMap = allSubscribes.get(hookSubscribe.getHookType());
        if (eventMap == null) {
            return;
        }

        Set<Map.Entry<IHookSubscribe, Event>> entries = eventMap.entrySet();
        if (entries.size() > 0) {
            List<Map.Entry<IHookSubscribe, Event>> entriesToRemove = new ArrayList<>();
            for (Map.Entry<IHookSubscribe, Event> entry : entries) {
                JSONObject content = entry.getKey().getContent();
                if (content == null || content.size() == 0) {
                    entriesToRemove.add(entry);
                    continue;
                }
                Boolean result = null;
                for (String s : content.keySet()) {
                    if (result == null) {
                        result = content.getString(s).equals(hookSubscribe.getContent().getString(s));
                    }else {
                        if (content.getString(s) == null) {
                            continue;
                        }
                        result = result && content.getString(s).equals(hookSubscribe.getContent().getString(s));
                    }
                }
                if (result){
                    entriesToRemove.add(entry);
                }
            }

            if (!CollectionUtils.isEmpty(entriesToRemove)) {
                for (Map.Entry<IHookSubscribe, Event> entry : entriesToRemove) {
                    eventMap.remove(entry.getKey());
                }
                if (eventMap.size() == 0) {
                    allSubscribes.remove(hookSubscribe.getHookType());
                }
            }

        }
    }


    /**
     * 对订阅数据进行过期清理
     */
//    @Scheduled(cron="0 0/5 * * * ?")   //每5分钟执行一次
    @Scheduled(fixedRate = 2 * 1000)
    public void execute(){
        Instant instant = Instant.now().minusMillis(TimeUnit.MINUTES.toMillis(5));
        int total = 0;
        for (HookType hookType : allSubscribes.keySet()) {
            Map<IHookSubscribe, Event> hookSubscribeEventMap = allSubscribes.get(hookType);
            if (hookSubscribeEventMap.size() > 0) {
                for (IHookSubscribe hookSubscribe : hookSubscribeEventMap.keySet()) {
                    if (hookSubscribe.getExpires().isBefore(instant)) {
                        // 过期的
                        hookSubscribeEventMap.remove(hookSubscribe);
                        total ++;
                    }
                }
            }
        }
    }
}
