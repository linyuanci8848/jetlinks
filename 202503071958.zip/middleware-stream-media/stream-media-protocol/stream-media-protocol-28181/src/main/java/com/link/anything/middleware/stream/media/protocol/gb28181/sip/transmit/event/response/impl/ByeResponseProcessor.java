package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.response.impl;


import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.SIPProcessorObserver;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.response.SIPResponseProcessorAbstract;
import javax.sip.ResponseEvent;
import javax.annotation.Resource;
import org.springframework.stereotype.Component;

/**
 * @description: BYE请求响应器
 * @author: swwheihei
 * @date: 2020年5月3日 下午5:32:05
 */
@Component
public class ByeResponseProcessor extends SIPResponseProcessorAbstract {

  private final String method = "BYE";


  @Resource
  private SIPProcessorObserver sipProcessorObserver;

  @Override
  public void afterPropertiesSet() throws Exception {
    // 添加消息处理的订阅
    sipProcessorObserver.addResponseProcessor(method, this);
  }

  /**
   * 处理BYE响应
   *
   * @param evt
   */
  @Override
  public void process(ResponseEvent evt) {
    // TODO Auto-generated method stub
  }


}
