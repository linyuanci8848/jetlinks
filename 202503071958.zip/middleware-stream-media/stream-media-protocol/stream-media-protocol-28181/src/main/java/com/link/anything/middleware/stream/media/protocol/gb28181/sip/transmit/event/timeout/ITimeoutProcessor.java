package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.timeout;

import javax.sip.TimeoutEvent;

public interface ITimeoutProcessor {
    void process(TimeoutEvent event);
}
