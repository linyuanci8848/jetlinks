package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl;

import com.link.anything.middleware.stream.media.common.DynamicTask;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.SendRtpItem;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.SIPProcessorObserver;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.ISIPRequestProcessor;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.server.IMediaServerManager;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Resource;
import javax.sip.RequestEvent;
import javax.sip.address.SipURI;
import javax.sip.header.CallIdHeader;
import javax.sip.header.FromHeader;
import javax.sip.header.HeaderAddress;
import javax.sip.header.ToHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * SIP命令类型： ACK请求
 */
@Component
public class AckRequestProcessor extends SIPRequestProcessorParent implements InitializingBean, ISIPRequestProcessor {

  private Logger logger = LoggerFactory.getLogger(AckRequestProcessor.class);
  private final String method = "ACK";

  @Resource
  private SIPProcessorObserver sipProcessorObserver;

  @Override
  public void afterPropertiesSet() throws Exception {
    // 添加消息处理的订阅
    sipProcessorObserver.addRequestProcessor(method, this);
  }


  @Resource
  private DynamicTask dynamicTask;


  @Resource
  private IMediaServerManager mediaServerManager;


  /**
   * 处理  ACK请求
   *
   * @param evt
   */
  @Override
  public void process(RequestEvent evt) {
    CallIdHeader callIdHeader = (CallIdHeader) evt.getRequest().getHeader(CallIdHeader.NAME);

    String platformGbId = ((SipURI) ((HeaderAddress) evt.getRequest().getHeader(FromHeader.NAME)).getAddress().getURI()).getUser();
    logger.info("[收到ACK]： platformGbId->{}", platformGbId);

    // 取消设置的超时任务
    dynamicTask.stop(callIdHeader.getCallId());
    String channelId = ((SipURI) ((HeaderAddress) evt.getRequest().getHeader(ToHeader.NAME)).getAddress().getURI()).getUser();
    SendRtpItem sendRtpItem = null;
    if (sendRtpItem == null) {
      logger.warn("[收到ACK]：未找到通道({})的推流信息", channelId);
      return;
    }
    // tcp主动时，此时是级联下级平台，在回复200ok时，本地已经请求zlm开启监听，跳过下面步骤
    if (sendRtpItem.isTcpActive()) {
      logger.info("收到ACK，rtp/{} TCP主动方式后续处理", sendRtpItem.getStreamId());
      return;
    }
    String is_Udp = sendRtpItem.isTcp() ? "0" : "1";
    MediaServerInstance mediaInfo = mediaServerManager.findMediaServerInstance(sendRtpItem.getMediaServerId());
    logger.info("收到ACK，rtp/{}开始向上级推流, 目标={}:{}，SSRC={}, 协议:{}",
        sendRtpItem.getStreamId(),
        sendRtpItem.getIp(),
        sendRtpItem.getPort(),
        sendRtpItem.getSsrc(),
        sendRtpItem.isTcp() ? (sendRtpItem.isTcpActive() ? "TCP主动" : "TCP被动") : "UDP"
    );
    Map<String, Object> param = new HashMap<>(12);
    param.put("vhost", "__defaultVhost__");
    param.put("app", sendRtpItem.getApp());
    param.put("stream", sendRtpItem.getStreamId());
    param.put("ssrc", sendRtpItem.getSsrc());
    param.put("dst_url", sendRtpItem.getIp());
    param.put("dst_port", sendRtpItem.getPort());
    param.put("is_udp", is_Udp);
    param.put("src_port", sendRtpItem.getLocalPort());
    param.put("pt", sendRtpItem.getPt());
    param.put("use_ps", sendRtpItem.isUsePs() ? "1" : "0");
    param.put("only_audio", sendRtpItem.isOnlyAudio() ? "1" : "0");
    if (!sendRtpItem.isTcp()) {
      // 开启rtcp保活
      param.put("udp_rtcp_timeout", sendRtpItem.isRtcp() ? "1" : "0");
    }
    //TODO
//    if (mediaInfo == null) {
//      RequestPushStreamMsg requestPushStreamMsg = RequestPushStreamMsg.getInstance(
//          sendRtpItem.getMediaServerId(), sendRtpItem.getApp(), sendRtpItem.getStreamId(),
//          sendRtpItem.getIp(), sendRtpItem.getPort(), sendRtpItem.getSsrc(), sendRtpItem.isTcp(),
//          sendRtpItem.getLocalPort(), sendRtpItem.getPt(), sendRtpItem.isUsePs(), sendRtpItem.isOnlyAudio());
//      redisGbPlayMsgListener.sendMsgForStartSendRtpStream(sendRtpItem.getServerId(), requestPushStreamMsg, jsonObject -> {
//        startSendRtpStreamHand(evt, sendRtpItem, parentPlatform, jsonObject, param, callIdHeader);
//      });
//    } else {
//      StartSendRtpRequest.StartSendRtpRequestBuilder requestBuilder = StartSendRtpRequest.builder();
//      requestBuilder.app(sendRtpItem.getApp()).stream(sendRtpItem.getStreamId()).ssrc(sendRtpItem.getSsrc()).dstUrl(sendRtpItem.getIp()).dstPort(sendRtpItem.getPort());
//      requestBuilder.isUdp( Integer.valueOf(is_Udp)).srcPort(sendRtpItem.getLocalPort()).pt(sendRtpItem.getPt()).use_ps(sendRtpItem.isUsePs() ? 1 : 0);
//      requestBuilder.onlyAudio(sendRtpItem.isOnlyAudio() ? 1 : 0).vhost("__defaultVhost__");
//
//      Integer localPort = mediaServerManager.startSendRtp(mediaInfo, requestBuilder.build());
//      startSendRtpStreamHand(evt, sendRtpItem, parentPlatform, localPort, param, callIdHeader);
//    }
  }

//  private void startSendRtpStreamHand(RequestEvent evt, SendRtpItem sendRtpItem, ParentPlatform parentPlatform, Integer localPort, Map<String, Object> param, CallIdHeader callIdHeader) {
//    if (localPort != null) {
//      logger.info("调用ZLM推流接口, 结果： {}", localPort);
//      logger.info("RTP推流成功[ {}/{} ]，{}->{}:{}, ", param.get("app"), param.get("stream"), localPort, param.get("dst_url"), param.get("dst_port"));
//      if (sendRtpItem.getPlayType() == InviteStreamType.PUSH) {
//        MessageForPushChannel messageForPushChannel = MessageForPushChannel.getInstance(0, sendRtpItem.getApp(), sendRtpItem.getStreamId(),
//            sendRtpItem.getChannelId(), parentPlatform.getServerGBId(), parentPlatform.getName(), userSetting.getServerId(),
//            sendRtpItem.getMediaServerId());
//        messageForPushChannel.setPlatFormIndex(parentPlatform.getId());
//        redisCatchStorage.sendPlatformStartPlayMsg(messageForPushChannel);
//      }
//    } else {
//      logger.error("RTP推流失败: {}, 参数：{}", localPort, JSON.toJSONString(param));
//      if (sendRtpItem.isOnlyAudio()) {
//        // TODO 可能是语音对讲
//      } else {
//        // 向上级平台
//        try {
//          commanderForPlatform.streamByeCmd(parentPlatform, callIdHeader.getCallId());
//        } catch (SipException | InvalidArgumentException | ParseException e) {
//          logger.error("[命令发送失败] 国标级联 发送BYE: {}", e.getMessage());
//        }
//      }
//    }
//  }
}
