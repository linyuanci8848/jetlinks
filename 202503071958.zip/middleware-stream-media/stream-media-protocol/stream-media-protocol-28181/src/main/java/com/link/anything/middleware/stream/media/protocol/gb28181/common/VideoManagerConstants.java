package com.link.anything.middleware.stream.media.protocol.gb28181.common;

/**
 * @description: 定义常量
 * @author: swwheihei
 * @date: 2019年5月30日 下午3:04:04
 */
public class VideoManagerConstants {

  public static final String MEDIA_TRANSACTION_USED_PREFIX = "VMP_MEDIA_TRANSACTION_";


  public static final String REGISTER_EXPIRE_TASK_KEY_PREFIX = "VMP_device_register_expire_";


}
