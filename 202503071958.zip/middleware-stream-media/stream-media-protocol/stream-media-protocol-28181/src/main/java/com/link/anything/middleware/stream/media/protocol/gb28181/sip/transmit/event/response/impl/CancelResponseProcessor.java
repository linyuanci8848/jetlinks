package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.response.impl;


import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.SIPProcessorObserver;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.response.SIPResponseProcessorAbstract;
import javax.sip.ResponseEvent;
import javax.annotation.Resource;
import org.springframework.stereotype.Component;

/**
 * @description: CANCEL响应处理器
 * @author: panlinlin
 * @date: 2021年11月5日 16:35
 */
@Component
public class CancelResponseProcessor extends SIPResponseProcessorAbstract {

  private final String method = "CANCEL";


  @Resource
  private SIPProcessorObserver sipProcessorObserver;

  @Override
  public void afterPropertiesSet() throws Exception {
    // 添加消息处理的订阅
    sipProcessorObserver.addResponseProcessor(method, this);
  }

  /**
   * 处理CANCEL响应
   *
   * @param evt
   */
  @Override
  public void process(ResponseEvent evt) {
    // TODO Auto-generated method stub

  }

}
