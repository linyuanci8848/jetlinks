package com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean;

public class CmdType {

    public static final String CATALOG = "Catalog";
    public static final String ALARM = "Alarm";
    public static final String MOBILE_POSITION = "MobilePosition";
}
