package com.link.anything.middleware.stream.media.protocol.gb28181.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Data
@Configuration
@ConfigurationProperties(prefix = "middleware.stream.gb28181", ignoreInvalidFields = true)
public class GB28181TranslationProperties {

  private String sipHost;
  /**
   * 主要端口
   */
  private Integer sipPort;
  /**
   * http转发代理端口
   */
  private String domain;

  /**
   * 代理绑定IP
   */
  private String id;

  private List<String> password;
  private Boolean alarm;
  private Integer registerTimeInterval;

  private Integer ptzSpeed;
  /**
   * 区划文件
   */
  private String civilCodeFile;
  /**
   * 是否扩展SDP
   */
  private Boolean seniorSdp;
  /**
   * 是否使用设备来源Ip作为回复IP， 不设置则为 false
   */
  private Boolean sipUseSourceIpAsRemoteAddress;
  /**
   * 保持通道状态，不接受notify通道状态变化， 兼容海康平台发送错误消息
   */
  private Boolean refuseChannelStatusChannelFormNotify;
  /**
   * 设备/通道状态变化时发送消息
   */
  private Boolean deviceStatusNotify;

}
