package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl;

import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.SIPProcessorObserver;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.ISIPRequestProcessor;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import javax.sip.RequestEvent;
import org.springframework.beans.factory.InitializingBean;
import javax.annotation.Resource;
import org.springframework.stereotype.Component;

/**
 * SIP命令类型： CANCEL请求
 */
@Component
public class CancelRequestProcessor extends SIPRequestProcessorParent implements InitializingBean, ISIPRequestProcessor {

	private final String method = "CANCEL";

	 @Resource
	private SIPProcessorObserver sipProcessorObserver;

	@Override
	public void afterPropertiesSet() throws Exception {
		// 添加消息处理的订阅
		sipProcessorObserver.addRequestProcessor(method, this);
	}

	/**   
	 * 处理CANCEL请求
	 *  
	 * @param evt 事件
	 */
	@Override
	public void process(RequestEvent evt) {
		// TODO 优先级99 Cancel Request消息实现，此消息一般为级联消息，上级给下级发送请求取消指令
		
	}

}
