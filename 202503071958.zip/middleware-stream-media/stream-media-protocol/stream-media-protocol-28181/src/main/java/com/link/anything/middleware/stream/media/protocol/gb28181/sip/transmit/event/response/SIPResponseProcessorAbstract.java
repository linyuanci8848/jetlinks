package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.response;

import org.springframework.beans.factory.InitializingBean;

public abstract class SIPResponseProcessorAbstract implements InitializingBean, ISIPResponseProcessor {


}
