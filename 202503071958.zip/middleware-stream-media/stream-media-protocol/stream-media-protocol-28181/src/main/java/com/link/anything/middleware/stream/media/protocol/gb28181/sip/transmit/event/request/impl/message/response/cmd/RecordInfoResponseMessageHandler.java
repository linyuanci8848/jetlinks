package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.cmd;

import static com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil.getText;

import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.RecordInfo;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.RecordItem;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.ResponseMessageHandler;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.message.Response;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

/**
 * @author lin
 */
@Component
public class RecordInfoResponseMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

  private final Logger logger = LoggerFactory.getLogger(RecordInfoResponseMessageHandler.class);
  private final String cmdType = "RecordInfo";


  @Resource
  private ResponseMessageHandler responseMessageHandler;


  @Qualifier("taskExecutor")
  @Resource
  private ThreadPoolTaskExecutor taskExecutor;


  private Long recordInfoTtl = 1800L;

  @Resource
  private SubscribeManager subscribeManager;


  @Override
  public void afterPropertiesSet() throws Exception {
    responseMessageHandler.addHandler(cmdType, this);
  }

  @Override
  public void handForDevice(RequestEvent evt, Device device, Element rootElement) {
    try {
      // 回复200 OK
      responseAck((SIPRequest) evt.getRequest(), Response.OK);
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[命令发送失败] 国标级联 国标录像: {}", e.getMessage());
    }
    taskExecutor.execute(() -> {
      try {

        String sn = getText(rootElement, "SN");
        String channelId = getText(rootElement, "DeviceID");
        String deviceId = device.getTerminalNumber();
        RecordInfo recordInfo = new RecordInfo();
        String name = getText(rootElement, "Name");
        String sumNumStr = getText(rootElement, "SumNum");
        int sumNum = 0;
        if (!ObjectUtils.isEmpty(sumNumStr)) {
          sumNum = Integer.parseInt(sumNumStr);
        }
        recordInfo.setSumNum(sumNum);
        Element recordListElement = rootElement.element("RecordList");
        List<VideoFragment> videoFragments = new ArrayList<>();
        if (recordListElement == null || sumNum == 0) {
          logger.info("无录像数据");
          recordInfo.setCount(sumNum);
        } else {
          Iterator<Element> recordListIterator = recordListElement.elementIterator();
          if (recordListIterator != null) {
            // 遍历DeviceList
            while (recordListIterator.hasNext()) {
              Element itemRecord = recordListIterator.next();
              Element recordElement = itemRecord.element("DeviceID");
              if (recordElement == null) {
                logger.info("记录为空，下一个...");
                continue;
              }
              VideoFragment fragment = new VideoFragment();
              RecordItem record = new RecordItem();
              fragment.setDevice(deviceId);
              fragment.setChannel(getText(itemRecord, "DeviceID"));
              //record.setName(getText(itemRecord, "Name"));
              fragment.setSource(HistoryVideoSource.Device);
              fragment.setSourceProtocol(StreamSourceProtocol.GB28181);

              //record.setFilePath(getText(itemRecord, "FilePath"));
              // record.setFileSize(getText(itemRecord, "FileSize"));
              fragment.setSize(Long.parseLong(Optional.ofNullable(getText(itemRecord, "FileSize")).orElse("0")));
              //record.setAddress(getText(itemRecord, "Address"));

              String startTimeStr = getText(itemRecord, "StartTime");
              //record.setStartTime(DateUtil.ISO8601Toyyyy_MM_dd_HH_mm_ss(startTimeStr));
              fragment.setStart(LocalDateTime.parse(startTimeStr, DateTimeFormatter.ISO_DATE_TIME));
              String endTimeStr = getText(itemRecord, "EndTime");
              // record.setEndTime(DateUtil.ISO8601Toyyyy_MM_dd_HH_mm_ss(endTimeStr));
              fragment.setEnd(LocalDateTime.parse(endTimeStr, DateTimeFormatter.ISO_DATE_TIME));
              //record.setSecrecy(itemRecord.element("Secrecy") == null ? 0 : Integer.parseInt(getText(itemRecord, "Secrecy")));
              fragment.setType(StreamType.Video);
              // record.setType(getText(itemRecord, "Type"));
              //record.setRecorderId(getText(itemRecord, "RecorderID"));
              String key = deviceId + "_" + fragment.getChannel() + "_" + fragment.getStart().toEpochSecond(ZoneOffset.ofHours(8)) + "_" + fragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8));
              fragment.setKey(getText(itemRecord, "RecorderID"));
              videoFragments.add(fragment);
            }
          }
        }
        subscribeManager.publish(StreamDefinitionEventKey.HistoryVideoFindCallback + device.getTerminalNumber() + "_" + sn, videoFragments);
      } catch (Exception e) {
        logger.error("[国标录像] 发现未处理的异常, \r\n{}", evt.getRequest());
        logger.error("[国标录像] 异常内容： ", e);
      }
    });
  }

  @Override
  public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element element) {

  }

  public static void main(String[] args) {
    System.out.println(Integer.valueOf("313047576576"));
  }

}
