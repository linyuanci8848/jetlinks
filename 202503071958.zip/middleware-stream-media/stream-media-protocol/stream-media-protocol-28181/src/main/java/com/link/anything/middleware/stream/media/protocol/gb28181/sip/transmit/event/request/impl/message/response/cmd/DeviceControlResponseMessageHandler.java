package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.cmd;

import static com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil.getText;

import com.alibaba.fastjson2.JSONObject;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.ResponseMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.message.Response;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

@Component
public class DeviceControlResponseMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

  private Logger logger = LoggerFactory.getLogger(DeviceControlResponseMessageHandler.class);
  private final String cmdType = "DeviceControl";

  @Resource
  private ResponseMessageHandler responseMessageHandler;


  @Override
  public void afterPropertiesSet() throws Exception {
    responseMessageHandler.addHandler(cmdType, this);
  }

  @Override
  public void handForDevice(RequestEvent evt, Device device, Element element) {
    // 此处是对本平台发出DeviceControl指令的应答
    try {
      responseAck((SIPRequest) evt.getRequest(), Response.OK);
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[命令发送失败] 国标级联 设备控制: {}", e.getMessage());
    }
    JSONObject json = new JSONObject();
    String channelId = getText(element, "DeviceID");
    XmlUtil.node2Json(element, json);
    if (logger.isDebugEnabled()) {
      logger.debug(json.toJSONString());
    }
  }

  @Override
  public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element rootElement) {
  }
}
