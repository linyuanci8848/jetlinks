package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.cmd;

import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.DeviceChannel;
import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.CivilCodeFileConf;
import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.GB28181TranslationProperties;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.HandlerCatchData;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.ResponseMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.SipUtils;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.message.Response;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

/**
 * 目录查询的回复
 */
@Component
public class CatalogResponseMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

  private final static Logger logger = LoggerFactory.getLogger(CatalogResponseMessageHandler.class);
  private final String cmdType = "Catalog";

  @Resource
  private ResponseMessageHandler responseMessageHandler;

  private final ConcurrentLinkedQueue<HandlerCatchData> taskQueue = new ConcurrentLinkedQueue<>();


  @Qualifier("taskExecutor")
  @Resource
  private ThreadPoolTaskExecutor taskExecutor;

  @Resource
  private CivilCodeFileConf civilCodeFileConf;

  @Resource
  private IDeviceManager deviceManager;


  @Resource
  private GB28181TranslationProperties gb28181TranslationProperties;
  private AtomicBoolean processing = new AtomicBoolean(false);

  @Override
  public void afterPropertiesSet() throws Exception {
    responseMessageHandler.addHandler(cmdType, this);
  }

  @Override
  public void handForDevice(RequestEvent evt, Device device, Element element) {
    taskQueue.offer(new HandlerCatchData(evt, device, element));
    // 回复200 OK
    try {
      responseAck((SIPRequest) evt.getRequest(), Response.OK);
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[命令发送失败] 目录查询回复: {}", e.getMessage());
    }
    // 已经开启消息处理则跳过
    if (processing.compareAndSet(false, true)) {
      taskExecutor.execute(() -> {
        while (!taskQueue.isEmpty()) {
          // 全局异常捕获，保证下一条可以得到处理
          try {
            HandlerCatchData take = taskQueue.poll();
            Element rootElement = null;
            try {
              rootElement = getRootElement(take.getEvt(), take.getDevice().getCharset());
            } catch (DocumentException e) {
              logger.error("[xml解析] 失败： ", e);
              continue;
            }
            if (rootElement == null) {
              logger.warn("[ 收到通道 ] content cannot be null, {}", evt.getRequest());
              continue;
            }
            Element deviceListElement = rootElement.element("DeviceList");
            Element sumNumElement = rootElement.element("SumNum");
            Element snElement = rootElement.element("SN");
            int sumNum = Integer.parseInt(sumNumElement.getText());

            if (sumNum == 0) {
              logger.debug("[收到通道]设备:{}的: 0个", take.getDevice().getTerminalNumber());
              // 数据已经完整接收
              deviceManager.deleteDeviceChannelByDevice(take.getDevice().getTerminalNumber());
            } else {
              Iterator<Element> deviceListIterator = deviceListElement.elementIterator();
              if (deviceListIterator != null) {
                List<DeviceChannel> channelList = new ArrayList<>();
                List<String> parentChannelIds = new ArrayList<>();
                // 遍历DeviceList
                while (deviceListIterator.hasNext()) {
                  Element itemDevice = deviceListIterator.next();
                  Element channelDeviceElement = itemDevice.element("DeviceID");
                  if (channelDeviceElement == null) {
                    continue;
                  }
                  DeviceChannel channel = XmlUtil.channelContentHandler(itemDevice, device, null, civilCodeFileConf);
                  if (channel == null) {
                    logger.info("[收到目录订阅]：但是解析失败 {}", new String(evt.getRequest().getRawContent()));
                    continue;
                  }
                  if (channel.getParentId() != null && channel.getParentId().equals(gb28181TranslationProperties.getId())) {
                    channel.setParentId(null);
                  }
                  SipUtils.updateGps(channel, device.getGeoCoordSys());
                  channel.setTerminalNumber(take.getDevice().getTerminalNumber());
                  channelList.add(channel);
                }
                int sn = Integer.parseInt(snElement.getText());
                logger.info("[收到通道]设备: {} -> {}个", take.getDevice().getTerminalNumber(), channelList.size());
                deviceManager.updateDeviceChanel(channelList);
              }
            }
          } catch (Exception e) {
            logger.warn("[收到通道] 发现未处理的异常, \r\n{}", evt.getRequest());
            logger.error("[收到通道] 异常内容： ", e);
          }
        }
        processing.set(false);
      });
    }

  }

  @Override
  public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element rootElement) {

  }

}
