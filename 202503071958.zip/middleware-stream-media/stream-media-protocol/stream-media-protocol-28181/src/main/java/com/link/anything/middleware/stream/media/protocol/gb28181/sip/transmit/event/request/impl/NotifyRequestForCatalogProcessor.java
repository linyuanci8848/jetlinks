package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl;

import com.google.common.collect.Lists;
import com.link.anything.middleware.stream.media.common.DynamicTask;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.DeviceChannel;
import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.CivilCodeFileConf;
import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.GB28181TranslationProperties;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.EventPublisher;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.subscribe.catalog.CatalogEvent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.SipUtils;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.annotation.Resource;
import javax.sip.RequestEvent;
import javax.sip.header.FromHeader;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * SIP命令类型： NOTIFY请求中的目录请求处理
 */
@Component
public class NotifyRequestForCatalogProcessor extends SIPRequestProcessorParent {


  private final static Logger logger = LoggerFactory.getLogger(NotifyRequestForCatalogProcessor.class);


  @Resource
  private CivilCodeFileConf civilCodeFileConf;

  @Resource
  private GB28181TranslationProperties gb28181TranslationProperties;

  @Resource
  private IDeviceManager deviceManager;


  public void process(RequestEvent evt) {
    try {
      long start = System.currentTimeMillis();
      FromHeader fromHeader = (FromHeader) evt.getRequest().getHeader(FromHeader.NAME);
      String deviceId = SipUtils.getUserIdFromFromHeader(fromHeader);

      Device device = deviceManager.findDevice(deviceId);
      if (device == null || deviceManager.isOnline(deviceId)) {
        logger.warn("[收到目录订阅]：{}, 但是设备已经离线", (device != null ? device.getTerminalNumber() : ""));
        return;
      }
      Element rootElement = getRootElement(evt, device.getCharset());
      if (rootElement == null) {
        logger.warn("[ 收到目录订阅 ] content cannot be null, {}", evt.getRequest());
        return;
      }
      Element deviceListElement = rootElement.element("DeviceList");
      if (deviceListElement == null) {
        return;
      }
      Iterator<Element> deviceListIterator = deviceListElement.elementIterator();
      if (deviceListIterator != null) {

        // 遍历DeviceList
        while (deviceListIterator.hasNext()) {
          Element itemDevice = deviceListIterator.next();
          Element channelDeviceElement = itemDevice.element("DeviceID");
          if (channelDeviceElement == null) {
            continue;
          }
          Element eventElement = itemDevice.element("Event");
          String event;
          if (eventElement == null) {
            logger.warn("[收到目录订阅]：{}, 但是Event为空, 设为默认值 ADD", (device != null ? device.getTerminalNumber() : ""));
            event = CatalogEvent.ADD;
          } else {
            event = eventElement.getText().toUpperCase();
          }
          DeviceChannel channel = XmlUtil.channelContentHandler(itemDevice, device, event, civilCodeFileConf);
          if (channel == null) {
            logger.info("[收到目录订阅]：但是解析失败 {}", new String(evt.getRequest().getRawContent()));
            continue;
          }
          if (channel.getParentId() != null && channel.getParentId().equals(gb28181TranslationProperties.getId())) {
            channel.setParentId(null);
          }
          channel.setTerminalNumber(device.getTerminalNumber());
          logger.info("[收到目录订阅]：{}/{}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
          switch (event) {
            case CatalogEvent.ON:
              // 上线
              logger.info("[收到通道上线通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              deviceManager.updateDeviceChanel(Lists.newArrayList(channel));
              break;
            case CatalogEvent.OFF:
              // 离线
              logger.info("[收到通道离线通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              deviceManager.deleteDeviceChannel(device.getTerminalNumber(),Lists.newArrayList( channel.getTerminalChannelNumber()));
              break;
            case CatalogEvent.VLOST:
              // 视频丢失
              logger.info("[收到通道视频丢失通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              if (gb28181TranslationProperties.getRefuseChannelStatusChannelFormNotify()) {
                logger.info("[收到通道视频丢失通知] 但是平台已配置拒绝此消息，来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              }
              deviceManager.deleteDeviceChannel(device.getTerminalNumber(),Lists.newArrayList( channel.getTerminalChannelNumber()));
              break;
            case CatalogEvent.DEFECT:
              // 故障
              logger.info("[收到通道视频故障通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              if (gb28181TranslationProperties.getRefuseChannelStatusChannelFormNotify()) {
                logger.info("[收到通道视频故障通知] 但是平台已配置拒绝此消息，来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              }
              deviceManager.deleteDeviceChannel(device.getTerminalNumber(),Lists.newArrayList( channel.getTerminalChannelNumber()));
              break;
            case CatalogEvent.ADD:
              // 增加
              logger.info("[收到增加通道通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              // 判断此通道是否存在
              deviceManager.updateDeviceChanel(Lists.newArrayList(channel));
              break;
            case CatalogEvent.DEL:
              // 删除
              logger.info("[收到删除通道通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              deviceManager.deleteDeviceChannel(device.getTerminalNumber(),Lists.newArrayList( channel.getTerminalChannelNumber()));
              break;
            case CatalogEvent.UPDATE:
              // 更新
              logger.info("[收到更新通道通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              // 判断此通道是否存在
              deviceManager.updateDeviceChanel(Lists.newArrayList(channel));
              break;
            default:
              logger.warn("[ NotifyCatalog ] event not found ： {}", event);
          }
        }
      }
    } catch (DocumentException e) {
      logger.error("未处理的异常 ", e);
    }
  }


}
