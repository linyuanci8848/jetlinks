package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl;

import com.alibaba.fastjson2.JSONObject;
import com.google.common.collect.Lists;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.DeviceChannel;
import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.CivilCodeFileConf;
import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.GB28181TranslationProperties;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.CmdType;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.DeviceAlarm;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.HandlerCatchData;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.MobilePosition;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.EventPublisher;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.subscribe.catalog.CatalogEvent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.SIPProcessorObserver;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.ISIPRequestProcessor;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.NumericUtil;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.SipUtils;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil;
import com.link.anything.middleware.stream.media.protocol.gb28181.utils.DateUtil;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.header.FromHeader;
import javax.sip.message.Response;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

/**
 * SIP命令类型： NOTIFY请求,这是作为上级发送订阅请求后，设备才会响应的
 */
@Component
public class NotifyRequestProcessor extends SIPRequestProcessorParent implements InitializingBean, ISIPRequestProcessor {


  private final static Logger logger = LoggerFactory.getLogger(NotifyRequestProcessor.class);


  @Resource
  private EventPublisher publisher;

  private final String method = "NOTIFY";

  @Resource
  private SIPProcessorObserver sipProcessorObserver;

  @Resource
  private GB28181TranslationProperties gb28181TranslationProperties;

  @Resource
  private NotifyRequestForCatalogProcessor notifyRequestForCatalogProcessor;

  @Resource
  private CivilCodeFileConf civilCodeFileConf;

  private ConcurrentLinkedQueue<HandlerCatchData> taskQueue = new ConcurrentLinkedQueue<>();

  @Qualifier("taskExecutor")
  @Resource
  private ThreadPoolTaskExecutor taskExecutor;

  private int maxQueueCount = 30000;
  private int maxNotifyCountQueue = 10000;
  @Resource
  private IDeviceManager deviceManager;

  @Override
  public void afterPropertiesSet() throws Exception {
    // 添加消息处理的订阅
    sipProcessorObserver.addRequestProcessor(method, this);
  }

  @Override
  public void process(RequestEvent evt) {
    try {

      if (taskQueue.size() >= maxNotifyCountQueue) {
        responseAck((SIPRequest) evt.getRequest(), Response.BUSY_HERE, null, null);
        logger.error("[notify] 待处理消息队列已满 {}，返回486 BUSY_HERE，消息不做处理", maxNotifyCountQueue);
        return;
      } else {
        responseAck((SIPRequest) evt.getRequest(), Response.OK, null, null);
      }

    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("未处理的异常 ", e);
    }
    boolean runed = !taskQueue.isEmpty();
    logger.info("[notify] 待处理消息数量： {}", taskQueue.size());
    taskQueue.offer(new HandlerCatchData(evt, null, null));
    if (!runed) {
      taskExecutor.execute(() -> {
        while (!taskQueue.isEmpty()) {
          try {
            HandlerCatchData take = taskQueue.poll();
            if (take == null) {
              continue;
            }
            Element rootElement = getRootElement(take.getEvt());
            if (rootElement == null) {
              logger.error("处理NOTIFY消息时未获取到消息体,{}", take.getEvt().getRequest());
              continue;
            }
            String cmd = XmlUtil.getText(rootElement, "CmdType");

            if (CmdType.CATALOG.equals(cmd)) {
              logger.info("接收到Catalog通知");
              processNotifyCatalogList(take.getEvt());
              notifyRequestForCatalogProcessor.process(take.getEvt());
            } else if (CmdType.ALARM.equals(cmd)) {
              logger.info("接收到Alarm通知");
              processNotifyAlarm(take.getEvt());
            } else if (CmdType.MOBILE_POSITION.equals(cmd)) {
              logger.info("接收到MobilePosition通知");
              processNotifyMobilePosition(take.getEvt());
            } else {
              logger.info("接收到消息：" + cmd);
            }
          } catch (DocumentException e) {
            logger.error("处理NOTIFY消息时错误", e);
          }
        }
      });
    }
  }

  /**
   * 处理MobilePosition移动位置Notify
   *
   * @param evt
   */
  private void processNotifyMobilePosition(RequestEvent evt) {
//    try {
//      FromHeader fromHeader = (FromHeader) evt.getRequest().getHeader(FromHeader.NAME);
//      String deviceId = SipUtils.getUserIdFromFromHeader(fromHeader);
//
//      // 回复 200 OK
//      Element rootElement = getRootElement(evt);
//      if (rootElement == null) {
//        logger.error("处理MobilePosition移动位置Notify时未获取到消息体,{}", evt.getRequest());
//        return;
//      }
//
//      MobilePosition mobilePosition = new MobilePosition();
//      mobilePosition.setCreateTime(DateUtil.getNow());
//
//      Element deviceIdElement = rootElement.element("DeviceID");
//      String channelId = deviceIdElement.getTextTrim().toString();
//      Device device = deviceManager.findDevice(deviceId);
//
//      if (device == null) {
//        device = deviceManager.findDevice(channelId);
//        if (device == null) {
//          // 根据通道id查询设备Id
//          device = deviceManager.findDeviceByChannel(channelId);
//        }
//      }
//      if (device == null) {
//        logger.warn("[mobilePosition移动位置Notify] 未找到通道{}所属的设备", channelId);
//        return;
//      }
//      if (!ObjectUtils.isEmpty(device.getName())) {
//        mobilePosition.setDeviceName(device.getName());
//      }
//
//      mobilePosition.setDeviceId(device.getTerminalNumber());
//      mobilePosition.setChannelId(channelId);
//      String time = XmlUtil.getText(rootElement, "Time");
//      if (ObjectUtils.isEmpty(time)) {
//        mobilePosition.setTime(DateUtil.getNow());
//      } else {
//        mobilePosition.setTime(SipUtils.parseTime(time));
//      }
//
//      mobilePosition.setLongitude(Double.parseDouble(XmlUtil.getText(rootElement, "Longitude")));
//      mobilePosition.setLatitude(Double.parseDouble(XmlUtil.getText(rootElement, "Latitude")));
//      if (NumericUtil.isDouble(XmlUtil.getText(rootElement, "Speed"))) {
//        mobilePosition.setSpeed(Double.parseDouble(XmlUtil.getText(rootElement, "Speed")));
//      } else {
//        mobilePosition.setSpeed(0.0);
//      }
//      if (NumericUtil.isDouble(XmlUtil.getText(rootElement, "Direction"))) {
//        mobilePosition.setDirection(Double.parseDouble(XmlUtil.getText(rootElement, "Direction")));
//      } else {
//        mobilePosition.setDirection(0.0);
//      }
//      if (NumericUtil.isDouble(XmlUtil.getText(rootElement, "Altitude"))) {
//        mobilePosition.setAltitude(Double.parseDouble(XmlUtil.getText(rootElement, "Altitude")));
//      } else {
//        mobilePosition.setAltitude(0.0);
//      }
//      logger.info("[收到移动位置订阅通知]：{}/{}->{}.{}", mobilePosition.getTerminalNumber(), mobilePosition.getTerminalChannelNumber(),
//          mobilePosition.getLongitude(), mobilePosition.getLatitude());
//      mobilePosition.setReportSource("Mobile Position");
//
//      // 更新device channel 的经纬度
//      DeviceChannel deviceChannel = new DeviceChannel();
//      deviceChannel.setDeviceId(device.getTerminalNumber());
//      deviceChannel.setChannelId(channelId);
//      deviceChannel.setLongitude(mobilePosition.getLongitude());
//      deviceChannel.setLatitude(mobilePosition.getLatitude());
//      deviceChannel.setGpsTime(mobilePosition.getTime());
//
//      mobilePosition.setLongitudeWgs84(deviceChannel.getLongitudeWgs84());
//      mobilePosition.setLatitudeWgs84(deviceChannel.getLatitudeWgs84());
//      mobilePosition.setLongitudeGcj02(deviceChannel.getLongitudeGcj02());
//      mobilePosition.setLatitudeGcj02(deviceChannel.getLatitudeGcj02());
//
//      // 发送redis消息。 通知位置信息的变化
//      JSONObject jsonObject = new JSONObject();
//      jsonObject.put("time", DateUtil.yyyy_MM_dd_HH_mm_ssToISO8601(mobilePosition.getTime()));
//      jsonObject.put("serial", deviceId);
//      jsonObject.put("code", channelId);
//      jsonObject.put("longitude", mobilePosition.getLongitude());
//      jsonObject.put("latitude", mobilePosition.getLatitude());
//      jsonObject.put("altitude", mobilePosition.getAltitude());
//      jsonObject.put("direction", mobilePosition.getDirection());
//      jsonObject.put("speed", mobilePosition.getSpeed());
//      //redisCatchStorage.sendMobilePositionMsg(jsonObject);
//    } catch (DocumentException e) {
//      logger.error("未处理的异常 ", e);
//    }
  }

  /***
   * 处理alarm设备报警Notify
   *
   * @param evt
   */
  private void processNotifyAlarm(RequestEvent evt) {
    if (!gb28181TranslationProperties.getAlarm()) {
      return;
    }
    try {
      FromHeader fromHeader = (FromHeader) evt.getRequest().getHeader(FromHeader.NAME);
      String deviceId = SipUtils.getUserIdFromFromHeader(fromHeader);

      Element rootElement = getRootElement(evt);
      if (rootElement == null) {
        logger.error("处理alarm设备报警Notify时未获取到消息体{}", evt.getRequest());
        return;
      }
      Element deviceIdElement = rootElement.element("DeviceID");
      String channelId = deviceIdElement.getText().toString();

      Device device = deviceManager.findDevice(deviceId);
      if (device == null) {
        logger.warn("[ NotifyAlarm ] 未找到设备：{}", deviceId);
        return;
      }
      rootElement = getRootElement(evt, device.getCharset());
      if (rootElement == null) {
        logger.warn("[ NotifyAlarm ] content cannot be null, {}", evt.getRequest());
        return;
      }
      DeviceAlarm deviceAlarm = new DeviceAlarm();
      deviceAlarm.setDeviceId(deviceId);
      deviceAlarm.setAlarmPriority(XmlUtil.getText(rootElement, "AlarmPriority"));
      deviceAlarm.setAlarmMethod(XmlUtil.getText(rootElement, "AlarmMethod"));
      String alarmTime = XmlUtil.getText(rootElement, "AlarmTime");
      if (alarmTime == null) {
        logger.warn("[ NotifyAlarm ] AlarmTime cannot be null");
        return;
      }
      deviceAlarm.setAlarmTime(DateUtil.ISO8601Toyyyy_MM_dd_HH_mm_ss(alarmTime));
      if (XmlUtil.getText(rootElement, "AlarmDescription") == null) {
        deviceAlarm.setAlarmDescription("");
      } else {
        deviceAlarm.setAlarmDescription(XmlUtil.getText(rootElement, "AlarmDescription"));
      }
      if (NumericUtil.isDouble(XmlUtil.getText(rootElement, "Longitude"))) {
        deviceAlarm.setLongitude(Double.parseDouble(XmlUtil.getText(rootElement, "Longitude")));
      } else {
        deviceAlarm.setLongitude(0.00);
      }
      if (NumericUtil.isDouble(XmlUtil.getText(rootElement, "Latitude"))) {
        deviceAlarm.setLatitude(Double.parseDouble(XmlUtil.getText(rootElement, "Latitude")));
      } else {
        deviceAlarm.setLatitude(0.00);
      }
      logger.info("[收到Notify-Alarm]：{}/{}", device.getTerminalNumber(), deviceAlarm.getChannelId());
      if ("4".equals(deviceAlarm.getAlarmMethod())) {
        MobilePosition mobilePosition = new MobilePosition();
        mobilePosition.setChannelId(channelId);
        mobilePosition.setCreateTime(DateUtil.getNow());
        mobilePosition.setDeviceId(deviceAlarm.getDeviceId());
        mobilePosition.setTime(deviceAlarm.getAlarmTime());
        mobilePosition.setLongitude(deviceAlarm.getLongitude());
        mobilePosition.setLatitude(deviceAlarm.getLatitude());
        mobilePosition.setReportSource("GPS Alarm");

        // 更新device channel 的经纬度
        DeviceChannel deviceChannel = new DeviceChannel();
        deviceChannel.setTerminalNumber(device.getTerminalNumber());
        deviceChannel.setTerminalChannelNumber(channelId);
        deviceChannel.setLongitude(mobilePosition.getLongitude());
        deviceChannel.setLatitude(mobilePosition.getLatitude());
        deviceChannel.setGpsTime(LocalDateTime.now());

        mobilePosition.setLongitudeWgs84(deviceChannel.getLongitudeWgs84());
        mobilePosition.setLatitudeWgs84(deviceChannel.getLatitudeWgs84());
        mobilePosition.setLongitudeGcj02(deviceChannel.getLongitudeGcj02());
        mobilePosition.setLatitudeGcj02(deviceChannel.getLatitudeGcj02());

        // 发送redis消息。 通知位置信息的变化
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("time", DateUtil.yyyy_MM_dd_HH_mm_ssToISO8601(mobilePosition.getTime()));
        jsonObject.put("serial", deviceChannel.getTerminalNumber());
        jsonObject.put("code", deviceChannel.getTerminalChannelNumber());
        jsonObject.put("longitude", mobilePosition.getLongitude());
        jsonObject.put("latitude", mobilePosition.getLatitude());
        jsonObject.put("altitude", mobilePosition.getAltitude());
        jsonObject.put("direction", mobilePosition.getDirection());
        jsonObject.put("speed", mobilePosition.getSpeed());
        //redisCatchStorage.sendMobilePositionMsg(jsonObject);

      }
      // TODO: 需要实现存储报警信息、报警分类

      // 回复200 OK
      if (deviceManager.isOnline(deviceId)) {
        publisher.deviceAlarmEventPublish(deviceAlarm);
      }
    } catch (DocumentException e) {
      logger.error("未处理的异常 ", e);
    }
  }

  /***
   * 处理catalog设备目录列表Notify
   *
   * @param evt
   */
  private void processNotifyCatalogList(RequestEvent evt) {
    try {
      FromHeader fromHeader = (FromHeader) evt.getRequest().getHeader(FromHeader.NAME);
      String deviceId = SipUtils.getUserIdFromFromHeader(fromHeader);

      Device device = deviceManager.findDevice(deviceId);
      if (device == null || !deviceManager.isOnline(deviceId)) {
        logger.warn("[收到目录订阅]：{}, 但是设备已经离线", (device != null ? device.getTerminalNumber() : ""));
        return;
      }
      Element rootElement = getRootElement(evt, device.getCharset());
      if (rootElement == null) {
        logger.warn("[ 收到目录订阅 ] content cannot be null, {}", evt.getRequest());
        return;
      }
      Element deviceListElement = rootElement.element("DeviceList");
      if (deviceListElement == null) {
        return;
      }
      Iterator<Element> deviceListIterator = deviceListElement.elementIterator();
      if (deviceListIterator != null) {

        // 遍历DeviceList
        while (deviceListIterator.hasNext()) {
          Element itemDevice = deviceListIterator.next();
          Element channelDeviceElement = itemDevice.element("DeviceID");
          if (channelDeviceElement == null) {
            continue;
          }
          Element eventElement = itemDevice.element("Event");
          String event;
          if (eventElement == null) {
            logger.warn("[收到目录订阅]：{}, 但是Event为空, 设为默认值 ADD", (device != null ? device.getTerminalNumber() : ""));
            event = CatalogEvent.ADD;
          } else {
            event = eventElement.getText().toUpperCase();
          }
          DeviceChannel channel = XmlUtil.channelContentHandler(itemDevice, device, event, civilCodeFileConf);
          if (channel == null) {
            logger.info("[收到目录订阅]：但是解析失败 {}", new String(evt.getRequest().getRawContent()));
            continue;
          }
          if (channel.getParentId() != null && channel.getParentId().equals(gb28181TranslationProperties.getId())) {
            channel.setParentId(null);
          }
          channel.setTerminalNumber(device.getTerminalNumber());
          logger.info("[收到目录订阅]：{}/{}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
          switch (event) {
            case CatalogEvent.ON:
              // 上线
              logger.info("[收到通道上线通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              deviceManager.updateDeviceChanel(Lists.newArrayList(channel));
              break;
            case CatalogEvent.OFF:
              // 离线
              logger.info("[收到通道离线通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              if (gb28181TranslationProperties.getRefuseChannelStatusChannelFormNotify()) {

              } else {
                logger.info("[收到通道离线通知] 但是平台已配置拒绝此消息，来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              }
              deviceManager.deleteDeviceChannel(device.getTerminalNumber(),Lists.newArrayList(channel.getTerminalChannelNumber()));
              break;
            case CatalogEvent.VLOST:
              // 视频丢失
              logger.info("[收到通道视频丢失通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              if (gb28181TranslationProperties.getRefuseChannelStatusChannelFormNotify()) {

              } else {
                logger.info("[收到通道视频丢失通知] 但是平台已配置拒绝此消息，来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              }
              deviceManager.deleteDeviceChannel(device.getTerminalNumber(),Lists.newArrayList( channel.getTerminalChannelNumber()));
              break;
            case CatalogEvent.DEFECT:
              // 故障
              break;
            case CatalogEvent.ADD:
              // 增加
              logger.info("[收到增加通道通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              deviceManager.updateDeviceChanel(Lists.newArrayList(channel));
              break;
            case CatalogEvent.DEL:
              // 删除
              logger.info("[收到删除通道通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              deviceManager.deleteDeviceChannel(device.getTerminalNumber(),Lists.newArrayList( channel.getTerminalChannelNumber()));
              break;
            case CatalogEvent.UPDATE:
              // 更新
              logger.info("[收到更新通道通知] 来自设备: {}, 通道 {}", device.getTerminalNumber(), channel.getTerminalChannelNumber());
              deviceManager.updateDeviceChanel(Lists.newArrayList(channel));
              break;
            default:
              logger.warn("[ NotifyCatalog ] event not found ： {}", event);

          }
        }
      }
    } catch (DocumentException e) {
      logger.error("未处理的异常 ", e);
    }
  }


}
