package com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean;

public class PlatformRegister {

    // 未回复次数
    private int reply;

    public int getReply() {
        return reply;
    }

    public void setReply(int reply) {
        this.reply = reply;
    }
}
