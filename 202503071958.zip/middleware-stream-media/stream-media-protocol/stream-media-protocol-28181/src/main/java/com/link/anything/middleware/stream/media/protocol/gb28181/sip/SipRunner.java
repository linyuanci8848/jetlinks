package com.link.anything.middleware.stream.media.protocol.gb28181.sip;

import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.SipSubscribe;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.SipSubscribe.Event;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.SipSubscribe.EventResult;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.cmd.ISIPCommander;
import java.util.List;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;


/**
 * 系统启动时控制设备
 *
 * @author lin
 */
@Slf4j
@Component
@Order(value = 14)
public class SipRunner implements CommandLineRunner {


  @Resource
  private IDeviceManager deviceManager;
  @Resource
  private ISIPCommander commander;

  @Override
  public void run(String... args) throws Exception {
    try{
      List<Device> deviceList = deviceManager.findDeviceByProtocol(StreamSourceProtocol.GB28181);
      for (Device device : deviceList) {
        commander.deviceStatusQuery(device, eventResult -> log.error("设备状态查询失败{}-{}", eventResult.statusCode, eventResult.msg));
      }
    }catch (Exception e){
      log.error("设备状态同步出错",e);
    }

  }
}
