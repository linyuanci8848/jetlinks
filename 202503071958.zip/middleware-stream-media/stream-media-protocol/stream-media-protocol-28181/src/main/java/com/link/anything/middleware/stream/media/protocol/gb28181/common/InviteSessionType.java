package com.link.anything.middleware.stream.media.protocol.gb28181.common;

public enum InviteSessionType {
    PLAY,
    PLAYBACK,
    DOWNLOAD
}
