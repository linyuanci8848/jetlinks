package com.link.anything.middleware.stream.media.protocol.gb28181;

import com.link.anything.middleware.stream.media.common.constant.GlobalDefinitionRedisKey;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamPlayType;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.PTZStreamControl;
import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.common.domain.StreamSession.StreamSessionBuilder;
import com.link.anything.middleware.stream.media.common.domain.StreamSessionApp;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.protocol.IProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.ProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.gb28181.exception.SsrcTransactionNotFoundException;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.cmd.ISIPCommander;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.cmd.impl.SIPCommander;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.SipUtils;
import com.link.anything.middleware.stream.media.server.IMediaServerManager;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;

import java.net.MalformedURLException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.ResponseEvent;
import javax.sip.SipException;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

/**
 * 1078执行器
 */
@ProtocolExecutor(value = StreamSourceProtocol.GB28181)
public class GB28181ProtocolExecutor implements IProtocolExecutor {

  Logger logger = LoggerFactory.getLogger(GB28181ProtocolExecutor.class);


  @Resource
  private IMediaServerManager mediaServerManager;


  @Resource
  private SIPCommander cmder;


  @Resource
  private IDeviceManager deviceManager;


  @Resource
  private SSRCManager ssrcManager;

  @Resource
  private IStreamSessionManager streamSessionManager;

  @Resource
  private ISIPCommander commander;

  @Resource
  private RedissonClient redissonClient;

  @Override
  public StreamSession openLive(String deviceNumber, String channel, Integer bitStream, StreamSourceProtocol streamSourceProtocol, StreamTransferMethod streamTransferMethod,
      MediaServerInstance instance) {
    Assert.isTrue(deviceManager.isOnline(deviceNumber), "当前设备可能存在信号不佳或已关机的情况，请稍后重试。");
    StreamSessionBuilder sessionBuilder = StreamSession.builder();
    sessionBuilder.bitstream(bitStream).streamSourceProtocol(streamSourceProtocol).channel(channel).device(deviceNumber);
    sessionBuilder.mediaServerId(instance.getInstanceId()).streamTransferMethod(streamTransferMethod);
    sessionBuilder.receiveIp(instance.getStreamIp()).app(StreamSessionApp.live).streamType(StreamType.Video);
    Device device = deviceManager.findDevice(deviceNumber);
    sessionBuilder.receivePort(instance.getRtpProxyPort());
    String ssrc = ssrcManager.next(instance.getInstanceId());
    sessionBuilder.streamId(ssrc).ssrc(ssrc);
    //主动模式
    if (streamTransferMethod.equals(StreamTransferMethod.TCP_ACTIVE)) {
      Integer port = mediaServerManager.openRTPServer(instance, ssrc, 0, streamTransferMethod);
      Assert.notNull(port, "收流端口分配失败");
      sessionBuilder.receivePort(port);
    }
    StreamSession streamSession = streamSessionManager.createSession(sessionBuilder.build());
    try {
      cmder.playStreamCmd(instance, streamSession, device, streamSession.getChannel(), (eventResult) -> {
          logger.info("[点播成功] deviceId: {}, channelId:{}, 码流类型：{}", device.getTerminalNumber(), streamSession.getChannel(), bitStream == 1 ? "辅码流" : "主码流");
        }, (event) -> {
          logger.error(String.format("点播失败， 错误码： %s, %s", event.statusCode, event.msg), event);
          controlLiveStream(streamSession, LiveStreamControl.CloseAudioAndVideo);
      });
    } catch (InvalidArgumentException | SipException | ParseException e) {
      logger.error("[命令发送失败] 点播消息: {}", e.getMessage());
      controlLiveStream(streamSession, LiveStreamControl.CloseAudioAndVideo);
    }
    return streamSession;
  }

  @Override
  public void controlLiveStream(StreamSession streamSession, LiveStreamControl control) {
    Device device = deviceManager.findDevice(streamSession.getDevice());
    switch (control) {
      case CloseAudioAndVideo:
        try {
          if (streamSession.getStreamTransferMethod().equals(StreamTransferMethod.TCP_ACTIVE)) {
            mediaServerManager.closeRTPServer(streamSession.getMediaServerId(), streamSession.getStreamId());
          }
          if (deviceManager.isOnline(streamSession.getDevice())) {
            cmder.streamByeCmd(device, streamSession.getChannel(), streamSession.getStreamId(), null);
          }
        } catch (InvalidArgumentException | ParseException | SipException | SsrcTransactionNotFoundException e) {
          logger.error("直播流关闭， 发送BYE失败 {}", e.getMessage());
        } finally {
          // 释放ssrc
          ssrcManager.release(streamSession.getMediaServerId(), streamSession.getStreamId());
          streamSessionManager.removeSession(streamSession.getStreamId());
        }
        break;
    }

  }

  @Override
  public List<VideoFragment> findVideoHistory(String deviceNumber, String channel, StreamSourceProtocol sourceType, LocalDateTime start, LocalDateTime end, StreamType type, Integer bitStream,
                                              HistoryVideoSource source, Long sq) {
    Assert.isTrue(deviceManager.isOnline(deviceNumber), "当前设备可能存在信号不佳或已关机的情况，请稍后重试。");
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    Device device = deviceManager.findDevice(deviceNumber);
    try {
      cmder.recordInfoQuery(device, channel, start.format(dateTimeFormatter), end.format(dateTimeFormatter), sq.intValue(), null, null, null, (eventResult -> {
        logger.warn("查询录像失败, status: " + eventResult.statusCode + ", message: " + eventResult.msg);
      }));
    } catch (Exception e) {
      logger.error(e.getMessage(), e);
      throw new IllegalArgumentException("设备录像文件查询失败");
    }
    return null;
  }

  @Override
  public StreamSession openHistoryStream(VideoFragment fragment, MediaServerInstance instance, StreamTransferMethod method, HistoryStreamPlayType playType, Integer multiple) {
    Assert.isTrue(deviceManager.isOnline(fragment.getDevice()), "当前设备可能存在信号不佳或已关机的情况，请稍后重试。");
    StreamSessionBuilder sessionBuilder = StreamSession.builder();
    sessionBuilder.bitstream(fragment.getBitStream()).streamSourceProtocol(fragment.getSourceProtocol()).channel(fragment.getChannel()).device(fragment.getDevice())
        .end(fragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8)));
    sessionBuilder.mediaServerId(instance.getInstanceId()).start(fragment.getStart().toEpochSecond(ZoneOffset.ofHours(8)));
    sessionBuilder.receiveIp(instance.getStreamIp()).app(StreamSessionApp.record).streamType(fragment.getType()).streamSourceProtocol(StreamSourceProtocol.GB28181);
    String streamId =
        fragment.getDevice() + "_" + fragment.getChannel() + "_" + fragment.getStart().toEpochSecond(ZoneOffset.ofHours(8)) + "_" + fragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8));
    sessionBuilder.streamId(streamId).streamTransferMethod(method).bitstream(fragment.getBitStream());
    Integer port = mediaServerManager.openRTPServer(instance, streamId, 0, method);
    Assert.notNull(port, "收流端口分配失败");
    sessionBuilder.receivePort(port);
    String ssrc = ssrcManager.next(instance.getInstanceId());
    sessionBuilder.ssrc(ssrc);
    StreamSession streamSession = streamSessionManager.createSession(sessionBuilder.build());
    Device device = deviceManager.findDevice(fragment.getDevice());
    try {
      cmder.playbackStreamCmd(instance, streamSession, device, fragment.getChannel(), fragment.getStart(), fragment.getEnd(), (mediaServerItem, hookParam) -> {
        logger.info("[录像回放] 成功 deviceId: {}, channelId: {},  开始时间: {}, 结束时间： {}", fragment.getDevice(), fragment.getChannel(), fragment.getStart(), fragment.getEnd());
      }, eventResult -> {
        // 处理收到200ok后的TCP主动连接以及SSRC不一致的问题
        ResponseEvent responseEvent = (ResponseEvent) eventResult.event;
        String contentString = new String(responseEvent.getResponse().getRawContent());
        String ssrcInResponse = SipUtils.getSsrcFromSdp(contentString);

      }, event -> {
        logger.info("[录像回放] 失败，{} {}", event.statusCode, event.msg);
        controlHistoryStream(streamSession, HistoryStreamControl.Close, 0, null);
      });
    } catch (InvalidArgumentException | SipException | ParseException e) {
      logger.error("[命令发送失败] 录像回放: {}", e.getMessage());
    }
    return streamSession;
  }


  @Override
  public void controlHistoryStream(StreamSession session, HistoryStreamControl control, Integer multiple, Long point) {
    // 只要接到close消息就释放SSRC，避免SSRC资源错误耗尽
    if (control == HistoryStreamControl.Close) {
      ssrcManager.release(session.getMediaServerId(), session.getSsrc());
    }
    Assert.isTrue(deviceManager.isOnline(session.getDevice()), "当前设备可能存在信号不佳或已关机的情况，请稍后重试。");
    Device device = deviceManager.findDevice(session.getDevice());
    switch (control) {
      case Close:
        try {
          cmder.streamByeCmd(device, session.getChannel(), session.getStreamId(), null);
        } catch (InvalidArgumentException | ParseException | SipException | SsrcTransactionNotFoundException e) {
          throw new IllegalArgumentException("流控制失败:" + e.getMessage());
        } finally {
          streamSessionManager.removeSession(session.getStreamId());
          mediaServerManager.closeRTPServer(session.getMediaServerId(), session.getStreamId());
        }
        break;
      case KeyframeRewindPlayback:
        break;
      case SingleFramePlay:
        break;
      case FastForward:
        try {
          cmder.playSpeedCmd(device, session, multiple * 1d);
        } catch (InvalidArgumentException | ParseException | SipException e) {
          throw new IllegalArgumentException("流控制失败:" + e.getMessage());
        }
        break;
      case Suspend:
        try {
          cmder.playPauseCmd(device, session);
        } catch (InvalidArgumentException | ParseException | SipException e) {
          throw new IllegalArgumentException("流控制失败:" + e.getMessage());
        }
        break;
      case Play:
        try {
          cmder.playResumeCmd(device, session);
        } catch (InvalidArgumentException | ParseException | SipException e) {
          throw new IllegalArgumentException("流控制失败:" + e.getMessage());
        }
        break;
      case Drag:
        try {
          cmder.playSeekCmd(device, session, point);
        } catch (InvalidArgumentException | ParseException | SipException e) {
          throw new IllegalArgumentException("流控制失败:" + e.getMessage());
        }
        break;
    }
  }

  @Override
  public void createTalkStream(String device, String channel) {

  }


  @Override
  public void syncDeviceChannel() {
    try {
      List<Device> deviceList = deviceManager.findDeviceByProtocol(StreamSourceProtocol.GB28181);
      if (CollectionUtils.isEmpty(deviceList)) {
        return;
      }
      for (Device device : deviceList) {
        if (!deviceManager.isOnline(device.getTerminalNumber())) {
          continue;
        }
        RAtomicLong rAtomicLong = redissonClient.getAtomicLong(GlobalDefinitionRedisKey.DEVICE_CHANNEL_SN_KEY + device.getTerminalNumber());
        long sq = rAtomicLong.addAndGet(1);
        if (sq >= 65534) {
          sq = 0L;
          rAtomicLong.set(0);
        }
        commander.catalogQuery(device, (int) sq, event -> {
          String errorMsg = String.format("同步通道失败，错误码： %s, %s", event.statusCode, event.msg);
          logger.error(errorMsg);
        });
      }
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[同步通道], 信令发送失败：{}", e.getMessage());
    }
  }


  @Override
  public void controlPTZStream(StreamSession session, PTZStreamControl control, Integer horizonSpeed, Integer zoomSpeed, Integer verticalSpeed) {
    try {
      Assert.isTrue(deviceManager.isOnline(session.getDevice()), "当前设备可能存在信号不佳或已关机的情况，请稍后重试。");
      Device device = deviceManager.findDevice(session.getDevice());
      cmder.frontEndCmd(device, session.getChannel(), control.getCode(), horizonSpeed, verticalSpeed, zoomSpeed);
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[命令发送失败] 云台控制: " + e.getMessage(), e);
      throw new IllegalArgumentException("设备控制失败");
    }
  }

  @Override
  public org.springframework.core.io.Resource captureAsResource(String channelNo) throws InvalidArgumentException, ParseException, SipException, InterruptedException {
    String deviceNumber = "41010500001180000000";
    Device device = deviceManager.findDevice(deviceNumber);
    return commander.sendCaptureCmd(device, channelNo);
  }
}
