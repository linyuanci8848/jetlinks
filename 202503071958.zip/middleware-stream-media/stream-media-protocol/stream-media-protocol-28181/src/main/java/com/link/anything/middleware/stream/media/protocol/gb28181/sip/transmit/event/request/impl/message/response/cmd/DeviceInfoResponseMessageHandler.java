package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.cmd;

import static com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil.getText;

import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.ResponseMessageHandler;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.message.Response;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

/**
 * @author lin
 */
@Component
public class DeviceInfoResponseMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

  private Logger logger = LoggerFactory.getLogger(DeviceInfoResponseMessageHandler.class);
  private final String cmdType = "DeviceInfo";

  @Resource
  private ResponseMessageHandler responseMessageHandler;


  @Resource
  private IDeviceManager deviceManager;

  @Override
  public void afterPropertiesSet() throws Exception {
    responseMessageHandler.addHandler(cmdType, this);
  }

  @Override
  public void handForDevice(RequestEvent evt, Device device, Element rootElement) {
    logger.debug("接收到DeviceInfo应答消息");
    // 检查设备是否存在， 不存在则不回复
    if (device == null) {
      logger.warn("[接收到DeviceInfo应答消息,但设备不存在]");
      return;
    }
    SIPRequest request = (SIPRequest) evt.getRequest();
    try {
      rootElement = getRootElement(evt, device.getCharset());
      if (rootElement == null) {
        logger.warn("[ 接收到DeviceInfo应答消息 ] content cannot be null, {}", evt.getRequest());
        try {
          responseAck((SIPRequest) evt.getRequest(), Response.BAD_REQUEST);
        } catch (SipException | InvalidArgumentException | ParseException e) {
          logger.error("[命令发送失败] DeviceInfo应答消息 BAD_REQUEST: {}", e.getMessage());
        }
        return;
      }
      Element deviceIdElement = rootElement.element("DeviceID");
      String channelId = deviceIdElement.getTextTrim();
      device.setName(getText(rootElement, "DeviceName"));
      device.setManufacturer(getText(rootElement, "Manufacturer"));
      device.setModel(getText(rootElement, "Model"));
      device.setFirmware(getText(rootElement, "Firmware"));
      if (ObjectUtils.isEmpty(device.getStreamMode())) {
        device.setStreamMode("UDP");
      }
      deviceManager.online(device);
    } catch (DocumentException e) {
      throw new RuntimeException(e);
    }
    try {
      // 回复200 OK
      responseAck(request, Response.OK);
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[命令发送失败] DeviceInfo应答消息 200: {}", e.getMessage());
    }

  }

  @Override
  public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element rootElement) {

  }
}
