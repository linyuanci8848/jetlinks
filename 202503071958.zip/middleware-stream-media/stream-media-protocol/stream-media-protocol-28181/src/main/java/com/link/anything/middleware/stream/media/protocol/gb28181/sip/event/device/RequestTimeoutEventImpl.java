package com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.device;

import com.link.anything.middleware.stream.media.control.domain.Device;
import javax.sip.ClientTransaction;
import javax.sip.address.SipURI;
import javax.sip.message.Request;
import javax.annotation.Resource;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * @author lin
 */
@Component
public class RequestTimeoutEventImpl implements ApplicationListener<RequestTimeoutEvent> {



    @Override
    public void onApplicationEvent(RequestTimeoutEvent event) {
        ClientTransaction clientTransaction = event.getTimeoutEvent().getClientTransaction();
        if (clientTransaction != null) {
            Request request = clientTransaction.getRequest();
            if (request != null) {
                String host = ((SipURI) request.getRequestURI()).getHost();
                int port = ((SipURI) request.getRequestURI()).getPort();
//                Device device = deviceService.getDeviceByHostAndPort(host, port);
//                if (device == null) {
//                    return;
//                }
//                deviceService.offline(device.getDeviceId(), "等待消息超时");
            }

        }
    }
}
