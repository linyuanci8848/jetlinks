package com.link.anything.middleware.stream.media.protocol.gb28181.configuration;

import com.link.anything.middleware.stream.media.common.StreamServerProperties;
import com.link.anything.middleware.stream.media.protocol.gb28181.common.CivilCodePo;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.ObjectUtils;

/**
 * 启动时读取行政区划表
 */
@Configuration
@Order(value = 14)
public class CivilCodeFileConf implements CommandLineRunner {

  private final static Logger logger = LoggerFactory.getLogger(CivilCodeFileConf.class);

  private final Map<String, CivilCodePo> civilCodeMap = new ConcurrentHashMap<>();

  @Resource
  private GB28181TranslationProperties translationProperties;


  @Override
  public void run(String... args) throws Exception {
    if (ObjectUtils.isEmpty(translationProperties.getCivilCodeFile())) {
      logger.warn("[行政区划] 文件未设置，可能造成目录刷新结果不完整");
      return;
    }
    InputStream inputStream;
    if (translationProperties.getCivilCodeFile().startsWith("classpath:")) {
      String filePath = translationProperties.getCivilCodeFile().substring("classpath:".length());
      ClassPathResource civilCodeFile = new ClassPathResource(filePath);
      if (!civilCodeFile.exists()) {
        logger.warn("[行政区划] 文件<{}>不存在，可能造成目录刷新结果不完整", translationProperties.getCivilCodeFile());
        return;
      }
      inputStream = civilCodeFile.getInputStream();

    } else {
      File civilCodeFile = new File(translationProperties.getCivilCodeFile());
      if (!civilCodeFile.exists()) {
        logger.warn("[行政区划] 文件<{}>不存在，可能造成目录刷新结果不完整", translationProperties.getCivilCodeFile());
        return;
      }
      inputStream = Files.newInputStream(civilCodeFile.toPath());
    }

    BufferedReader inputStreamReader = new BufferedReader(new InputStreamReader(inputStream));
    int index = -1;
    String line;
    while ((line = inputStreamReader.readLine()) != null) {
      index++;
      if (index == 0) {
        continue;
      }
      String[] infoArray = line.split(",");
      CivilCodePo civilCodePo = CivilCodePo.getInstance(infoArray);
      civilCodeMap.put(civilCodePo.getCode(), civilCodePo);
    }
    inputStreamReader.close();
    inputStream.close();
    if (civilCodeMap.size() == 0) {
      logger.warn("[行政区划] 文件内容为空，可能造成目录刷新结果不完整");
    } else {
      logger.info("[行政区划] 加载成功，共加载数据{}条", civilCodeMap.size());
    }
  }

  public CivilCodePo getParentCode(String code) {
    if (code.length() > 8) {
      return null;
    }
    if (code.length() == 8) {
      String parentCode = code.substring(0, 6);
      return civilCodeMap.get(parentCode);
    } else {
      CivilCodePo civilCodePo = civilCodeMap.get(code);
      if (civilCodePo == null) {
        return null;
      }
      String parentCode = civilCodePo.getParentCode();
      if (parentCode == null) {
        return null;
      }
      return civilCodeMap.get(parentCode);
    }

  }

}
