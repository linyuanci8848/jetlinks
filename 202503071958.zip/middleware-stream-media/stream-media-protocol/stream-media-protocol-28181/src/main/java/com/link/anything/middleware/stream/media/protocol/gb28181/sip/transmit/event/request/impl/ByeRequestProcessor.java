package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl;

import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.common.domain.StreamSessionApp;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.DeviceChannel;
import com.link.anything.middleware.stream.media.protocol.gb28181.GB28181ProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.gb28181.exception.SsrcTransactionNotFoundException;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.InviteStreamType;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.SendRtpItem;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.SsrcTransaction;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.session.VideoStreamSessionManager;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.SIPProcessorObserver;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.cmd.ISIPCommander;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.ISIPRequestProcessor;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.server.IMediaServerManager;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import com.link.anything.middleware.stream.media.server.request.StopSendRtpRequest;
import com.link.anything.middleware.stream.media.server.response.MediaStreamResponse;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.header.CallIdHeader;
import javax.sip.message.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * SIP命令类型： BYE请求
 */
@Component
public class ByeRequestProcessor extends SIPRequestProcessorParent implements InitializingBean, ISIPRequestProcessor {

  private final Logger logger = LoggerFactory.getLogger(ByeRequestProcessor.class);
  private final String method = "BYE";

  @Resource
  private ISIPCommander cmder;


  @Resource
  private IDeviceManager deviceManager;


  @Resource
  private SIPProcessorObserver sipProcessorObserver;

  @Resource
  private VideoStreamSessionManager streamSession;


  @Resource
  private IMediaServerManager mediaServerManager;

  @Resource
  private IStreamSessionManager streamSessionManager;

  @Resource
  private GB28181ProtocolExecutor gb28181ProtocolExecutor;

  @Override
  public void afterPropertiesSet() throws Exception {
    // 添加消息处理的订阅
    sipProcessorObserver.addRequestProcessor(method, this);
  }

  /**
   * 处理BYE请求
   *
   * @param evt
   */
  @Override
  public void process(RequestEvent evt) {
    SIPRequest request = (SIPRequest) evt.getRequest();
    try {
      responseAck(request, Response.OK);
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[回复BYE信息失败]，{}", e.getMessage());
    }
    CallIdHeader callIdHeader = (CallIdHeader) evt.getRequest().getHeader(CallIdHeader.NAME);

    SendRtpItem sendRtpItem = null;

    if (sendRtpItem != null) {
      logger.info("[收到bye] 来自平台{}， 停止通道：{}", sendRtpItem.getPlatformId(), sendRtpItem.getChannelId());
      String streamId = sendRtpItem.getStreamId();
      Map<String, Object> param = new HashMap<>();
      param.put("vhost", "__defaultVhost__");
      param.put("app", sendRtpItem.getApp());
      param.put("stream", streamId);
      param.put("ssrc", sendRtpItem.getSsrc());
      logger.info("[收到bye] 停止向上级推流：{}", streamId);
      MediaServerInstance mediaInfo = mediaServerManager.findMediaServerInstance(sendRtpItem.getMediaServerId());
      StopSendRtpRequest.StopSendRtpRequestBuilder requestBuilder = StopSendRtpRequest.builder();
      requestBuilder.app(sendRtpItem.getApp()).stream(streamId).ssrc(sendRtpItem.getSsrc());
      mediaServerManager.stopSendRtp(mediaInfo, requestBuilder.build());
      if (sendRtpItem.getPlayType().equals(InviteStreamType.PUSH)) {
        //向上级平台发送停止观看消息
      }
      List<MediaStreamResponse> mediaStreams = mediaServerManager.getMediaList(mediaInfo, null, null, sendRtpItem.getApp(), streamId);
      if (mediaStreams != null && mediaStreams.stream().mapToInt(MediaStreamResponse::getTotalReaderCount).sum() <= 0) {
        logger.info("[收到bye] {} 无其它观看者，通知设备停止推流", streamId);
        if (sendRtpItem.getPlayType().equals(InviteStreamType.PLAY)) {
          Device device = deviceManager.findDevice(sendRtpItem.getDeviceId());
          if (device == null) {
            logger.info("[收到bye] {} 通知设备停止推流时未找到设备信息", streamId);
          }
          try {
            logger.info("[停止点播] {}/{}", sendRtpItem.getDeviceId(), sendRtpItem.getChannelId());
            cmder.streamByeCmd(device, sendRtpItem.getChannelId(), streamId, null);
          } catch (InvalidArgumentException | ParseException | SipException |
                   SsrcTransactionNotFoundException e) {
            logger.error("[收到bye] {} 无其它观看者，通知设备停止推流， 发送BYE失败 {}", streamId, e.getMessage());
          }
        }
      }
    } else {

      // 可能是设备发送的停止
      SsrcTransaction ssrcTransaction = streamSession.getSsrcTransaction(null, null, callIdHeader.getCallId(), null);
      if (ssrcTransaction == null) {
        return;
      }
      logger.info("[收到bye] 来自设备：{}, 通道已停止推流: {}", ssrcTransaction.getDeviceId(), ssrcTransaction.getChannelId());

      Device device = deviceManager.findDevice(ssrcTransaction.getDeviceId());
      if (device == null) {
        logger.info("[收到bye] 未找到设备：{} ", ssrcTransaction.getDeviceId());
        return;
      }
      StreamSession session = streamSessionManager.getSession(ssrcTransaction.getSsrc());
      //点播是多端口所以要关闭端口
      if (session != null && session.getApp().equals(StreamSessionApp.record)) {

        gb28181ProtocolExecutor.controlHistoryStream(session, HistoryStreamControl.Close, 0, 0L);
      }
      if (session != null && session.getApp().equals(StreamSessionApp.live)) {

        gb28181ProtocolExecutor.controlLiveStream(session, LiveStreamControl.CloseAudioAndVideo);
      }
    }
  }
}
