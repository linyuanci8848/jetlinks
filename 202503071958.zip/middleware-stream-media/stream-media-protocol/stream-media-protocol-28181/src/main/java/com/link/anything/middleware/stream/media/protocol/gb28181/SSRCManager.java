package com.link.anything.middleware.stream.media.protocol.gb28181;

import com.link.anything.middleware.stream.media.protocol.gb28181.configuration.GB28181TranslationProperties;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Resource;

import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;

/**
 * GB28181 协议直播用单端口所以这个
 */
@Component
public class SSRCManager {

  /**
   * 播流最大并发个数
   */
  private static final Integer MAX_STREAM_COUNT = 10000;

  private static final Map<String, Queue<String>> ssrcPools = new ConcurrentHashMap<>();

  private static final Queue<String> lock = new LinkedList<>();

  @Resource
  private RedissonClient redisson;
  @Resource
  private GB28181TranslationProperties gb28181TranslationProperties;

  /**
   * 获取SSRC
   */
  public String next(String mediaServerId) {
    tryInitSegment(mediaServerId);

    String ssrc = ssrcPools.get(mediaServerId).poll();
    if (ssrc == null) {
      throw new RuntimeException("SSRC 耗尽");
    }
    return ssrc;
  }

  private void tryInitSegment(String mediaServerId) {
    synchronized (ssrcPools.getOrDefault(mediaServerId, lock)) {
      Queue<String> ssrcPool = ssrcPools.get(mediaServerId);
      if (ssrcPool != null) {
        return;
      }

      String ssrcPrefix = gb28181TranslationProperties.getDomain().substring(3, 8);
      ssrcPool = new ArrayDeque<>(MAX_STREAM_COUNT);
      ssrcPools.put(mediaServerId, ssrcPool);
      for (int i = 1; i <= MAX_STREAM_COUNT; i++) {
        ssrcPool.add(String.format("0%s%04d", ssrcPrefix, i));
      }
    }
  }

  /**
   * 重置一个流媒体服务的所有ssrc
   *
   * @param mediaServerId 流媒体服务ID
   */
  public void reset(String mediaServerId) {
    ssrcPools.remove(mediaServerId);
  }

  /**
   * 释放ssrc，主要用完的ssrc一定要释放，否则会耗尽
   *
   * @param ssrc 需要重置的ssrc
   */
  public void release(String mediaServerId, String ssrc) {
    if (ssrc == null) {
      return;
    }
    ssrcPools.get(mediaServerId).add(ssrc);
  }

}
