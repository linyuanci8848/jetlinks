package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.cmd;

import static com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil.getText;

import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.PresetQuerySipReq;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.ResponseMessageHandler;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.message.Response;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * 设备预置位查询应答
 */
@Component
public class PresetQueryResponseMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

  private Logger logger = LoggerFactory.getLogger(PresetQueryResponseMessageHandler.class);
  private final String cmdType = "PresetQuery";

  @Resource
  private ResponseMessageHandler responseMessageHandler;


  @Override
  public void afterPropertiesSet() throws Exception {
    responseMessageHandler.addHandler(cmdType, this);
  }

  @Override
  public void handForDevice(RequestEvent evt, Device device, Element element) {

    SIPRequest request = (SIPRequest) evt.getRequest();

    try {
      Element rootElement = getRootElement(evt, device.getCharset());

      if (rootElement == null) {
        logger.warn("[ 设备预置位查询应答 ] content cannot be null, {}", evt.getRequest());
        try {
          responseAck(request, Response.BAD_REQUEST);
        } catch (InvalidArgumentException | ParseException | SipException e) {
          logger.error("[命令发送失败] 设备预置位查询应答处理: {}", e.getMessage());
        }
        return;
      }
      Element presetListNumElement = rootElement.element("PresetList");
      Element snElement = rootElement.element("SN");
      //该字段可能为通道或则设备的id
      String deviceId = getText(rootElement, "DeviceID");

      if (snElement == null || presetListNumElement == null) {
        try {
          responseAck(request, Response.BAD_REQUEST, "xml error");
        } catch (InvalidArgumentException | ParseException | SipException e) {
          logger.error("[命令发送失败] 设备预置位查询应答处理: {}", e.getMessage());
        }
        return;
      }
      int sumNum = Integer.parseInt(presetListNumElement.attributeValue("Num"));
      List<PresetQuerySipReq> presetQuerySipReqList = new ArrayList<>();
      if (sumNum > 0) {
        for (Iterator<Element> presetIterator = presetListNumElement.elementIterator(); presetIterator.hasNext(); ) {
          Element itemListElement = presetIterator.next();
          PresetQuerySipReq presetQuerySipReq = new PresetQuerySipReq();
          for (Iterator<Element> itemListIterator = itemListElement.elementIterator(); itemListIterator.hasNext(); ) {
            // 遍历item
            Element itemOne = itemListIterator.next();
            String name = itemOne.getName();
            String textTrim = itemOne.getTextTrim();
            if ("PresetID".equalsIgnoreCase(name)) {
              presetQuerySipReq.setPresetId(textTrim);
            } else {
              presetQuerySipReq.setPresetName(textTrim);
            }
          }
          presetQuerySipReqList.add(presetQuerySipReq);
        }
      }

      try {
        responseAck(request, Response.OK);
      } catch (InvalidArgumentException | ParseException | SipException e) {
        logger.error("[命令发送失败] 设备预置位查询应答处理: {}", e.getMessage());
      }
    } catch (DocumentException e) {
      logger.error("[解析xml]失败: ", e);
    }
  }

  @Override
  public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element rootElement) {

  }

}
