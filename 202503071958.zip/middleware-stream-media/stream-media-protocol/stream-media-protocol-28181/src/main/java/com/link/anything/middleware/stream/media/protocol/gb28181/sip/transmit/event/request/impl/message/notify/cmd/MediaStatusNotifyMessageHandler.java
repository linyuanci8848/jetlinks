package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.notify.cmd;

import static com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil.getText;

import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.gb28181.exception.SsrcTransactionNotFoundException;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.SsrcTransaction;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.session.VideoStreamSessionManager;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.cmd.impl.SIPCommander;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.notify.NotifyMessageHandler;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.header.CallIdHeader;
import javax.sip.message.Response;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * 媒体通知
 */
@Component
public class MediaStatusNotifyMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

  private Logger logger = LoggerFactory.getLogger(MediaStatusNotifyMessageHandler.class);
  private final String cmdType = "MediaStatus";

  @Resource
  private NotifyMessageHandler notifyMessageHandler;

  @Resource
  private SIPCommander cmder;


  @Resource
  private IStreamSessionManager streamSessionManager;


  @Resource
  private VideoStreamSessionManager streamSession;

  @Override
  public void afterPropertiesSet() throws Exception {
    notifyMessageHandler.addHandler(cmdType, this);
  }

  @Override
  public void handForDevice(RequestEvent evt, Device device, Element rootElement) {

    // 回复200 OK
    try {
      responseAck((SIPRequest) evt.getRequest(), Response.OK);
    } catch (SipException | InvalidArgumentException | ParseException e) {
      logger.error("[命令发送失败] 国标级联 录像流推送完毕，回复200OK: {}", e.getMessage());
    }
    CallIdHeader callIdHeader = (CallIdHeader) evt.getRequest().getHeader(CallIdHeader.NAME);
    String NotifyType = getText(rootElement, "NotifyType");
    if ("121".equals(NotifyType)) {
      logger.info("[录像流]推送完毕，收到关流通知");

      SsrcTransaction ssrcTransaction = streamSession.getSsrcTransaction(null, null, callIdHeader.getCallId(), null);
      if (ssrcTransaction != null) {
        logger.info("[录像流]推送完毕，关流通知， device: {}, channelId: {}", ssrcTransaction.getDeviceId(), ssrcTransaction.getChannelId());
        try {
          cmder.streamByeCmd(device, ssrcTransaction.getChannelId(), null, callIdHeader.getCallId());
        } catch (InvalidArgumentException | ParseException | SsrcTransactionNotFoundException | SipException e) {
          logger.error("[录像流]推送完毕，收到关流通知， 发送BYE失败 {}", e.getMessage());
        }
        // 去除监听流注销自动停止下载的监听
        //streamSessionManager.removeSession(ssrcTransaction.getStream());
      } else {
        logger.info("[录像流]推送完毕，关流通知， 但是未找到对应的下载信息");
      }
    }
  }

  @Override
  public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element element) {

  }
}
