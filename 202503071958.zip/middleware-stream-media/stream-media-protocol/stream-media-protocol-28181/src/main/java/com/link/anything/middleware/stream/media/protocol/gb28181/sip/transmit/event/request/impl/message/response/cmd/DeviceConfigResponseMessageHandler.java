package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.cmd;

import static com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil.getText;

import com.alibaba.fastjson2.JSONObject;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.ResponseMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil;
import javax.annotation.Resource;
import javax.sip.RequestEvent;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

@Component
public class DeviceConfigResponseMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

  private Logger logger = LoggerFactory.getLogger(DeviceConfigResponseMessageHandler.class);
  private final String cmdType = "DeviceConfig";

  @Resource
  private ResponseMessageHandler responseMessageHandler;


  @Override
  public void afterPropertiesSet() throws Exception {
    responseMessageHandler.addHandler(cmdType, this);
  }

  @Override
  public void handForDevice(RequestEvent evt, Device device, Element element) {
    JSONObject json = new JSONObject();
    XmlUtil.node2Json(element, json);
    String channelId = getText(element, "DeviceID");
    if (logger.isDebugEnabled()) {
      logger.debug(json.toJSONString());
    }
  }

  @Override
  public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element rootElement) {
  }
}
