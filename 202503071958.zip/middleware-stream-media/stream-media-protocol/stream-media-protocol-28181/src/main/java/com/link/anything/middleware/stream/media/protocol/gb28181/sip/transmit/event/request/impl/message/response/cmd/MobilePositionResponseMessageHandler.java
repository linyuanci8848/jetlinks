package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.cmd;

import static com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.XmlUtil.getText;

import com.alibaba.fastjson2.JSONObject;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.DeviceChannel;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.MobilePosition;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.ParentPlatform;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.IMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.response.ResponseMessageHandler;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.NumericUtil;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.SipUtils;
import com.link.anything.middleware.stream.media.protocol.gb28181.utils.DateUtil;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import java.time.LocalDateTime;
import javax.annotation.Resource;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.message.Response;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

/**
 * 移动设备位置数据查询回复
 *
 * @author lin
 */
@Component
public class MobilePositionResponseMessageHandler extends SIPRequestProcessorParent implements InitializingBean, IMessageHandler {

  private Logger logger = LoggerFactory.getLogger(MobilePositionResponseMessageHandler.class);
  private final String cmdType = "MobilePosition";

  @Resource
  private ResponseMessageHandler responseMessageHandler;


  @Override
  public void afterPropertiesSet() throws Exception {
    responseMessageHandler.addHandler(cmdType, this);
  }

  @Override
  public void handForDevice(RequestEvent evt, Device device, Element rootElement) {
    SIPRequest request = (SIPRequest) evt.getRequest();

    try {
      rootElement = getRootElement(evt, device.getCharset());
      if (rootElement == null) {
        logger.warn("[ 移动设备位置数据查询回复 ] content cannot be null, {}", evt.getRequest());
        try {
          responseAck(request, Response.BAD_REQUEST);
        } catch (SipException | InvalidArgumentException | ParseException e) {
          logger.error("[命令发送失败] 移动设备位置数据查询 BAD_REQUEST: {}", e.getMessage());
        }
        return;
      }
      MobilePosition mobilePosition = new MobilePosition();
      mobilePosition.setCreateTime(DateUtil.getNow());
      if (!ObjectUtils.isEmpty(device.getName())) {
        mobilePosition.setDeviceName(device.getName());
      }
      mobilePosition.setDeviceId(device.getTerminalNumber());
      mobilePosition.setChannelId(getText(rootElement, "DeviceID"));
      //兼容ISO 8601格式时间
      String time = getText(rootElement, "Time");
      if (ObjectUtils.isEmpty(time)) {
        mobilePosition.setTime(DateUtil.getNow());
      } else {
        mobilePosition.setTime(SipUtils.parseTime(time));
      }
      mobilePosition.setLongitude(Double.parseDouble(getText(rootElement, "Longitude")));
      mobilePosition.setLatitude(Double.parseDouble(getText(rootElement, "Latitude")));
      if (NumericUtil.isDouble(getText(rootElement, "Speed"))) {
        mobilePosition.setSpeed(Double.parseDouble(getText(rootElement, "Speed")));
      } else {
        mobilePosition.setSpeed(0.0);
      }
      if (NumericUtil.isDouble(getText(rootElement, "Direction"))) {
        mobilePosition.setDirection(Double.parseDouble(getText(rootElement, "Direction")));
      } else {
        mobilePosition.setDirection(0.0);
      }
      if (NumericUtil.isDouble(getText(rootElement, "Altitude"))) {
        mobilePosition.setAltitude(Double.parseDouble(getText(rootElement, "Altitude")));
      } else {
        mobilePosition.setAltitude(0.0);
      }
      mobilePosition.setReportSource("Mobile Position");

      // 更新device channel 的经纬度
      DeviceChannel deviceChannel = new DeviceChannel();
      deviceChannel.setTerminalNumber(device.getTerminalNumber());
      deviceChannel.setTerminalChannelNumber(mobilePosition.getChannelId());
      deviceChannel.setLongitude(mobilePosition.getLongitude());
      deviceChannel.setLatitude(mobilePosition.getLatitude());
      deviceChannel.setGpsTime(LocalDateTime.now());

      mobilePosition.setLongitudeWgs84(deviceChannel.getLongitudeWgs84());
      mobilePosition.setLatitudeWgs84(deviceChannel.getLatitudeWgs84());
      mobilePosition.setLongitudeGcj02(deviceChannel.getLongitudeGcj02());
      mobilePosition.setLatitudeGcj02(deviceChannel.getLatitudeGcj02());

      // 发送redis消息。 通知位置信息的变化
      JSONObject jsonObject = new JSONObject();
      jsonObject.put("time", DateUtil.yyyy_MM_dd_HH_mm_ssToISO8601(mobilePosition.getTime()));
      jsonObject.put("serial", deviceChannel.getTerminalNumber());
      jsonObject.put("code", deviceChannel.getTerminalChannelNumber());
      jsonObject.put("longitude", mobilePosition.getLongitude());
      jsonObject.put("latitude", mobilePosition.getLatitude());
      jsonObject.put("altitude", mobilePosition.getAltitude());
      jsonObject.put("direction", mobilePosition.getDirection());
      jsonObject.put("speed", mobilePosition.getSpeed());
      //TODO
      //redisCatchStorage.sendMobilePositionMsg(jsonObject);
      //回复 200 OK
      try {
        responseAck(request, Response.OK);
      } catch (SipException | InvalidArgumentException | ParseException e) {
        logger.error("[命令发送失败] 移动设备位置数据查询 200: {}", e.getMessage());
      }

    } catch (DocumentException e) {
      logger.error("未处理的异常 ", e);
    }
  }

  @Override
  public void handForPlatform(RequestEvent evt, ParentPlatform parentPlatform, Element element) {

  }
}
