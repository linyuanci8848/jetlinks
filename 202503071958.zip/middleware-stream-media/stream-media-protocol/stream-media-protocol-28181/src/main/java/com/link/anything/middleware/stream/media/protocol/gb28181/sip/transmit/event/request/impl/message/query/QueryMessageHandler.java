package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.query;

import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.MessageHandlerAbstract;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.message.MessageRequestProcessor;
import org.springframework.beans.factory.InitializingBean;
import javax.annotation.Resource;
import org.springframework.stereotype.Component;

/**
 * 命令类型： 查询指令
 * 命令类型： 设备状态, 设备目录信息, 设备信息, 文件目录检索(TODO), 报警(TODO), 设备配置(TODO), 设备预置位(TODO), 移动设备位置数据(TODO)
 */
@Component
public class QueryMessageHandler extends MessageHandlerAbstract implements InitializingBean  {

    private final String messageType = "Query";

     @Resource
    private MessageRequestProcessor messageRequestProcessor;

    @Override
    public void afterPropertiesSet() throws Exception {
        messageRequestProcessor.addHandler(messageType, this);
    }
}
