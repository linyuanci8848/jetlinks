package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit;

import javax.sip.*;
import javax.sip.address.*;
import javax.sip.header.*;
import javax.sip.message.*;
import java.util.*;

public class GB28181Capture implements SipListener {

    private SipFactory sipFactory;
    private SipStack sipStack;
    private SipProvider sipProvider;
    private AddressFactory addressFactory;
    private HeaderFactory headerFactory;
    private MessageFactory messageFactory;

    private String deviceIp = "192.168.0.108"; // 设备 IP
    private int devicePort = 5060;           // 设备 SIP 端口
    private String serverIp = "192.168.0.09"; // SIP 服务器 IP
    private int serverPort = 8116;           // SIP 服务器端口

    public void init() throws Exception {
        // 初始化 SIP 工厂
        sipFactory = SipFactory.getInstance();
        sipFactory.setPathName("gov.nist");
        Properties properties = new Properties();
        properties.setProperty("javax.sip.STACK_NAME", "GB28181Client");
        sipStack = sipFactory.createSipStack(properties);

        // 创建工厂
        addressFactory = sipFactory.createAddressFactory();
        headerFactory = sipFactory.createHeaderFactory();
        messageFactory = sipFactory.createMessageFactory();

        // 创建 SIP 提供者
        ListeningPoint listeningPoint = sipStack.createListeningPoint(serverIp, serverPort, "udp");
        sipProvider = sipStack.createSipProvider(listeningPoint);
        sipProvider.addSipListener(this);
    }

    public void sendCaptureCommand() throws Exception {
        // 创建 SIP 地址
        Address deviceAddress = addressFactory.createAddress("sip:" + deviceIp + ":" + devicePort);
        Address serverAddress = addressFactory.createAddress("sip:" + serverIp + ":" + serverPort);

        // 创建请求 URI
        javax.sip.address.URI requestURI = addressFactory.createURI("sip:" + deviceIp + ":" + devicePort);

        // 创建 From 和 To 头
        FromHeader fromHeader = headerFactory.createFromHeader(serverAddress, "12345");
        ToHeader toHeader = headerFactory.createToHeader(deviceAddress, null);

        // 创建 Call-ID 头
        CallIdHeader callIdHeader = sipProvider.getNewCallId();

        // 创建 CSeq 头
        CSeqHeader cSeqHeader = headerFactory.createCSeqHeader(1, Request.MESSAGE);

        // 创建 Max-Forwards 头
        MaxForwardsHeader maxForwards = headerFactory.createMaxForwardsHeader(70);

        // 创建 Via 头
        ArrayList<ViaHeader> viaHeaders = new ArrayList<>();
        ViaHeader viaHeader = headerFactory.createViaHeader(serverIp, serverPort, "udp", null);
        viaHeaders.add(viaHeader);

        // 创建请求
        Request request = messageFactory.createRequest(
                requestURI, Request.MESSAGE, callIdHeader, cSeqHeader, fromHeader, toHeader, viaHeaders, maxForwards);

        // 添加抓图命令的 XML 内容
        String xmlContent = "<?xml version=\"1.0\"?>\n" +
                "<Control>\n" +
                "  <CmdType>DeviceControl</CmdType>\n" +
                "  <SN>123456</SN>\n" +
                "  <DeviceID>34020000001320000001</DeviceID>\n" +
                "  <Capture>\n" +
                "    <PictureType>JPEG</PictureType>\n" +
                "  </Capture>\n" +
                "</Control>";
        request.setContent(xmlContent, headerFactory.createContentTypeHeader("Application", "MANSCDP+xml"));

        // 发送请求
        ClientTransaction clientTransaction = sipProvider.getNewClientTransaction(request);
        clientTransaction.sendRequest();
    }

    @Override
    public void processRequest(RequestEvent requestEvent) {
        // 处理设备返回的响应
        Request request = requestEvent.getRequest();
        System.out.println("Received request: " + request);
    }

    @Override
    public void processResponse(ResponseEvent responseEvent) {
        // 处理设备返回的响应
        Response response = responseEvent.getResponse();
        System.out.println("Received response: " + response);
    }

    @Override
    public void processTimeout(TimeoutEvent timeoutEvent) {
        System.out.println("Timeout occurred");
    }

    @Override
    public void processIOException(IOExceptionEvent ioExceptionEvent) {
        System.out.println("IO exception occurred");
    }

    @Override
    public void processTransactionTerminated(TransactionTerminatedEvent transactionTerminatedEvent) {
        System.out.println("Transaction terminated");
    }

    @Override
    public void processDialogTerminated(DialogTerminatedEvent dialogTerminatedEvent) {
        System.out.println("Dialog terminated");
    }

    public static void main(String[] args) throws Exception {
        GB28181Capture client = new GB28181Capture();
        client.init();
        client.sendCaptureCommand();
    }
}