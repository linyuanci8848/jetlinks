package com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.impl.info;

import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.bean.*;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.event.SipSubscribe;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.session.VideoStreamSessionManager;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.SIPProcessorObserver;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.cmd.impl.SIPCommander;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.ISIPRequestProcessor;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.transmit.event.request.SIPRequestProcessorParent;
import com.link.anything.middleware.stream.media.protocol.gb28181.sip.utils.SipUtils;
import gov.nist.javax.sip.message.SIPRequest;
import java.text.ParseException;
import javax.sip.InvalidArgumentException;
import javax.sip.RequestEvent;
import javax.sip.SipException;
import javax.sip.header.CallIdHeader;
import javax.sip.header.ContentTypeHeader;
import javax.sip.message.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import javax.annotation.Resource;
import org.springframework.stereotype.Component;

@Component
public class InfoRequestProcessor extends SIPRequestProcessorParent implements InitializingBean, ISIPRequestProcessor {

  private final static Logger logger = LoggerFactory.getLogger(InfoRequestProcessor.class);

  private final String method = "INFO";

  @Resource
  private SIPProcessorObserver sipProcessorObserver;


  @Resource
  private SipSubscribe sipSubscribe;


  @Resource
  private SIPCommander cmder;

  @Resource
  private IDeviceManager deviceManager;

  @Resource
  private VideoStreamSessionManager sessionManager;

  @Resource
  private IStreamSessionManager streamSessionManager;

  @Override
  public void afterPropertiesSet() throws Exception {
    // 添加消息处理的订阅
    sipProcessorObserver.addRequestProcessor(method, this);
  }

  @Override
  public void process(RequestEvent evt) {
    logger.debug("接收到消息：" + evt.getRequest());
    SIPRequest request = (SIPRequest) evt.getRequest();
    String deviceId = SipUtils.getUserIdFromFromHeader(request);
    CallIdHeader callIdHeader = request.getCallIdHeader();
    // 先从会话内查找
    SsrcTransaction ssrcTransaction = sessionManager.getSsrcTransaction(null, null, callIdHeader.getCallId(), null);

    // 兼容海康 媒体通知 消息from字段不是设备ID的问题
    if (ssrcTransaction != null) {
      deviceId = ssrcTransaction.getDeviceId();
    }
    // 查询设备是否存在
    Device device = deviceManager.findDevice(deviceId);
    // 查询上级平台是否存在

    try {
      if (device == null) {
        // 不存在则回复404
        responseAck(request, Response.NOT_FOUND, "device " + deviceId + " not found");
        logger.warn("[设备未找到 ]： {}", deviceId);
        if (sipSubscribe.getErrorSubscribe(callIdHeader.getCallId()) != null) {
          DeviceNotFoundEvent deviceNotFoundEvent = new DeviceNotFoundEvent(evt.getDialog());
          deviceNotFoundEvent.setCallId(callIdHeader.getCallId());
          SipSubscribe.EventResult eventResult = new SipSubscribe.EventResult(deviceNotFoundEvent);
          sipSubscribe.getErrorSubscribe(callIdHeader.getCallId()).response(eventResult);
        }
      } else {
        ContentTypeHeader header = (ContentTypeHeader) evt.getRequest().getHeader(ContentTypeHeader.NAME);
        String contentType = header.getContentType();
        String contentSubType = header.getContentSubType();
        if ("Application".equalsIgnoreCase(contentType) && "MANSRTSP".equalsIgnoreCase(contentSubType)) {
          SendRtpItem sendRtpItem = null;
          String streamId = sendRtpItem.getStreamId();
          StreamSession streamSession = streamSessionManager.getSession(streamId);
          if (null == streamSession) {
            responseAck(request, Response.NOT_FOUND, "stream " + streamId + " not found");
            return;
          }
          Device device1 = deviceManager.findDevice(streamSession.getDevice());
          cmder.playbackControlCmd(device1, streamSession, new String(evt.getRequest().getRawContent()), eventResult -> {
            // 失败的回复
            try {
              responseAck(request, eventResult.statusCode, eventResult.msg);
            } catch (SipException | InvalidArgumentException | ParseException e) {
              logger.error("[命令发送失败] 国标级联 录像控制: {}", e.getMessage());
            }
          }, eventResult -> {
            // 成功的回复
            try {
              responseAck(request, eventResult.statusCode);
            } catch (SipException | InvalidArgumentException | ParseException e) {
              logger.error("[命令发送失败] 国标级联 录像控制: {}", e.getMessage());
            }
          });

        }
      }
    } catch (SipException e) {
      logger.warn("SIP 回复错误", e);
    } catch (InvalidArgumentException e) {
      logger.warn("参数无效", e);
    } catch (ParseException e) {
      logger.warn("SIP回复时解析异常", e);
    }
  }


}
