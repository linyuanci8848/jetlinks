package com.link.anything.middleware.stream.media.protocol.hikvision.rest;

import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.hikvision.artemis.sdk.ArtemisHttpUtil;
import com.link.anything.common.utils.JSONUtils;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.PTZStreamControl;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import com.link.anything.middleware.stream.media.common.exception.ThirdPartyCallException;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.protocol.entity.MediaEncoding;
import com.link.anything.middleware.stream.media.server.constant.HikvisionPTZCommand;
import com.link.anything.middleware.stream.media.server.constant.HikvisionStreamType;
import com.link.anything.middleware.stream.media.server.constant.HikvisionTransmode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

import java.net.MalformedURLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 简介
 *
 * @author linyuanci
 */
@Slf4j
public class ArtemisPost {

    private static DateTimeFormatter dateTimeFormatter = new DateTimeFormatterBuilder()
            .parseCaseInsensitive()
            .append(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
            .appendLiteral(".")
            .appendValue(ChronoField.MILLI_OF_SECOND, 3)
            .appendOffsetId()
            .toFormatter();

    /**
     * API网关的后端服务上下文为：/artemis
     */
    private static final String ARTEMIS_PATH = "/artemis";

    public static String previewRtspURL(String channelNo) {
        final String  getCamsApi = ARTEMIS_PATH + "/api/vnsc/mls/v1/preview/openApi/getPreviewParam";
        JSONObject paramMap = new JSONObject();// post请求Form表单参数
        paramMap.set("indexCode", channelNo);
        paramMap.set("streamType", HikvisionStreamType.PRIMARY);
        paramMap.set("protocol", "rtsp");
        paramMap.set("transmode", HikvisionTransmode.TCP);
        String body = paramMap.toString();
        Map<String, String> path = new HashMap<String, String>(2) {
            {
                put("https://", getCamsApi);
            }
        };
        String resp = ArtemisHttpUtil.doPostStringArtemis(path, body, null, null, "application/json");
        Map<String, Object> respMap = JSONUtil.parseObj(resp);
        String code = (String) respMap.get("code");
        Object dataObj = respMap.get("data");
        if ("0".equals(code) && dataObj != null) {
            Map<?, ?> data = (Map<?, ?>) respMap.get("data");
            return (String) data.get("url");
        }
        throw new ThirdPartyCallException(formatResp(respMap));
    }

    public static String playbackRtspURL(String channelNo, LocalDateTime start, LocalDateTime end) {
        final String  getCamsApi = ARTEMIS_PATH + "/api/video/v1/cameras/playbackURLs";
        Map<String, Object> paramMap = new HashMap<>();// post请求Form表单参数
        paramMap.put("cameraIndexCode", channelNo);
        paramMap.put("beginTime", start.atZone(ZoneId.systemDefault()).format(dateTimeFormatter));
        paramMap.put("endTime", end.atZone(ZoneId.systemDefault()).format(dateTimeFormatter));
        String body = JSONUtils.convert(paramMap);
        Map<String, String> path = new HashMap<String, String>(2) {
            {
                put("https://", getCamsApi);
            }
        };
        String resp = ArtemisHttpUtil.doPostStringArtemis(path, body, null, null, "application/json");
        Map<String, Object> respMap = JSONUtil.parseObj(resp);
        String code = (String) respMap.get("code");
        Object dataObj = respMap.get("data");
        if ("0".equals(code) && dataObj != null) {
            Map<?, ?> data = (Map<?, ?>) respMap.get("data");
            return (String) data.get("url");
        }
        throw new ThirdPartyCallException(formatResp(respMap));
    }

    public static List<VideoFragment> playbackRtspFragments(String channelNo, LocalDateTime start, LocalDateTime end) {
        final String  getCamsApi = ARTEMIS_PATH + "/api/video/v1/cameras/playbackURLs";
        List<VideoFragment> fragments = new ArrayList<>();
        Map<String, Object> paramMap = new HashMap<>();// post请求Form表单参数
        paramMap.put("cameraIndexCode", channelNo);
        paramMap.put("beginTime", start.atZone(ZoneId.systemDefault()).format(dateTimeFormatter));
        paramMap.put("endTime", end.atZone(ZoneId.systemDefault()).format(dateTimeFormatter));
        Map<String, String> path = new HashMap<String, String>(2) {
            {
                put("https://", getCamsApi);
            }
        };
        String body = JSONUtils.convert(paramMap);
        String resp = ArtemisHttpUtil.doPostStringArtemis(path, body, null, null, "application/json");
        Map<String, Object> respMap = JSONUtil.parseObj(resp);
        String code = (String) respMap.get("code");
        Object dataObj = respMap.get("data");
        if ("0".equals(code) && dataObj != null) {
            Map<?, ?> data = (Map<?, ?>) respMap.get("data");
            List<?> list = (List<?>) data.get("list");
            if (list == null) {
                return fragments;
            }
            for (Object object : list) {
                Map<?, ?> fragmentMap = (Map<?, ?>) object;
                String beginTime = (String) fragmentMap.get("beginTime");
                String endTime = (String) fragmentMap.get("endTime");
                Object sizeValue = fragmentMap.get("size");
                if (sizeValue == null) {
                    continue;
                }
                long size = Long.parseLong(sizeValue.toString());
                VideoFragment fragment = new VideoFragment();
                fragment.setChannel(channelNo).setStart(LocalDateTime.parse(beginTime, DateTimeFormatter.ISO_OFFSET_DATE_TIME));
                fragment.setSize(size).setEnd(LocalDateTime.parse(endTime, DateTimeFormatter.ISO_OFFSET_DATE_TIME));
                fragments.add(fragment);
            }
            return fragments;
        }
        throw new ThirdPartyCallException(formatResp(respMap));
    }

    public static Map<String, Boolean> getCameraOnlineStatus() {
        Map<String, Boolean> onlineStatusMap = new HashMap<>();
        final String  getCamsApi = ARTEMIS_PATH + "/api/nms/v1/online/camera/get";
        JSONObject paramMap = new JSONObject();// post请求Form表单参数
        paramMap.set("indexCodes", new ArrayList<>());
        paramMap.set("pageNo", 1);
        paramMap.set("pageSize", 1000);
        String body = JSONUtils.convert(paramMap);
        Map<String, String> path = new HashMap<String, String>(2) {
            {
                put("https://", getCamsApi);
            }
        };
        String resp = ArtemisHttpUtil.doPostStringArtemis(path, body, null, null, "application/json");
        Map<String, Object> respMap = JSONUtil.parseObj(resp);
        Map<?, ?> data = (Map<?, ?>) respMap.get("data");
        String code = (String) respMap.get("code");
        if ("0".equals(code) && data != null) {
            List<?> dataList = (List<?>) data.get("list");
            if (dataList == null) {
                return onlineStatusMap;
            }
            for (Object item : dataList) {
                Map<?, ?> itemMap = (Map<?, ?>) item;
                String channelNo = (String) itemMap.get("indexCode");
                Object onlineValue = itemMap.get("online");
                if (onlineValue == null) {
                    continue;
                }
                boolean online = BooleanUtil.toBoolean(onlineValue.toString());
                onlineStatusMap.put(channelNo, online);
            }
            return onlineStatusMap;
        }
        throw new ThirdPartyCallException(formatResp(respMap));
    }

    public static List<Device> getCameras(int pageNo) {
        final String  getCamsApi = ARTEMIS_PATH + "/api/resource/v2/camera/search";
        JSONObject paramMap = new JSONObject();// post请求Form表单参数
        paramMap.set("pageNo", pageNo);
        paramMap.set("pageSize", 1000); // 最多限制1000
        String body = JSONUtils.convert(paramMap);
        Map<String, String> path = new HashMap<String, String>(2) {
            {
                put("https://", getCamsApi);
            }
        };
        String resp = ArtemisHttpUtil.doPostStringArtemis(path, body, null, null, "application/json");
        Map<String, Object> respMap = JSONUtil.parseObj(resp);
        String code = (String) respMap.get("code");
        Object dataObj = respMap.get("data");
        if ("0".equals(code) && dataObj != null) {
            Map<?, ?> data = (Map<?, ?>) respMap.get("data");
            List<Device> deviceList = new ArrayList<>();
            List<?> dataList = (List<?>) data.get("list");
            if (dataList == null) {
                return deviceList;
            }
            for (Object item : dataList) {
                Map<?, ?> itemMap = (Map<?, ?>) item;
                Device device = new Device();
                device.setProtocol(StreamSourceProtocol.HKV);
                // 和设备录入对应上，用于通知设备在线离线
                device.setTerminalNumber((String) itemMap.get("externalIndexCode"));
                device.setName((String) itemMap.get("name"));
                deviceList.add(device);
            }
            return deviceList;
        }
        throw new ThirdPartyCallException(formatResp(respMap));
    }


    public static void controlPTZStream(String channelNo, PTZStreamControl control, Integer speed) {
        final String  getCamsApi = ARTEMIS_PATH + "/api/video/v1/ptzs/controlling";
        JSONObject paramMap = new JSONObject();// post请求Form表单参数
        paramMap.set("cameraIndexCode", channelNo);
        // 0-开始 1-停止 注：GOTO_PRESET命令下填任意值均可转到预置点,建议填0即可
        paramMap.set("action", PTZStreamControl.Stop == control ? 1 : 0);
        HikvisionPTZCommand ptzCommand = HikvisionPTZCommand.of(control);
        if (ptzCommand != null) {
            paramMap.set("command", ptzCommand.name());
        }
        paramMap.set("speed", speed);
        String body = JSONUtils.convert(paramMap);
        Map<String, String> path = new HashMap<String, String>(2) {
            {
                put("https://", getCamsApi);
            }
        };
        String resp = ArtemisHttpUtil.doPostStringArtemis(path, body, null, null, "application/json");
        log.info(resp);
    }

    /**
     * 视频抓图
     */
    public static String manualCaptureAsUrl(String channelNo) {
        final String  getCamsApi = ARTEMIS_PATH + "/api/video/v1/manualCapture";
        JSONObject paramMap = new JSONObject();// post请求Form表单参数
        paramMap.set("cameraIndexCode", channelNo);
        String body = paramMap.toString();
        Map<String, String> path = new HashMap<String, String>(2) {
            {
                put("https://", getCamsApi);
            }
        };
        String resp = ArtemisHttpUtil.doPostStringArtemis(path, body, null, null, "application/json");
        Map<String, Object> respMap = JSONUtil.parseObj(resp);
        String code = (String) respMap.get("code");
        Object dataObj =respMap.get("data");
        if ("0".equals(code) && dataObj != null) {
            Map<?, ?> data = (Map<?, ?>) respMap.get("data");
            return (String) data.get("picUrl");
        }
        throw new ThirdPartyCallException(formatResp(respMap));
    }

    /**
     * 视频抓图
     */
    public static Resource manualCaptureAsResource(String channelNo) throws MalformedURLException {
        String picUrl = manualCaptureAsUrl(channelNo);
        return new UrlResource(picUrl);
    }


    private static Map<String, Object> formatResp(Map<String, Object> rawResp) {
        Object msg = rawResp.get("msg");
        rawResp.put("message", msg);
        rawResp.remove("msg");
        return rawResp;
    }
}
