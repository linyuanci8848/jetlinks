package com.link.anything.middleware.stream.media.protocol.hikvision.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "middleware.stream.hkv", ignoreInvalidFields = true)
public class HKVTranslationProperties {

  private String host;

  private String appKey;

  private String appSecret;

}
