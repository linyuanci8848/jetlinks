package com.link.anything.middleware.stream.media.protocol.hikvision;

import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.protocol.hikvision.rest.ArtemisPost;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 注册事件监听
 */
@Component
@ConditionalOnProperty(name = "middleware.stream.hkv.enable", havingValue = "true")
@Slf4j
public class HikvisionRunner implements CommandLineRunner {

  @Resource
  private IDeviceManager deviceManager;

  @Override
  public void run(String... args) {
    execute();
  }


  @Scheduled(initialDelayString = "PT5M", fixedDelayString = "PT30S")
  public void execute() {
    try {
      onlineCheck();
    } catch (Exception e) {
      log.warn(e.getMessage(), e);
    }
  }

  private void onlineCheck() {
    Map<String, Boolean> cameraOnlineMap = ArtemisPost.getCameraOnlineStatus();
    List<Device> cameras = ArtemisPost.getCameras(1);
    for (Device camera : cameras) {
      Boolean online = cameraOnlineMap.get(camera.getTerminalNumber());
      if (online == null) {
        continue;
      }
      if (online) {
        deviceManager.online(camera);
      } else {
        deviceManager.offline(camera.getTerminalNumber());
      }
    }
  }
}
