package com.link.anything.middleware.stream.media.protocol.hikvision.configuration;

import com.hikvision.artemis.sdk.config.ArtemisConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 简介
 *
 * @author linyuanci
 */
@Configuration
@Slf4j
@EnableConfigurationProperties(HKVTranslationProperties.class)
public class HikvisionConfig {

    @Bean
    public ArtemisConfig artemisConfig(HKVTranslationProperties hkvTranslationProperties) {
        ArtemisConfig artemisConfig = new ArtemisConfig();
        artemisConfig.setAppKey(hkvTranslationProperties.getAppKey());
        artemisConfig.setAppSecret(hkvTranslationProperties.getAppSecret());
        artemisConfig.setHost(hkvTranslationProperties.getHost());
        return artemisConfig;
    }
}
