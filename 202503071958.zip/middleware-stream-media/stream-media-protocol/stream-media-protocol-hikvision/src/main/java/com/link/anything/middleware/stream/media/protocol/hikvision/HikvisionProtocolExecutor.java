package com.link.anything.middleware.stream.media.protocol.hikvision;

import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamPlayType;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.PTZStreamControl;
import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.common.domain.StreamSession.StreamSessionBuilder;
import com.link.anything.middleware.stream.media.common.domain.StreamSessionApp;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.protocol.IProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.ProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.hikvision.rest.ArtemisPost;
import com.link.anything.middleware.stream.media.server.IMediaServerManager;
import com.link.anything.middleware.stream.media.server.constant.RtpType;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import com.link.anything.middleware.stream.media.server.request.AddStreamProxyRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.net.MalformedURLException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

/**
 * 1078执行器
 */
@ProtocolExecutor(value = StreamSourceProtocol.HKV)
public class HikvisionProtocolExecutor implements IProtocolExecutor {

  Logger logger = LoggerFactory.getLogger(HikvisionProtocolExecutor.class);


  @Resource
  private IMediaServerManager mediaServerManager;

  @Resource
  private IStreamSessionManager streamSessionManager;

  @Override
  public StreamSession openLive(String deviceNumber, String channel, Integer bitStream, StreamSourceProtocol streamSourceProtocol, StreamTransferMethod streamTransferMethod,
      MediaServerInstance instance) {
    StreamSessionBuilder sessionBuilder = StreamSession.builder();
    sessionBuilder.bitstream(bitStream).streamSourceProtocol(streamSourceProtocol).channel(channel).device(deviceNumber);
    sessionBuilder.mediaServerId(instance.getInstanceId()).streamTransferMethod(streamTransferMethod);
    sessionBuilder.receiveIp(instance.getStreamIp()).app(StreamSessionApp.live).streamType(StreamType.Video);
    sessionBuilder.receivePort(instance.getRtpProxyPort());
    // 直接将通道id作为流id
    String streamId = deviceNumber + "_" + channel;
    sessionBuilder.streamId(streamId).ssrc(streamId);
    StreamSession streamSession = streamSessionManager.createSession(sessionBuilder.build());
    try {
      String previewURL = ArtemisPost.previewRtspURL(channel);
      addStreamProxy(instance, streamSession, previewURL);
    } catch (Exception e) {
      String key =  "__defaultVhost__/" + streamSession.getApp().name() +"/" + streamId;
      logger.error("[命令发送失败] 点播消息: {}", e.getMessage());
      boolean flag = mediaServerManager.delStreamProxy(instance, key);
      logger.info("delStreamProxy:{}", flag);
      throw new RuntimeException("点播异常", e);
    }
    return streamSession;
  }

  private void addStreamProxy(MediaServerInstance instance, StreamSession streamSession, String previewURL) {
    String streamId = streamSession.getStreamId();
    String channel = streamSession.getChannel();
    if (mediaServerManager.isStreamReady(instance, streamSession.getApp().name(), streamId)) {
      logger.warn("“流已存在");
      return;
    }
    logger.info("[开始拉流] deviceId: {}, channelId:{}, previewURL：{}", streamSession.getDevice(), channel, previewURL);
    AddStreamProxyRequest request = AddStreamProxyRequest.builder().stream(streamId).rtpType(RtpType.TCP).enableRtsp(true).autoClose(true)
            .app(streamSession.getApp().name()).url(previewURL).retryCount(0).build();
    String key = mediaServerManager.addStreamProxy(instance, request);
    streamSession.setStreamProxyKey(key);
    logger.info("[拉流成功] deviceId: {}, channelId:{}, streamProxyKey：{}", streamSession.getDevice(), channel, key);
  }

  @Override
  public void controlLiveStream(StreamSession streamSession, LiveStreamControl control) {
    switch (control) {
      case CloseAudioAndVideo:
      case PauseStream:
        break;
      case ContinueStream:
        MediaServerInstance instance = mediaServerManager.findMediaServerInstance(streamSession.getMediaServerId());
        String channel = streamSession.getChannel();
        try {
          String previewURL = ArtemisPost.previewRtspURL(channel);
          addStreamProxy(instance, streamSession, previewURL);
        } catch (Exception e) {
          logger.error("[命令发送失败] 点播消息: {}", e.getMessage());
          throw new RuntimeException("点播异常", e);
        }
        break;
      default:
    }

  }

  @Override
  public List<VideoFragment> findVideoHistory(String deviceNumber, String channel, StreamSourceProtocol sourceType, LocalDateTime start, LocalDateTime end, StreamType type, Integer bitStream,
                                              HistoryVideoSource source, Long sq) {
    List<VideoFragment> fragments = ArtemisPost.playbackRtspFragments(channel, start, end);
    for (VideoFragment fragment : fragments) {
      fragment.setSource(HistoryVideoSource.Center);
      fragment.setSourceProtocol(StreamSourceProtocol.HKV);
      fragment.setType(StreamType.Video);
      fragment.setDevice(deviceNumber);
      String key = deviceNumber + "_" + fragment.getChannel() + "_" + fragment.getStart().toEpochSecond(ZoneOffset.ofHours(8)) + "_" + fragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8));
      fragment.setKey(key);
    }
    return fragments;
  }

  @Override
  public StreamSession openHistoryStream(VideoFragment fragment, MediaServerInstance instance, StreamTransferMethod method, HistoryStreamPlayType playType, Integer multiple) {
    StreamSessionBuilder sessionBuilder = StreamSession.builder();
    sessionBuilder.bitstream(fragment.getBitStream()).streamSourceProtocol(fragment.getSourceProtocol()).channel(fragment.getChannel()).device(fragment.getDevice())
        .end(fragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8)));
    sessionBuilder.mediaServerId(instance.getInstanceId()).start(fragment.getStart().toEpochSecond(ZoneOffset.ofHours(8)));
    sessionBuilder.receiveIp(instance.getStreamIp()).app(StreamSessionApp.record).streamType(fragment.getType()).streamSourceProtocol(StreamSourceProtocol.HKV);
    String streamId =
        fragment.getDevice() + "_" + fragment.getChannel() + "_" + fragment.getStart().toEpochSecond(ZoneOffset.ofHours(8)) + "_" + fragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8));
    sessionBuilder.streamId(streamId).streamTransferMethod(method).bitstream(fragment.getBitStream());
    Integer port = mediaServerManager.openRTPServer(instance, streamId, 0, method);
    Assert.notNull(port, "收流端口分配失败");
    sessionBuilder.receivePort(port);
    StreamSession streamSession = streamSessionManager.createSession(sessionBuilder.build());
    try {
      String playbackRtsp = ArtemisPost.playbackRtspURL(fragment.getChannel(), fragment.getStart(), fragment.getEnd());
      addStreamProxy(instance, streamSession, playbackRtsp);
    } catch (Exception e) {
      String key =  "__defaultVhost__/" + streamSession.getApp().name() +"/" + streamId;
      logger.error("[命令发送失败] 点播消息: {}", e.getMessage());
      boolean flag = mediaServerManager.delStreamProxy(instance, key);
      logger.info("delStreamProxy:{}", flag);
      throw new RuntimeException("点播异常", e);
    }
    return streamSession;
  }


  @Override
  public void controlHistoryStream(StreamSession session, HistoryStreamControl control, Integer multiple, Long point) {
    switch (control) {
      case Close:
        try {
          streamSessionManager.removeSession(session.getStreamId());
          String key =  "__defaultVhost__/" + session.getApp().name() +"/" + session.getStreamId();
          boolean flag = mediaServerManager.delStreamProxy(session.getMediaServerId(), key);
          logger.info("delStreamProxy:{}", flag);
          mediaServerManager.closeRTPServer(session.getMediaServerId(), session.getStreamId());
        } catch (Exception ignored) {
        }
        break;
      case KeyframeRewindPlayback:
      case SingleFramePlay:
      case FastForward:
      case Suspend:
      case Play:
      case Drag:
        break;
    }
  }

  @Override
  public void createTalkStream(String device, String channel) {

  }


  @Override
  public void syncDeviceChannel() {

  }


  @Override
  public void controlPTZStream(StreamSession session, PTZStreamControl control, Integer horizonSpeed, Integer zoomSpeed, Integer verticalSpeed) {
    // 云台控制
    try {
      String terminalNumber = session.getChannel();
      ArtemisPost.controlPTZStream(terminalNumber, control, zoomSpeed);
    } catch (Exception e) {
      logger.error("[命令发送失败] 云台控制: " + e.getMessage(), e);
    }
  }

  /**
   * 视频抓图
   */
  @Override
  public org.springframework.core.io.Resource captureAsResource(String channelNo) throws MalformedURLException {
    return ArtemisPost.manualCaptureAsResource(channelNo);
  }
}
