package com.link.anything.middleware.stream.media.protocol.qly.rest;


import cn.hutool.crypto.digest.MD5;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.link.anything.common.utils.http.HttpClientWrapper;
import okhttp3.OkHttpClient;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


/**
 * 简介
 *
 * @author linyuanci
 */
public class QlyClientTest {

    public static void main(String[] args) throws Exception {
        String appid = "02d6f12e15eb4f918924633eb0383923";
        String secret = "mKS5vaSvBxUHBXdE";
        String version = "1.0.0";
        Long timestamp = System.currentTimeMillis();
        try {
            getDeviceList(appid, secret, timestamp, version);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Map<String, Object> createHeaders(String appid, Long timestamp, String version, String md5, String token) {
        Map<String, Object> headers = createHeaders(appid, timestamp, version, md5);
        headers.put("token", token);
        return headers;
    }

    private static Map<String, Object> createHeaders(String appid, Long timestamp, String version, String md5) {
        Map<String, Object> headers = new LinkedHashMap<>();
        headers.put("appid", appid);
        headers.put("md5", md5);
        headers.put("timestamp", timestamp);
        headers.put("version", version);
        return headers;
    }

    private static String getToken(String appid, String secret, Long timestamp, String version) throws Exception {
        HttpClientWrapper httpClientWrapper = new HttpClientWrapper(new OkHttpClient());
        Map<String,Object> body = new HashMap<>();
        body.put("sig", MD5.create().digestHex(appid + secret));
        body.put("operatorType", 1);
        String bodyStr = JSONUtil.toJsonStr(body);
        System.out.println(bodyStr);
        String md5 = MD5.create().digestHex(bodyStr);
        System.out.println(md5);
        Map<String, Object> heads = createHeaders(appid, timestamp, version, md5);
        httpClientWrapper.headers(heads);
        String signature = getSignature(heads);
        httpClientWrapper.header("signature", signature);
        System.out.println(signature);
        String resp = httpClientWrapper.url("https://open.andmu.cn/v3/open/api/token").post(body).asString();
        Map<?, ?> map = JSONUtil.parseObj(resp);
        String resultCode = (String) map.get("resultCode");
        if (!"000000".equals(resultCode)) {
            throw new RuntimeException(resp);
        }
        Map<?, ?> data = (Map<?, ?>) map.get("data");
        return (String) data.get("token");
    }

    private static String getDeviceList(String appid, String secret, Long timestamp, String version) throws Exception {
        String token = getToken(appid, secret, timestamp, version);
        HttpClientWrapper httpClientWrapper = new HttpClientWrapper(new OkHttpClient());
        Map<String,Object> body = new HashMap<>();
        String bodyStr = JSONUtil.toJsonStr(body);
        System.out.println(bodyStr);
        String md5 = MD5.create().digestHex(bodyStr);
        System.out.println(md5);
        Map<String, Object> heads = createHeaders(appid, timestamp, version, md5, token);
        httpClientWrapper.headers(heads);
        httpClientWrapper.header("signature", getSignature(heads));
        String resp = httpClientWrapper.url("https://open.andmu.cn/v3/open/api/device/list").post(body).asString();
        System.out.println(httpClientWrapper.headers());
        Map<?, ?> map = JSONUtil.parseObj(resp);
        String resultCode = (String) map.get("resultCode");
        if (!"000000".equals(resultCode)) {
            throw new RuntimeException(resp);
        }
        Map<?, ?> data = (Map<?, ?>) map.get("data");
        return (String) data.get("token");
    }

    private static String getSignature(Map<String, Object> headers) throws Exception {
        //需要签名字符串
        String jsonString= JSONUtil.toJsonStr(headers);
        System.out.println(jsonString);
        //RSA密钥
        String privateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKlwsFwlRxkub/PXX2bUxsF3KHqZ9UuZsAnagL4ijM5YiwOGV1K+iqXP52mbToD71Abyb2L8qaXl6luX1O2EMQ9/fVrTTPfsokVWF3LdmevAO/wc1o95D+R0SFcmTNBI+jGgeqnquHziI93m87b1u+fLIpw6ISJbaBcDFLG2VfwhAgMBAAECgYBcoKkYxpw2jOdQwxV5TqqVCsILO+0X9h2BVXz59ENLbqYYODG2n0mGWcClP+zLoF+JqLDxyTQo6CaVCcyyR4jVi9in2ZtvWl3UqUgM7WOD/keWhnqfvEGeqPIH2yH32d0KcyU/J6ingsDSNu9DsBMDCkcBtQcJYBj96BFyK7wRfQJBAPhf7kW7fI6wodTCBK3R04D8TZdMoJGAr4rC0asT1oP/R4h/M8YLu+uy9voWJ4vM0kG4WH1hqahPboLWhXlUORsCQQCupGHeYZuQ1vFuw8auDYY5YNEKc0JZlXz2fiYS+pa/wBy/FoE/epAbN138BlIPgNYPysVppBvSdH+mZaR+s09zAkEAkMiDAf0vt5H5VCehSJ3m1+q7ZDYT552HNrEoPby7sIhP756O1KSkb9oMJG5jsRe9fPf0BWq31lgvSG+6sKZK/wJAKe+NFLJJgcErXlaiib7zoSmPaLv+jbZouGPYTqxfsJG4FWaZCJ4spmxoJBF8eP6N6GLffpuKlsGkuVck5cu24wJAPN7cqS9DltIGtMpDP9yIu46yEGe/PaZ8iC/Z+fqGBKzbdELqMFHISSCuSBp2WGs5e8VsGktAmPubI8P8K/xhgw==";
        Base64.Encoder encoder = Base64.getEncoder();
        Base64.Decoder decoder = Base64.getDecoder();
        PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(decoder.decode(privateKey.getBytes()));
        PrivateKey priKey = KeyFactory.getInstance("RSA").generatePrivate(priPKCS8);
        Signature signature = Signature.getInstance("SHA1WithRSA");
        signature.initSign(priKey);
        signature.update(jsonString.getBytes(StandardCharsets.UTF_8));
        return encoder.encodeToString(signature.sign());
    }
}