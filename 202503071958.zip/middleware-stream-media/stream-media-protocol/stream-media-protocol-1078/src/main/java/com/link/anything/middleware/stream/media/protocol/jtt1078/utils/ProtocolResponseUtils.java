package com.link.anything.middleware.stream.media.protocol.jtt1078.utils;

import cn.hutool.core.codec.BCD;
import com.link.anything.common.constant.Parameter;
import com.link.anything.common.utils.ByteUtils;
import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.IProtocolResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;

import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author YcYa_xbj JT808协议下发构建类
 */
@Slf4j
public class ProtocolResponseUtils {

  /**
   * 构建注册应该消息 标识位 消息ID 数据长度 设备号ID 应答消息流水号 终端消息流水号 注册结果 车辆标识 校验码 标识位 7E 8100 0005 056704659339 0000 02AF 00 303134333035333830353434 10 7E
   *
   * @param deviceNumber
   * @param upMessageNumber 终端消息流水号
   * @param result          注册结果
   * @param code            校验码
   * @return
   */
  public static IProtocolResponse<byte[],Byte> buildRegisteredResponse(String deviceNumber, String upMessageNumber, String result, String code) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("8100");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber(upMessageNumber);
    builder.append(ByteUtils.hexStringToByteList(upMessageNumber.concat(result)));
    byte[] codeArray = code.getBytes(Charset.forName("GBK"));
    for (byte b : codeArray) {
        builder.append(b);
    }
    return builder;
  }

  /**
   * 构建通用应答消息消息体 标识位 消息ID 数据长度 设备号ID 应答消息流水号 终端消息流水号 终端消息ID 应答结果 校验码 标识位 7E 8001 0005 056704659339 0000 01A3 0200 00 8D 7E
   *
   * @param deviceNumber
   * @param upMessageNumber
   * @param upMessageId
   * @param result
   * @return
   */
  public static IProtocolResponse<byte[],Byte> buildGeneralResponse(String deviceNumber, String upMessageNumber, String upMessageId, String result) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("8001");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber("0000");
    builder.append(ByteUtils.hexStringToByteList(upMessageNumber.concat(upMessageId).concat(result)));
    return builder;
  }


  /**
   * 构建心跳
   *
   * @param deviceNumber
   * @param upMessageNumber
   * @param upMessageId
   * @param result
   * @return
   */
  public static IProtocolResponse<byte[],Byte> buildHeartbeatResponse(String deviceNumber, String upMessageNumber, String upMessageId, String result) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("8001");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber("0000");
    builder.append(ByteUtils.hexStringToByteList(upMessageNumber.concat(upMessageId).concat(result)));
    return builder;
  }


  /**
   * 构建命令返回
   *
   * @param deviceNumber
   * @param commandKey
   * @return
   */
  public static IProtocolResponse<byte[],Byte> buildCommandResponse(String deviceNumber, String commandKey, List<Parameter> parameters) {
    IProtocolResponse<byte[],Byte> response = null;
    Map<String, String> parameterMap = parameters.stream().collect(Collectors.toMap(Parameter::getKey, Parameter::getValue));
    switch (commandKey) {
      case "Open":
        response = buildPlayCommand(deviceNumber, parameterMap);
        break;
      case "Close":
        response = buildCloseCommand(deviceNumber, parameterMap);
        break;
      case "QueryHistory":
        response = buildQueryHistoryCommand(deviceNumber, parameterMap);
        break;
      case "OpenHistory":
        response = buildPlayHistoryCommand(deviceNumber, parameterMap);
        break;
      case "ControlLiveStream":
        response = buildControlLiveStreamCommand(deviceNumber, parameterMap);
        break;
      case "ControlHistoryStream":
        response = buildControlHistoryStreamCommand(deviceNumber, parameterMap);
        break;
    }
    return response;
  }

  private static IProtocolResponse<byte[],Byte> buildPlayCommand(String deviceNumber, Map<String, String> parameters) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("9101");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber("0000");
    byte[] ips = parameters.get("ip").getBytes(Charset.forName("GBK"));
    builder.append(Integer.valueOf(ips.length).byteValue());
    for (byte ip : ips) {
        builder.append(ip);
    }
    byte[] port = ByteUtils.intToByteArray(Integer.parseInt(parameters.get("tcp")));
    builder.append(port[2]);
    builder.append(port[3]);
    port = ByteUtils.intToByteArray(Integer.parseInt(parameters.get("udp")));
    builder.append(port[2]);
    builder.append(port[3]);

    builder.append(Integer.valueOf(parameters.get("channel")).byteValue());
    Assert.isTrue(!parameters.get("dataType").equals("Audio"), "JTT1078不支持单独的音频");
    switch (parameters.get("dataType")) {
      case "Video":
        builder.append((byte) 0x01);
        break;
      case "VideoAndAudio":
        builder.append((byte) 0x00);
        break;
      case "TwoWayIntercom":
        builder.append((byte) 0x02);
        break;
      case "Monitor":
        builder.append((byte) 0x03);
        break;
      case "CentralBroadcasting":
        builder.append((byte) 0x04);
        break;
      case "Transparent":
        builder.append((byte) 0x05);
        break;

    }

    builder.append(Integer.valueOf(parameters.get("bitStream")).byteValue());
    return builder;
  }

  private static IProtocolResponse<byte[],Byte> buildCloseCommand(String deviceNumber, Map<String, String> parameters) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("9102");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber("0000");
    builder.append(Integer.valueOf(parameters.get("channel")).byteValue());
    builder.append(Integer.valueOf(parameters.get("action")).byteValue());
    switch (parameters.get("dataType")) {
      case "Video":
        builder.append((byte) 0x01);
        break;
      case "Audio":
        break;
      case "VideoAndAudio":
        builder.append((byte) 0x00);
        break;
      case "TwoWayIntercom":
        builder.append((byte) 0x02);
        break;
      case "Monitor":
        builder.append((byte) 0x03);
        break;
      case "CentralBroadcasting":
        builder.append((byte) 0x04);
        break;
      case "Transparent":
        builder.append((byte) 0x05);
        break;
    }
    builder.append(Integer.valueOf(parameters.get("bitStream")).byteValue());

    return builder;
  }

  private static IProtocolResponse<byte[],Byte> buildQueryHistoryCommand(String deviceNumber, Map<String, String> parameters) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("9205");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber(toHexMessageNumber(Long.valueOf(parameters.get("sq"))));
    builder.append(Byte.valueOf(Integer.toHexString(Integer.valueOf(parameters.get("channel"))), 16));
    builder.append(BCD.strToBcd(parameters.get("start")));
    builder.append(BCD.strToBcd(parameters.get("end")));
    //TODO 报警位
    builder.append((byte) 0x00);
    builder.append((byte) 0x00);
    builder.append((byte) 0x00);
    builder.append((byte) 0x00);
    builder.append((byte) 0x00);
    builder.append((byte) 0x00);
    builder.append((byte) 0x00);
    builder.append((byte) 0x00);
    switch (parameters.get("dataType")) {
      case "Video":
        builder.append((byte) 0x01);
        break;
      case "Audio":
        break;
      case "VideoAndAudio":
        builder.append((byte) 0x00);
        break;
      case "TwoWayIntercom":
        builder.append((byte) 0x02);
        break;
      case "Monitor":
        builder.append((byte) 0x03);
        break;
      case "CentralBroadcasting":
        builder.append((byte) 0x04);
        break;
      case "Transparent":
        builder.append((byte) 0x05);
        break;
    }
    builder.append(Byte.valueOf(Integer.toHexString(Integer.parseInt(parameters.get("bitStream"))), 16));
    builder.append((byte) 0x01);
    return builder;
  }

  private static IProtocolResponse<byte[],Byte> buildPlayHistoryCommand(String deviceNumber, Map<String, String> parameters) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("9201");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber("0000");
    byte[] ips = parameters.get("ip").getBytes(Charset.forName("GBK"));
    builder.append(Integer.valueOf(ips.length).byteValue());
    for (byte ip : ips) {
        builder.append(ip);
    }
    byte[] port = ByteUtils.intToByteArray(Integer.parseInt(parameters.get("tcp")));
    builder.append(port[2]);
    builder.append(port[3]);
    port = ByteUtils.intToByteArray(Integer.parseInt(parameters.get("udp")));
    builder.append(port[2]);
    builder.append(port[3]);

    builder.append(Integer.valueOf(parameters.get("channel")).byteValue());
    switch (parameters.get("dataType")) {
      case "Video":
        builder.append((byte) 0x01);
        break;
      case "Audio":

        break;
      case "VideoAndAudio":
        builder.append((byte) 0x00);
        break;
      case "TwoWayIntercom":
        builder.append((byte) 0x02);
        break;
      case "Monitor":
        builder.append((byte) 0x03);
        break;
      case "CentralBroadcasting":
        builder.append((byte) 0x04);
        break;
      case "Transparent":
        builder.append((byte) 0x05);
        break;

    }

    builder.append(Integer.valueOf(parameters.get("bitStream")).byteValue());
    builder.append((byte) 0x00);
    switch (parameters.get("playType")) {
      case "Normal":
        builder.append((byte) 0x00);
        parameters.put("multiple", "0");
        break;
      case "FastForward":
        builder.append((byte) 0x01);
        break;
      case "KeyFramesFastBack":
        builder.append((byte) 0x02);
        break;
      case "KeyFrames":
        builder.append((byte) 0x03);
        parameters.put("multiple", "0");
        break;
      case "SingleFrame":
        builder.append((byte) 0x04);
        parameters.put("multiple", "0");
        break;
    }
    builder.append(Integer.valueOf(parameters.get("multiple")).byteValue());
    builder.append(BCD.strToBcd(parameters.get("start")));
    builder.append(BCD.strToBcd(parameters.get("end")));
    return builder;
  }

  private static IProtocolResponse<byte[],Byte> buildControlLiveStreamCommand(String deviceNumber, Map<String, String> parameters) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("9102");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber("0000");
    builder.append(Integer.valueOf(parameters.get("channel")).byteValue());
    builder.append(Integer.valueOf(parameters.get("1")).byteValue());
    builder.append(Integer.valueOf(parameters.get("2")).byteValue());
    builder.append(Integer.valueOf(parameters.get("3")).byteValue());
    return builder;
  }

  private static IProtocolResponse<byte[],Byte> buildControlHistoryStreamCommand(String deviceNumber, Map<String, String> parameters) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("9202");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber("0000");
    builder.append(Integer.valueOf(parameters.get("channel")).byteValue());
    builder.append(Integer.valueOf(parameters.get("1")).byteValue());
    builder.append(Integer.valueOf(parameters.get("2")).byteValue());
    builder.append(BCD.strToBcd(parameters.get("3")));
    return builder;
  }

  /**
   * 消息流水处理
   *
   * @param value
   * @return
   */
  private static String toHexMessageNumber(Long value) {
    String hexValue = Long.toHexString(value);
    if (hexValue.length() % 2 != 0) {
      hexValue = "0" + hexValue;
    }
    if (hexValue.length() < 4) {
      hexValue = "00" + hexValue;
    }
    return hexValue;
  }

  /**
   * 下发抓拍指令
   *
   * @param deviceNumber  设备号
   * @param messageNumber 消息流水
   * @param channel       通道号
   * @param cmd           抓拍指令
   * @param time          抓拍时间
   * @return
   */
  public static IProtocolResponse<byte[],Byte> buildSnapshotResponse(String deviceNumber, String messageNumber, byte channel, short cmd, short time) {
    JT1078Response builder = new JT1078Response();
    builder.setMessageid("8801");
    builder.setDeviceNumber(deviceNumber);
    builder.setMessageNumber(String.format("%4s", messageNumber).replaceAll("\\s", "1"));
    builder.append(channel);
    byte[] cmdByte = new byte[]{(byte) (cmd >>> 8 & 255), (byte) (cmd & 255)};
    builder.append(cmdByte);
    byte[] timeByte = new byte[]{(byte) (time >>> 8 & 255), (byte) (time & 255)};
    builder.append(timeByte);
    builder.append((byte) 0);
    builder.append((byte) 4);
    builder.append((byte) 1);
    builder.append((byte) 255);
    builder.append((byte) 0);
    builder.append((byte) 127);
    builder.append((byte) 255);
    return builder;
  }
}
