package com.link.anything.middleware.stream.media.protocol.jtt1078.handler;

import com.link.anything.middleware.stream.media.protocol.jtt1078.utils.ProtocolUtils;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.util.ByteProcessor;
import java.util.List;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author YcYa_xbj 这个类的实例是每个连接都持有一个，所以不存在线程安全问题
 */


@NoArgsConstructor
public class ProtocolByteDecoder extends ByteToMessageDecoder {

  private final static Logger logger = LoggerFactory.getLogger(ProtocolByteDecoder.class);
  private byte mark = 0x7e;

  @Override
  protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) {
    byte[] data = new byte[in.readableBytes()];
    in.getBytes(in.readerIndex(), data);
    int startIndex = in.forEachByte(in.readerIndex(), in.readableBytes(), new ByteProcessor.IndexOfProcessor(mark));
    if (startIndex < 0) {
      //未找到标识符直接全部跳过
      in.skipBytes(in.readableBytes());
      logger.warn("{} FORMAT-ERROR {}", ctx.channel().remoteAddress().toString(), ByteBufUtil.hexDump(data));
      //非法数据直接关闭这个连接
      ctx.close();
      return;
    }
    //查找结束符
    int endIndex = in.forEachByte(startIndex + 1, in.readableBytes() - 1, new ByteProcessor.IndexOfProcessor(mark));
    //未找到结束标识符 继续等待接收
    if (endIndex < 2) {
      return;
    }
    data = new byte[endIndex - startIndex + 1];
    in.readBytes(data);
    logger.debug("{} 转义前DO       {}", ctx.channel().remoteAddress().toString(), ByteBufUtil.hexDump(data));
    //进行反向转义
    data = ProtocolUtils.unescape(data);
    //校验校验码
    byte comparison = data[1];
    for (int i = 2; i < data.length - 2; i++) {
      comparison = (byte) (comparison ^ data[i]);
    }
    if (comparison != data[data.length - 2]) {
      //校验码未通过，抛弃这条数据
      logger.error("{} CHECK-ERROR    {}", ctx.channel().remoteAddress().toString(), ByteBufUtil.hexDump(data));
      return;
    }
    logger.debug("{} DO             {}", ctx.channel().remoteAddress().toString(), ByteBufUtil.hexDump(data));
    out.add(data);
  }
}
