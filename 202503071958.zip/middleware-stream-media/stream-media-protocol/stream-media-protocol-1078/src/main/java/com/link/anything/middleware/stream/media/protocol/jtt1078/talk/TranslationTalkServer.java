package com.link.anything.middleware.stream.media.protocol.jtt1078.talk;


import com.link.anything.middleware.stream.media.protocol.jtt1078.configuration.JTT1078TranslationProperties;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.concurrent.TimeUnit;


@Slf4j
@Service
@ConditionalOnProperty("middleware.stream.jtt1078.talk.enable")
public class TranslationTalkServer {

  private final LoggingHandler loggingHandler;
  private final JTT1078TranslationProperties translationConfig;
  NioEventLoopGroup boss = new NioEventLoopGroup();
  NioEventLoopGroup worker = new NioEventLoopGroup();

  private TalkStreamHandler talkStreamContainer;

  public TranslationTalkServer(JTT1078TranslationProperties translationConfig, TalkStreamHandler talkStreamContainer) {
    this.talkStreamContainer = talkStreamContainer;
    this.loggingHandler = new LoggingHandler(LogLevel.DEBUG);
    this.translationConfig = translationConfig;
  }

  public void start() {
    try {
      // 服务器
      ServerBootstrap serverBootstrap = new ServerBootstrap();
      // 通道
      serverBootstrap.channel(NioServerSocketChannel.class);
      // 工作组
      serverBootstrap.group(boss, worker).option(ChannelOption.SO_SNDBUF, 320);
      serverBootstrap.childHandler(new ChannelInitializer<SocketChannel>() {

        @Override
        protected void initChannel(SocketChannel socketChannel) {
          ChannelPipeline pipeline = socketChannel.pipeline();
          pipeline.addLast(loggingHandler);
          // 添加心跳响应 10秒响应一次心跳
          pipeline.addLast(new IdleStateHandler(10, 0, 0, TimeUnit.SECONDS));
          pipeline.addLast(new LengthDecoder());
          // 解析报文转换为数据实体
          pipeline.addLast(new TalkStreamCodec());
          pipeline.addLast(talkStreamContainer);
        }
      });

      ChannelFuture channelFuture = serverBootstrap.bind(translationConfig.getAudioPort()).sync();
      log.info("JTT1078车载对讲服务启动成功 port:{}", translationConfig.getAudioPort());
      // 优雅的关闭服务器
      Channel channel = channelFuture.channel();
      channel.closeFuture().addListener((ChannelFutureListener) channelFuture1 -> {
        log.info("---------------关闭JTT1078车载对讲服务---------------");
        boss.shutdownGracefully();
        worker.shutdownGracefully();
      });
    } catch (Exception e) {
      log.error("---------------JTT1078车载对讲服务启动失败---------------", e);
    }

  }

  @PreDestroy
  public void shutdown() {
    boss.shutdownGracefully();
    worker.shutdownGracefully();
  }
}
