package com.link.anything.middleware.stream.media.protocol.jtt1078.handler;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelId;
import io.netty.util.AttributeKey;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author YcYa_xbj 连接管理器
 */
@Slf4j
@Component
public class ProtocolConnectionManager {

  public Map<String, ChannelHandlerContext> contexts = new ConcurrentHashMap<>();

  /**
   * 加入连接
   *
   * @param deviceNumber
   * @param context
   * @return 新连接 就是true 新旧替换就是 false
   */
  public synchronized boolean join(String deviceNumber, ChannelHandlerContext context) {
    if (!contexts.containsKey(deviceNumber)) {
      contexts.put(deviceNumber, context);
      return true;
    }
    Channel channel = contexts.get(deviceNumber).channel();
    //重复注册的话不做处理
    if (!context.channel().id().equals(channel.id())) {
      contexts.put(deviceNumber, context);
      try {
        //新旧连接替换的时候关闭旧的连接会触发发送连接离线状态 所以要把这个值去掉 这样旧连接关闭的时候就不会发生这个状态到业务服务器
        channel.attr(AttributeKey.valueOf("deviceNumber")).remove();
        channel.close().get(1000, TimeUnit.MILLISECONDS);
      } catch (Exception e) {
        log.error(e.getMessage(), e);
      }
    }
    return false;
  }

  /**
   * 提出链接
   *
   * @param deviceNumber
   * @param id
   */
  public synchronized void kick(String deviceNumber, ChannelId id) {
    if (!contexts.containsKey(deviceNumber)) {
      return;
    }
    ChannelHandlerContext context = contexts.get(deviceNumber);
    if (context.channel().id().equals(id)) {
      //context.close();
    }
    contexts.remove(deviceNumber);
  }

  public synchronized ChannelHandlerContext select(String deviceNumber) {
    return contexts.get(deviceNumber);
  }

}
