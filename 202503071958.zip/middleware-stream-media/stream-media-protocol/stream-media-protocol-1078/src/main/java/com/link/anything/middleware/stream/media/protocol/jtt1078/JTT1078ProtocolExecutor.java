package com.link.anything.middleware.stream.media.protocol.jtt1078;

import com.link.anything.common.constant.Command;
import com.link.anything.middleware.stream.media.common.CommandBuilder;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.HistoryStreamPlayType;
import com.link.anything.middleware.stream.media.common.domain.PTZStreamControl;
import com.link.anything.middleware.stream.media.common.domain.StreamSession;
import com.link.anything.middleware.stream.media.common.domain.StreamSession.StreamSessionBuilder;
import com.link.anything.middleware.stream.media.common.domain.StreamSessionApp;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.IStreamSessionManager;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.protocol.IProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.ProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.jtt1078.configuration.JTT1078TranslationProperties;
import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.IProtocolResponse;
import com.link.anything.middleware.stream.media.protocol.jtt1078.forward.ForwardService;
import com.link.anything.middleware.stream.media.protocol.jtt1078.handler.ProtocolConnectionManager;
import com.link.anything.middleware.stream.media.protocol.jtt1078.utils.ProtocolResponseUtils;
import com.link.anything.middleware.stream.media.server.IMediaServerManager;
import com.link.anything.middleware.stream.media.server.domain.MediaServerInstance;
import io.netty.channel.ChannelHandlerContext;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.util.Assert;

/**
 * 1078执行器
 */
@ProtocolExecutor(value = StreamSourceProtocol.JTT1078)
public class JTT1078ProtocolExecutor implements IProtocolExecutor {

  @Resource
  private ProtocolConnectionManager protocolConnectionManager;
  @Resource
  private JTT1078TranslationProperties jtt1078TranslationProperties;

  @Resource
  private IMediaServerManager mediaServerManager;
  @Resource
  private IStreamSessionManager streamSessionManager;

  @Resource
  private IDeviceManager deviceManager;

  @Resource
  private ForwardService forwardService;

  @Override
  public StreamSession openLive(String deviceNumber, String channel, Integer bitStream, StreamSourceProtocol streamSourceProtocol, StreamTransferMethod streamTransferMethod,
      MediaServerInstance instance) {
    Assert.isTrue(deviceManager.isOnline(deviceNumber), "当前设备可能存在信号不佳或已熄火的情况，请稍后重试。");
    StreamSessionBuilder sessionBuilder = StreamSession.builder();
    sessionBuilder.bitstream(bitStream).streamSourceProtocol(streamSourceProtocol).channel(channel).device(deviceNumber);
    sessionBuilder.mediaServerId(instance.getInstanceId()).streamTransferMethod(streamTransferMethod).streamId(deviceNumber + "_" + channel);
    sessionBuilder.receiveIp(instance.getStreamIp()).receivePort(instance.getRtpProxyPort()).app(StreamSessionApp.live).streamType(StreamType.Video);
    if (streamSourceProtocol.equals(StreamSourceProtocol.JTT1078)) {
      sessionBuilder.streamType(StreamType.VideoAndAudio);
    }
    StreamSession streamSession = streamSessionManager.createSession(sessionBuilder.build());
    CommandBuilder builder = CommandBuilder.newBuilder("Open").appendParameter("device", streamSession.getDevice()).appendParameter("channel", streamSession.getChannel())
        .appendParameter("bitStream", streamSession.getBitstream().toString());
    builder.appendParameter("dataType", streamSession.getStreamType().toString()).appendParameter("ip", streamSession.getReceiveIp()).appendParameter("udp", "00");
    builder.appendParameter("tcp", streamSession.getReceivePort() + "");
    Command command = builder.build();
    IProtocolResponse<byte[],Byte> protocolResponse = ProtocolResponseUtils.buildCommandResponse(streamSession.getDevice(), command.getKey(), command.getParameters());
    ChannelHandlerContext context = protocolConnectionManager.select(deviceNumber);
    if (context != null) {
      context.writeAndFlush(protocolResponse);
    } else {
      forwardService.response(protocolResponse);
    }
    return streamSession;
  }

  @Override
  public void controlLiveStream(StreamSession streamSession, LiveStreamControl control) {

    CommandBuilder builder = CommandBuilder.newBuilder("ControlLiveStream").appendParameter("device", streamSession.getDevice()).appendParameter("channel", streamSession.getChannel());
    switch (control) {
      case CloseAudio:
        builder.appendParameter("1", "0").appendParameter("2", "1").appendParameter("3", "0");
        streamSessionManager.removeSession(streamSession.getStreamId());
        break;
      case PauseStream:
        builder.appendParameter("1", "2").appendParameter("2", "0").appendParameter("3", "0");
        break;
      case CLoseVideo:
        builder.appendParameter("1", "0").appendParameter("2", "2").appendParameter("3", "0");
        streamSessionManager.removeSession(streamSession.getStreamId());
        break;
      case CloseAudioAndVideo:
        builder.appendParameter("1", "0").appendParameter("2", "0").appendParameter("3", "0");
        streamSessionManager.removeSession(streamSession.getStreamId());
        break;
      case ContinueStream:
        builder.appendParameter("1", "3").appendParameter("2", "0").appendParameter("3", "0");
        break;
      case ChangeBitStream:
        builder.appendParameter("1", "1").appendParameter("2", "0").appendParameter("3", streamSession.getBitstream().toString());
        break;
//      case CloseWalkingTalkie:
//        builder.appendParameter("1", "4").appendParameter("2", "0").appendParameter("3", "0");
//        break;
    }
    if (deviceManager.isOnline(streamSession.getDevice())) {
      Command command = builder.build();
      IProtocolResponse<byte[],Byte> protocolResponse = ProtocolResponseUtils.buildCommandResponse(streamSession.getDevice(), command.getKey(), command.getParameters());
      ChannelHandlerContext context = protocolConnectionManager.select(streamSession.getDevice());
      if (context != null) {
        context.writeAndFlush(protocolResponse);
      } else {
        forwardService.response(protocolResponse);
      }
    }
  }


  @Override
  public List<VideoFragment> findVideoHistory(String deviceNumber, String channel, StreamSourceProtocol sourceType, LocalDateTime start, LocalDateTime end, StreamType type, Integer bitStream,
                                              HistoryVideoSource source, Long sq) {
    Assert.isTrue(deviceManager.isOnline(deviceNumber), "当前设备可能存在信号不佳或已熄火的情况，请稍后重试。");
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
    CommandBuilder builder = CommandBuilder.newBuilder("QueryHistory").appendParameter("device", deviceNumber).appendParameter("channel", channel)
        .appendParameter("bitStream", bitStream.toString());
    builder.appendParameter("start", start.format(dateTimeFormatter)).appendParameter("end", end.format(dateTimeFormatter)).appendParameter("alarm", "0").appendParameter("dataType", type.name())
        .appendParameter("deviceSource", "0").appendParameter("sq", sq.toString());
    Command command = builder.build();
    IProtocolResponse<byte[],Byte> protocolResponse = ProtocolResponseUtils.buildCommandResponse(deviceNumber, command.getKey(), command.getParameters());
    ChannelHandlerContext context = protocolConnectionManager.select(deviceNumber);
    if (context != null) {
      context.writeAndFlush(protocolResponse);
    } else {
      forwardService.response(protocolResponse);
    }
      return null;
  }

  @Override
  public StreamSession openHistoryStream(VideoFragment fragment, MediaServerInstance instance, StreamTransferMethod method, HistoryStreamPlayType playType, Integer multiple) {

    Assert.isTrue(deviceManager.isOnline(fragment.getDevice()), "当前设备可能存在信号不佳或已熄火的情况，请稍后重试。");
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");

    StreamSessionBuilder sessionBuilder = StreamSession.builder();
    sessionBuilder.bitstream(fragment.getBitStream()).streamSourceProtocol(fragment.getSourceProtocol()).channel(fragment.getChannel())
        .device(fragment.getDevice()).end(fragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8)));
    sessionBuilder.mediaServerId(instance.getInstanceId()).start(fragment.getStart().toEpochSecond(ZoneOffset.ofHours(8)));
    sessionBuilder.receiveIp(instance.getStreamIp()).app(StreamSessionApp.record).streamType(fragment.getType()).streamSourceProtocol(StreamSourceProtocol.GB28181);
    String streamId = fragment.getDevice() + "_" + fragment.getChannel() + "_" + fragment.getStart()
        .toEpochSecond(ZoneOffset.ofHours(8)) + "_" + fragment.getEnd().toEpochSecond(ZoneOffset.ofHours(8));
    sessionBuilder.streamId(streamId);
    Integer port = mediaServerManager.openRTPServer(instance, streamId, 0, method);
    Assert.notNull(port, "收流端口分配失败");
    sessionBuilder.receivePort(port);
    StreamSession streamSession = streamSessionManager.createSession(sessionBuilder.build());
    CommandBuilder builder = CommandBuilder.newBuilder("OpenHistory").appendParameter("device", streamSession.getDevice()).appendParameter("channel", streamSession.getChannel())
        .appendParameter("bitStream", streamSession.getBitstream().toString());
    builder.appendParameter("start", fragment.getStart().format(dateTimeFormatter)).appendParameter("end", fragment.getEnd().format(dateTimeFormatter)).appendParameter("playType", playType.name())
        .appendParameter("multiple", multiple.toString());
    builder.appendParameter("dataType", streamSession.getStreamType().toString()).appendParameter("ip", streamSession.getReceiveIp()).appendParameter("udp", "00");
    builder.appendParameter("tcp", streamSession.getReceivePort().toString());
    Command command = builder.build();
    IProtocolResponse<byte[],Byte> protocolResponse = ProtocolResponseUtils.buildCommandResponse(streamSession.getDevice(), command.getKey(), command.getParameters());
    ChannelHandlerContext context = protocolConnectionManager.select(fragment.getDevice());
    if (context != null) {
      context.writeAndFlush(protocolResponse);
    } else {
      forwardService.response(protocolResponse);
    }
    return streamSession;
  }

  @Override
  public void controlHistoryStream(StreamSession session, HistoryStreamControl control, Integer multiple, Long point) {
    Assert.isTrue(deviceManager.isOnline(session.getDevice()), "当前设备可能存在信号不佳或已熄火的情况，请稍后重试。");
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
    CommandBuilder builder = CommandBuilder.newBuilder("ControlHistoryStream").appendParameter("device", session.getDevice()).appendParameter("channel", session.getChannel());
    switch (control) {
      //正常播放
      case Play:
        builder.appendParameter("1", "0").appendParameter("2", "0").appendParameter("3", "000000000000");
        break;
      //暂停
      case Suspend:
        builder.appendParameter("1", "1").appendParameter("2", "0").appendParameter("3", "000000000000");
        break;
      //结束播放
      case Close:
        streamSessionManager.removeSession(session.getStreamId());
        builder.appendParameter("1", "2").appendParameter("2", "0").appendParameter("3", "000000000000");
        break;
      //快进
      case FastForward:
        builder.appendParameter("1", "3").appendParameter("2", multiple.toString()).appendParameter("3", "000000000000");
        break;
      //关键帧快退播放
      case KeyframeRewindPlayback:
        builder.appendParameter("1", "4").appendParameter("2", multiple.toString()).appendParameter("3", "000000000000");
        break;
      //拖动
      case Drag:
        LocalDateTime time = LocalDateTime.ofEpochSecond(session.getStart() + point, 0, ZoneOffset.ofHours(8));
        builder.appendParameter("1", "5").appendParameter("2", "0").appendParameter("3", time.format(dateTimeFormatter));
        break;
      //单帧播放
      case SingleFramePlay:
        builder.appendParameter("1", "6").appendParameter("2", "0").appendParameter("3", "000000000000");
        break;
    }
    Command command = builder.build();
    IProtocolResponse<byte[],Byte> protocolResponse = ProtocolResponseUtils.buildCommandResponse(session.getDevice(), command.getKey(), command.getParameters());
    ChannelHandlerContext context = protocolConnectionManager.select(session.getDevice());
    if (context != null) {
      context.writeAndFlush(protocolResponse);
    } else {
      forwardService.response(protocolResponse);
    }
  }

  @Override
  public void createTalkStream(String device, String channel) {
    CommandBuilder builder = CommandBuilder.newBuilder("Open").appendParameter("device", device).appendParameter("channel", channel).appendParameter("bitStream", "0");
    builder.appendParameter("dataType", StreamType.TwoWayIntercom.toString()).appendParameter("ip", jtt1078TranslationProperties.getAudioHost()).appendParameter("udp", "00");
    builder.appendParameter("tcp", jtt1078TranslationProperties.getAudioPort().toString());
    Command command = builder.build();
    IProtocolResponse<byte[],Byte> protocolResponse = ProtocolResponseUtils.buildCommandResponse(device, command.getKey(), command.getParameters());
    ChannelHandlerContext context = protocolConnectionManager.select(device);
    if (context != null) {
      context.writeAndFlush(protocolResponse);
    } else {
      forwardService.response(protocolResponse);
    }
  }


  @Override
  public void syncDeviceChannel() {

  }

  @Override
  public void controlPTZStream(StreamSession session, PTZStreamControl control, Integer horizonSpeed, Integer zoomSpeed, Integer verticalSpeed) {
    throw new IllegalArgumentException("1078 无此功能");
  }


}
