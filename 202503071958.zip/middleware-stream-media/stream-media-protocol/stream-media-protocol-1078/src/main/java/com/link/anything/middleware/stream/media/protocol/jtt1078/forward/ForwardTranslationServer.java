package com.link.anything.middleware.stream.media.protocol.jtt1078.forward;


import com.link.anything.middleware.stream.media.protocol.jtt1078.configuration.JTT1078TranslationProperties;
import com.link.anything.middleware.stream.media.protocol.jtt1078.forward.ProtocolForwardByteDecoder;
import com.link.anything.middleware.stream.media.protocol.jtt1078.forward.ProtocolForwardByteEncoder;
import com.link.anything.middleware.stream.media.protocol.jtt1078.forward.ProtocolForwardHandlerAdapter;
import com.link.anything.middleware.stream.media.protocol.jtt1078.handler.ProtocolByteDecoder;
import com.link.anything.middleware.stream.media.protocol.jtt1078.handler.ProtocolByteEncoder;
import com.link.anything.middleware.stream.media.protocol.jtt1078.handler.ProtocolHandlerAdapter;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class ForwardTranslationServer {

  private final LoggingHandler loggingHandler;
  private final JTT1078TranslationProperties translationConfig;
  NioEventLoopGroup boss = new NioEventLoopGroup();
  NioEventLoopGroup worker = new NioEventLoopGroup();
  private ProtocolForwardHandlerAdapter protocolForwardHandlerAdapter;

  public ForwardTranslationServer(JTT1078TranslationProperties translationConfig, ProtocolForwardHandlerAdapter protocolHandlerAdapter) {
    this.protocolForwardHandlerAdapter = protocolHandlerAdapter;
    this.loggingHandler = new LoggingHandler(LogLevel.DEBUG);
    this.translationConfig = translationConfig;
  }

  public void start() {
    try {
      // 服务器
      ServerBootstrap serverBootstrap = new ServerBootstrap();
      // 通道
      serverBootstrap.channel(NioServerSocketChannel.class);
      // 工作组
      serverBootstrap.group(boss, worker);

      serverBootstrap.childHandler(new ChannelInitializer<SocketChannel>() {

        @Override
        protected void initChannel(SocketChannel socketChannel) throws Exception {
          ChannelPipeline pipeline = socketChannel.pipeline();
          pipeline.addLast(loggingHandler);
          // 添加心跳响应 10秒响应一次心跳
          pipeline.addLast(new IdleStateHandler(10, 0, 0, TimeUnit.SECONDS));
          // 报文定长解析器
          pipeline.addLast(new ProtocolForwardByteDecoder());
          // 解析报文转换为数据实体
          pipeline.addLast(new ProtocolForwardByteEncoder());
          // 数据处理
          pipeline.addLast(protocolForwardHandlerAdapter);
        }
      });

      ChannelFuture channelFuture = serverBootstrap.bind(translationConfig.getForwardPort()).sync();
      log.info("JTT808车载转发接收服务启动成功 port:{}", translationConfig.getForwardPort());
      // 优雅的关闭服务器
      Channel channel = channelFuture.channel();
      channel.closeFuture().addListener((ChannelFutureListener) channelFuture1 -> {
        log.info("---------------关闭JTT808车载转发接收服务---------------");
        boss.shutdownGracefully();
        worker.shutdownGracefully();
      });
    } catch (Exception e) {
      log.error("---------------JTT808车载转发接收服务启动失败---------------", e);
    }
  }

  public void shutdown() {
    boss.shutdownGracefully();
    worker.shutdownGracefully();
  }
}
