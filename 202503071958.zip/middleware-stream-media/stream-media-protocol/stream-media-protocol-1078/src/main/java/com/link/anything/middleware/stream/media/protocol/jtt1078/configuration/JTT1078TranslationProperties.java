package com.link.anything.middleware.stream.media.protocol.jtt1078.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "middleware.stream.jtt1078", ignoreInvalidFields = true)
public class JTT1078TranslationProperties {

  /**
   * 主要端口
   */
  private Integer port;
  /**
   * http转发代理端口
   */
  private Integer audioPort;
  /**
   * 音频服务器地址
   */
  private String audioHost;
  /**
   * 转发端口
   */
  private Integer forwardPort;

}
