package com.link.anything.middleware.stream.media.protocol.jtt1078.snapshot;

import com.link.anything.common.constant.AlarmVariable;
import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.control.IDeviceAlarmManager;
import com.link.anything.middleware.stream.media.control.domain.Alarm;
import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.IProtocolResponse;
import com.link.anything.middleware.stream.media.protocol.jtt1078.utils.ProtocolResponseUtils;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;

import java.util.List;
import java.util.Objects;
import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * 抓拍管理器
 */
@Slf4j
@Component
public class SnapshotManager {


  @Resource
  private RedissonClient redisson;

  @Resource
  private IDeviceAlarmManager deviceAlarmManager;

  @Resource
  private SubscribeManager subscribeManager;

  /**
   * 提交抓拍任务
   *
   * @param alarms 报警数据
   */
  public void submitTask(List<Alarm> alarms, ChannelHandlerContext context) {
    //这里只会处理ADAS 的报警
    if (CollectionUtils.isEmpty(alarms)) {
      return;
    }
    RMap<String, Integer> alarmStateCache = redisson.getMap("middleware:stream:alarm:state");

    for (Alarm item : alarms) {
      String key = item.getNumber() + "_" + item.getVariable() + "_" + item.getMessage();
      boolean isOK = Objects.equals(item.getVariable(), AlarmVariable.ADAS);
      isOK = isOK && !Objects.equals(alarmStateCache.getOrDefault(key, 0), item.getState());
      if (isOK) {
        alarmStateCache.put(key, item.getState());
      } else {
        //continue;
      }
      Long id = deviceAlarmManager.submitAlarm(item);
      if (Objects.equals(item.getState(), 1)) {
        RAtomicLong snapshotNumber = redisson.getAtomicLong("middleware:stream:alarm:snapshot:sn:" + item.getNumber());
        long sn = snapshotNumber.getAndIncrement();
        if (sn > 32760) {
          sn = 0L;
          snapshotNumber.set(0L);
        }
        //开启异常
        IProtocolResponse<byte[], Byte> builder = ProtocolResponseUtils.buildSnapshotResponse(item.getNumber(), Long.toString(sn), (byte) 2, (short) 1, (short) 1);
        context.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        //订阅截图事件 3 秒钟超时
        subscribeManager.subscribe(
            StreamDefinitionEventKey.DeviceAlarmSnapshotFinish + "_" + item.getNumber() + "_" + sn,
            3,
            o -> {
              log.info("拍照结果{}", o);
            },
            o -> {
              log.warn("{}--下发拍照指令设备响应超时->{}", item, ByteBufUtil.hexDump(builder.build()));
              //开始上报
            }
        );
      } else {
        //关闭异常
        //开始上报
      }
    }
  }


}
