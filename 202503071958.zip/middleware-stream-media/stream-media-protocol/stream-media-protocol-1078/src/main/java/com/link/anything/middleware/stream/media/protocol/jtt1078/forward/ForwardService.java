package com.link.anything.middleware.stream.media.protocol.jtt1078.forward;

import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.IProtocolResponse;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.stereotype.Component;

/**
 * 转发服务
 */
@Component
public class ForwardService {

  private static ChannelHandlerContext context;

  public ChannelHandlerContext getChannelHandlerContext() {
    return context;
  }

  public void setChannelHandlerContext(ChannelHandlerContext context) {
    ForwardService.context = context;
  }

  /**
   * 回应数据
   */
  public void response(IProtocolResponse<byte[], Byte> response) {
    if (ForwardService.context != null) {
      ForwardService.context.writeAndFlush(response).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
    }
  }
}
