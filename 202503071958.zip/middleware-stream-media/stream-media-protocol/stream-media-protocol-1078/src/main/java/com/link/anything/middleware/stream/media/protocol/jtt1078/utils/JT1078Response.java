package com.link.anything.middleware.stream.media.protocol.jtt1078.utils;

import com.link.anything.common.utils.ByteUtils;
import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.IProtocolResponse;
import java.util.ArrayList;
import java.util.List;

import lombok.Data;

/**
 * jt808协议响应内容存储体
 *
 * @author YcYa_xbj
 */
@Data
public class JT1078Response implements IProtocolResponse<byte[],Byte> {

  //标志位
  private String mark = "7E";
  List<Byte> contentData = new ArrayList<>();
  //消息id 这个是固定的
  private String messageid;
  //设备ID
  private String deviceNumber;
  //消息流水号
  private String messageNumber;

  @Override
  public byte[] build() {
    List<Byte> dataList = new ArrayList<>();
    //消息 ID 消息体属性(长度)  终端手机号 消息流水号
    //标志位
    dataList.add((byte) 0x7E);
    //消息ID
    dataList.addAll(ByteUtils.hexStringToByteList(this.messageid));
    //消息属性
    int length = contentData.size();
    String temp = Integer.toBinaryString(length);
    String preString="";
    for (int i = 0; i < 16 - temp.length(); i++) {
      preString+="0";
    }
    StringBuilder buffer = new StringBuilder(preString+temp);
    dataList.add((byte) Integer.parseInt(buffer.substring(0, 8), 2) );
    dataList.add((byte) Integer.parseInt(buffer.substring(8, 16), 2));
    //设备ID
    dataList.addAll(ByteUtils.hexStringToByteList(this.deviceNumber));
    //消息流水
    dataList.addAll(ByteUtils.hexStringToByteList(this.messageNumber));
    //消息数据体
    dataList.addAll(contentData);
    //校验码
    byte check = dataList.get(1);
    for (int i = 2; i < dataList.size(); i++) {
      check = (byte) (check ^ dataList.get(i));
    }
    dataList.add(check);
    //标志位
    dataList.add((byte) 0x7E);
    byte[] data = new byte[dataList.size()];
    for (int i = 0; i < dataList.size(); i++) {
      data[i] = dataList.get(i);
    }

    return ProtocolUtils.escape(data);
  }

  @Override
  public void append(Byte item) {
    this.contentData.add(item);
  }
  @Override
  public void append(List<Byte> items) {
    this.contentData.addAll(items);
  }

  @Override
  public void append(byte[] items) {
    for (int i = 0; i < items.length; i++) {
      this.contentData.add(items[i]);
    }
  }
}
