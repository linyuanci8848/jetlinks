package com.link.anything.middleware.stream.media.protocol.jtt1078.talk;


import com.link.anything.common.constant.Command;
import com.link.anything.middleware.stream.media.common.CommandBuilder;
import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.protocol.TalkStreamContainer;
import com.link.anything.middleware.stream.media.protocol.entity.AudioInfo;
import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.DataType;
import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.IProtocolResponse;
import com.link.anything.middleware.stream.media.protocol.jtt1078.forward.ForwardService;
import com.link.anything.middleware.stream.media.protocol.jtt1078.handler.ProtocolConnectionManager;
import com.link.anything.middleware.stream.media.protocol.jtt1078.utils.ProtocolResponseUtils;
import com.link.anything.middleware.stream.media.protocol.codec.AudioCodec;
import com.link.anything.middleware.stream.media.protocol.entity.Media;
import com.link.anything.middleware.stream.media.protocol.entity.MediaEncoding;
import com.link.anything.middleware.stream.media.protocol.jtt1078.talk.entity.AudioPacket;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.util.AttributeKey;
import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@ChannelHandler.Sharable
@Slf4j
@Component
public class TalkStreamHandler extends SimpleChannelInboundHandler<AudioPacket> {


  private final TalkStreamContainer talkStreamContainer;
  private final SubscribeManager subscribeManager;
  private final ProtocolConnectionManager protocolConnectionManager;
  private final ForwardService forwardService;

  @Value("${middleware.stream.jtt1078.talk.welcome-audio-file:}")
  private String welcomeAudioFile;

  private static final AttributeKey<String> TAGKEY = AttributeKey.valueOf("tag-key");
  private static final AttributeKey<Boolean> HAISIKEY = AttributeKey.valueOf("haisi-key");
  private static final AttributeKey<AudioCodec> AUDIOCODECKEY = AttributeKey.valueOf("audio-codec-key");
  private static final AttributeKey<Integer> LOADTYPEKEY = AttributeKey.valueOf("load-type-key");

  public TalkStreamHandler(TalkStreamContainer talkStreamContainer, SubscribeManager subscribeManager, ProtocolConnectionManager protocolConnectionManager, ForwardService forwardService) {
    this.talkStreamContainer = talkStreamContainer;
    this.subscribeManager = subscribeManager;
    this.protocolConnectionManager = protocolConnectionManager;
    this.forwardService = forwardService;
  }

  @Override
  protected void channelRead0(ChannelHandlerContext ctx, AudioPacket visualAudio) {
    //不是音频不处理
    if (!DataType.AUDIO.getType().equals(visualAudio.getDataType())) {
      return;
    }
    String sim = visualAudio.getSimNo();
    int channel = visualAudio.getChannelNo();
    String tag = sim + "_" + channel;
    Integer sequence = visualAudio.getSequence();
    int pt = visualAudio.getLoadType();
    byte[] data = visualAudio.getData();
    AudioCodec audioCodec = AudioCodec.getCodec(pt);
    if (!ctx.channel().hasAttr(TAGKEY)) {
      log.info("audio codec: {}", MediaEncoding.getEncoding(Media.Type.Audio, pt));
      log.debug("audio data length: {}", data.length);
      ctx.channel().attr(TAGKEY).set(tag);
      if (data[0] == 0x00 && data[1] == 0x01 && (data[2] & 0xff) == (data.length - 4) / 2 && data[3] == 0x00) {
        //海思头
        ctx.channel().attr(HAISIKEY).set(true);
        log.info("海斯头");
      }
      welcomeIfNeeded(ctx, sim, channel);
      ctx.channel().attr(AUDIOCODECKEY).set(audioCodec);
      talkStreamContainer.join(sim, channel + "", ctx);
      ctx.channel().attr(LOADTYPEKEY).set(pt);
    }
    if (ctx.channel().hasAttr(HAISIKEY) && ctx.channel().attr(HAISIKEY).get()) {
      data = Arrays.copyOfRange(data, 4, data.length);
    }
    talkStreamContainer.upRedirect(sim, channel + "", audioCodec.toPCM(data));
  }

  private void welcomeIfNeeded(ChannelHandlerContext ctx, String sim, int channel) {
    if (welcomeAudioFile != null && !welcomeAudioFile.isEmpty()) {
      new Thread(() -> {
        try {
          File file = new File(welcomeAudioFile);
          if (!file.exists()) {
            log.debug("no welcome audio file found");
            return;
          }

          byte[] g711a;
          if (file.getName().endsWith(".pcm")) {
            g711a = AudioCodec.getCodec(6).fromPCM(Files.readAllBytes(file.toPath()));
          } else {
            g711a = Files.readAllBytes(file.toPath());
          }

          int squeue = 0;

          for (int i = 0; i < g711a.length / 320; ++i) {
            byte[] output = new byte[320 + 4];
            System.arraycopy(g711a, 4 + i * 320, output, 4, 320);
            output[0] = 0x00;
            output[1] = 0x01;
            output[2] = (byte)(160);
            output[3] = 0x00;
            AudioInfo audioInfo = AudioInfo.builder().simNo(sim).channelNo(channel).data(output).sequence(squeue).timeStamp(squeue * 40L).build();

            ctx.writeAndFlush(audioInfo);
            squeue++;
            Thread.sleep(40L);
          }
          log.debug("welcome audio file send complete");
        } catch (Exception e) {
          e.printStackTrace();
        }
      }).start();
    }
  }

  @Override
  public void channelInactive(ChannelHandlerContext ctx) throws Exception {
    super.channelInactive(ctx);
    release(ctx.channel());
  }

  @Override
  public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
    // super.exceptionCaught(ctx, cause);
    cause.printStackTrace();
    release(ctx.channel());
    ctx.close();
  }

  @Override
  public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
    if (IdleStateEvent.class.isAssignableFrom(evt.getClass())) {
      IdleStateEvent event = (IdleStateEvent) evt;
      if (event.state() == IdleState.READER_IDLE) {
        String tag = ctx.channel().attr(TAGKEY).get();
        log.info("read timeout: {}", tag);
        release(ctx.channel());
      }
    }
  }

  private void release(io.netty.channel.Channel channel) {
    String tag = channel.attr(TAGKEY).get();
    if (tag != null) {
      String[] tags = tag.split("_");
      this.talkStreamContainer.kick(tags[0], tags[1]);
      //发送关闭对讲指令避免重新连接
      CommandBuilder builder = CommandBuilder.newBuilder("ControlLiveStream").appendParameter("device", tags[0]).appendParameter("channel", tags[1]);
      builder.appendParameter("1", "4").appendParameter("2", "0").appendParameter("3", "0");
      Command command = builder.build();
      IProtocolResponse protocolResponse = ProtocolResponseUtils.buildCommandResponse(tags[0], command.getKey(), command.getParameters());
      ChannelHandlerContext context = protocolConnectionManager.select(tags[0]);
      if (context != null) {
        context.writeAndFlush(protocolResponse);
      } else {
        forwardService.response(protocolResponse);
      }
      log.info("close netty channel: {}", tag);
    }
  }
}
