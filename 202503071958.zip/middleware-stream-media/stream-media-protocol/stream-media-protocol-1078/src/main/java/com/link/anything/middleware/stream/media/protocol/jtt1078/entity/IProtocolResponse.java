package com.link.anything.middleware.stream.media.protocol.jtt1078.entity;

import java.util.List;

/**
 * @author YcYa_xbj
 */
public interface IProtocolResponse<T,S> {

  /**
   * 构建相应内容
   *
   * @return
   */
  T build();

  /**
   * 追加数据
   */
  void append(S item);

   void append(List<S> items);
  void append(byte[] items);
}
