package com.link.anything.middleware.stream.media.protocol.jtt1078.forward;

import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.IProtocolResponse;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author YcYa_xbj
 */

public class ProtocolForwardByteEncoder extends MessageToByteEncoder<IProtocolResponse<byte[],Byte>> {
  private final static Logger logger = LoggerFactory.getLogger(ProtocolForwardByteEncoder.class);
  @Override
  protected void encode(ChannelHandlerContext ctx, IProtocolResponse<byte[],Byte> builder, ByteBuf out) {
    byte[] data = builder.build();
    logger.debug("{} DOWN           {}", ctx.channel().remoteAddress().toString(), ByteBufUtil.hexDump(data));
    out.writeBytes(data);
  }
}
