package com.link.anything.middleware.stream.media.protocol.jtt1078.handler;

import com.link.anything.common.utils.ByteUtils;

import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.IProtocolResponse;
import com.link.anything.middleware.stream.media.protocol.jtt1078.snapshot.SnapshotManager;
import com.link.anything.middleware.stream.media.protocol.jtt1078.utils.ModelUtils;
import com.link.anything.middleware.stream.media.protocol.jtt1078.utils.ProtocolResponseUtils;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.util.AttributeKey;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author YcYa_xbj
 */
@Component()
@Slf4j
@ChannelHandler.Sharable
public class ProtocolHandlerAdapter extends ChannelInboundHandlerAdapter {

  private final AttributeKey<Object> deviceNumberKey = AttributeKey.valueOf("deviceNumber");
  @Resource
  private ProtocolConnectionManager connectionManager;
  @Resource
  private SubscribeManager subscribeManager;

  @Resource
  private IDeviceManager deviceManager;
  @Resource
  private SnapshotManager snapshotManager;
  /**
   * 设备多媒体分包数据缓存
   */
  private static final Map<String, File> cacheMediaByte = new ConcurrentHashMap<>();

  @Override
  public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
    if (evt instanceof IdleStateEvent) {
      final IdleStateEvent event = (IdleStateEvent) evt;
      if (IdleState.READER_IDLE.equals(event.state())) {
        ctx.close();
      }
    } else {
      super.userEventTriggered(ctx, evt);
    }
  }

  @Override
  public void channelRead(final ChannelHandlerContext ctx, final Object model) throws IOException {
    byte[] data = (byte[]) model;
    //去除标识符 和 校验符
    data = Arrays.copyOfRange(data, 1, data.length - 2);

    //消息ID
    String messageId = ByteBufUtil.hexDump(data, 0, 2);
    //消息体属性
    int bodyAttributes = Integer.parseInt(ByteBufUtil.hexDump(data, 2, 2), 16);
    //终端手机号
    String deviceNumber = ByteBufUtil.hexDump(data, 4, 6);
    //消息流水
    String messageNumber = ByteBufUtil.hexDump(data, 10, 2);
    //消息体属性有一个值决定是否有消息包装项目 这里要进行判断
    //反序数组
    //此三位都为 0，表示消息体不加密；
    if (ByteUtils.getUIntBit(bodyAttributes, 12) == 0 && ByteUtils.getUIntBit(bodyAttributes, 11) == 0 && ByteUtils.getUIntBit(bodyAttributes, 10) == 0) {
      //TODO 暂时不处理
    }
    //第 10 位为 1，表示消息体经过 RSA 算法加密；
    if (ByteUtils.getUIntBit(bodyAttributes, 10) == 1) {
      //TODO 暂时不处理
    }
    int contentIndex = 12;
    int packTotal = 0;
    int packIndex = 0;
    //消息进行了分包
    if (ByteUtils.getUIntBit(bodyAttributes, 13) == 1) {
      packTotal = Integer.parseInt(ByteBufUtil.hexDump(data, 12, 2), 16);
      packIndex = Integer.parseInt(ByteBufUtil.hexDump(data, 14, 2), 16);
      contentIndex = 16;
    }
    //去除消息体属性
    data = Arrays.copyOfRange(data, contentIndex, data.length);
    switch (messageId) {
      //注册包
      case "0100":
        //这里直接返回就可以了
        IProtocolResponse builder = ProtocolResponseUtils.buildRegisteredResponse(deviceNumber, messageNumber, "00", "ok");
        ctx.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        break;
      //鉴权包
      case "0102":
        //这里设备的判断在其他地方判断
        log.debug(deviceNumber + "连接成功");
        ctx.channel().attr(deviceNumberKey).set(deviceNumber);
        builder = ProtocolResponseUtils.buildGeneralResponse(deviceNumber, messageNumber, messageId, "00");
        ctx.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        connectionManager.join(deviceNumber, ctx);
        Device device = new Device();
        device.setProtocol(StreamSourceProtocol.JTT1078);
        device.setSipTransactionInfo(null);
        device.setTerminalNumber(deviceNumber);
        deviceManager.online(device);
        break;
      //注销包
      case "0003":
        deviceManager.offline(deviceNumber);
        String result = "00";
        builder = ProtocolResponseUtils.buildGeneralResponse(deviceNumber, messageNumber, messageId, result);
        ctx.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        break;
      //心跳包
      case "0002":
        builder = ProtocolResponseUtils.buildGeneralResponse(deviceNumber, messageNumber, messageId, "00");
        ctx.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        break;
      //位置汇报
      case "0200":
        snapshotManager.submitTask(ModelUtils.buildAlarm(deviceNumber, data), ctx);
        builder = ProtocolResponseUtils.buildGeneralResponse(deviceNumber, messageNumber, messageId, "00");
        ctx.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        break;
      //批量位置汇报
      case "0704":
        int nums = Integer.parseInt(ByteBufUtil.hexDump(Arrays.copyOfRange(data, 0, 2)), 16);
        //移除头部 属性
        data = Arrays.copyOfRange(data, 3, data.length);
        int itemLength = 0;
        int start = 0;
        for (int i = 0; i < nums; i++) {
          itemLength = Integer.parseInt(ByteBufUtil.hexDump(Arrays.copyOfRange(data, start, start + 2)), 16);
          byte[] cache = Arrays.copyOfRange(data, start + 2, start + itemLength + 2);
          snapshotManager.submitTask(ModelUtils.buildAlarm(deviceNumber, cache), ctx);
          start = start + itemLength + 2;
        }
        builder = ProtocolResponseUtils.buildGeneralResponse(deviceNumber, messageNumber, messageId, "00");
        ctx.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        break;
      //历史音视频回传
      case "1205":
        //copyData
        //查询流水
        long queryNumber = Long.parseLong(ByteBufUtil.hexDump(data, 0, 2), 16);
        List<VideoFragment> videoFragments = ModelUtils.handleVideoFragment(deviceNumber, data);
        //数据回调
        subscribeManager.publish(StreamDefinitionEventKey.HistoryVideoFindCallback + deviceNumber + "_" + queryNumber, videoFragments);
        builder = ProtocolResponseUtils.buildGeneralResponse(deviceNumber, messageNumber, messageId, "00");
        ctx.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        break;
      //截图或者录制视频信息回传
      case "0805":
        //查询流水
        queryNumber = Long.parseLong(ByteBufUtil.hexDump(data, 0, 2), 16);
        byte snapshotResult = Byte.valueOf(ByteBufUtil.hexDump(data, 2, 1), 16);
        Short fileTotal = Short.valueOf(ByteBufUtil.hexDump(data, 3, 1), 16);
        Map<String, Object> dataMap = new HashMap<>();
        switch (snapshotResult) {
          case 0:
            //成功
            dataMap.put("state", 0);
            dataMap.put("data", ByteBufUtil.hexDump(data, 4, fileTotal * 4));
            break;
          case 1:
            //失败
            dataMap.put("state", 1);
            break;
          case 2:
            //通道不支持
            dataMap.put("state", 2);
            break;
        }
        //数据回调
        subscribeManager.publish(StreamDefinitionEventKey.DeviceAlarmSnapshotFinish + "_" + deviceNumber + "_" + queryNumber, dataMap);
        builder = ProtocolResponseUtils.buildGeneralResponse(deviceNumber, messageNumber, messageId, "00");
        ctx.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        break;
      case "0801":
        if (packTotal > 0) {
          if (packIndex == 1) {
            //媒体标识
            Integer mediaIndex = Integer.parseInt(ByteBufUtil.hexDump(data, 0, 4), 16);
            //媒体类型
            byte mediaType = Byte.parseByte(ByteBufUtil.hexDump(data, 4, 1), 16);
            //媒体格式
            byte mediaExt = Byte.parseByte(ByteBufUtil.hexDump(data, 5, 1), 16);
            String mediaExtString = "";
            //0：JPEG；1：TIF；2：MP3；3：WAV；4：WMV；
            //其他保留
            switch (mediaExt) {
              case 0:
                mediaExtString = ".jpg";
                break;
              case 1:
                mediaExtString = ".tif";
                break;
              case 2:
                mediaExtString = ".mp3";
                break;
              case 3:
                mediaExtString = ".wav";
                break;
              case 4:
                mediaExtString = ".wmv";
                break;
            }
            //CMD
            byte mediaCmd = Byte.parseByte(ByteBufUtil.hexDump(data, 6, 1), 16);
            //通道
            byte mediaChannel = Byte.parseByte(ByteBufUtil.hexDump(data, 7, 1), 16);
            //位置信息
            byte[] mediaLocation = Arrays.copyOfRange(data, 8, 28);
            //媒体信息
            byte[] media = Arrays.copyOfRange(data, 36, data.length - 1);
            File mediaFile = new File(File.separator + "Users" + File.separator + "lan" + File.separator + deviceNumber + "_" + mediaChannel + "_" + mediaIndex + mediaExtString);
            if (!mediaFile.exists()) {
              mediaFile.createNewFile();
            }
            Files.write(mediaFile.toPath(), media, StandardOpenOption.APPEND);
            cacheMediaByte.remove(deviceNumber);
            cacheMediaByte.put(deviceNumber, mediaFile);
          } else {
            File mediaFile = cacheMediaByte.get(deviceNumber);
            Files.write(mediaFile.toPath(), data, StandardOpenOption.APPEND);
          }
        }
        //数据回调
        builder = ProtocolResponseUtils.buildGeneralResponse(deviceNumber, messageNumber, messageId, "00");
        ctx.writeAndFlush(builder).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
        break;
    }

  }

  @Override
  public void channelActive(ChannelHandlerContext ctx) throws Exception {
    super.channelActive(ctx);
    if (log.isDebugEnabled()) {
      log.debug("连接{}建立", ctx.channel().toString());
    }
  }

  @Override
  public void channelInactive(ChannelHandlerContext ctx) {
    if (ctx.channel().hasAttr(deviceNumberKey)) {
      //剔除连接
      connectionManager.kick(ctx.channel().attr(deviceNumberKey).get().toString(), ctx.channel().id());
      if (log.isDebugEnabled()) {
        log.debug("连接主动{}断开", ctx.channel().toString());
      }
      deviceManager.offline(ctx.channel().attr(deviceNumberKey).get().toString());
    } else {
      if (log.isDebugEnabled()) {
        log.debug("新旧连接替换{}断开", ctx.channel().toString());
      }
    }
  }

  @Override
  public void exceptionCaught(final ChannelHandlerContext ctx, final Throwable cause) {
    //关了就关了 不处理
    if (log.isDebugEnabled()) {
      log.error(cause.getLocalizedMessage(), cause);
    }
  }
}
