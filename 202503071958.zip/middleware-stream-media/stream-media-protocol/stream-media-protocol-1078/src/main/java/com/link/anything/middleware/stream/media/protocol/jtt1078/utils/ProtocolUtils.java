package com.link.anything.middleware.stream.media.protocol.jtt1078.utils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author YcYa_xbj
 */
@Slf4j
public class ProtocolUtils {

  /**
   * 协议要求进行转义
   *
   * @param src
   * @return
   */
  public static byte[] escape(byte[] src) {
    byte[] bs = new byte[src.length * 2];
    int len = 1;
    bs[0] = 0x7E;
    for (int i = 1; i < src.length - 1; i++) {
      if (src[i] == 0x7d) {
        bs[len] = 0x7d;
        bs[len + 1] = 0x01;
        len = len + 2;
      } else if (src[i] == 0x7e) {
        bs[len] = 0x7d;
        bs[len + 1] = 0x02;
        len = len + 2;
      } else {
        bs[len] = src[i];
        len = len + 1;
      }
    }
    bs[len] = 0x7E;
    byte[] target = new byte[len + 1];
    System.arraycopy(bs, 0, target, 0, target.length);
    return target;
  }

  public static byte[] unescape(byte[] src) {
    byte[] bs = new byte[src.length];
    int len = 1;
    bs[0] = 0x7E;
    for (int i = 1; i < src.length - 1; i++) {
      //0x7d
      if (src[i] == 0x7d && src[i + 1] == 0x01) {
        bs[len] = 0x7d;
        i = 1 + i;
      } else if (src[i] == 0x7d && src[i + 1] == 0x02) {
        //0x7e
        bs[len] = 0x7e;
        i = 1 + i;
      } else {
        bs[len] = src[i];
      }
      len = len + 1;
    }
    bs[len] = 0x7E;
    byte[] target = new byte[len + 1];
    System.arraycopy(bs, 0, target, 0, target.length);
    return target;
  }
}
