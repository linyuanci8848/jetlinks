package com.link.anything.middleware.stream.media.protocol.jtt1078.forward;

import com.link.anything.common.utils.ByteUtils;
import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.Device;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import com.link.anything.middleware.stream.media.protocol.jtt1078.utils.ModelUtils;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author YcYa_xbj
 */
@Component()
@Slf4j
@ChannelHandler.Sharable
public class ProtocolForwardHandlerAdapter extends ChannelInboundHandlerAdapter {


  @Resource
  private SubscribeManager subscribeManager;

  @Resource
  private IDeviceManager deviceManager;

  @Resource
  private ForwardService forwardService;

  private static Set<String> devices = new CopyOnWriteArraySet<>();

  @Override
  public void channelRead(final ChannelHandlerContext ctx, final Object model) {
    // DoubleLock，管理转发服务通道上下文。
    // 逻辑走到这里之后，当前通道肯定是转发的JTT808消息。
    // TODO：可能需要增加机制来判断这个转发JTT808消息的连接是不是我方需要的连接
    if (forwardService.getChannelHandlerContext() == null) {
      synchronized (this) {
        if (forwardService.getChannelHandlerContext() == null) {
          forwardService.setChannelHandlerContext(ctx);
        }
      }
    }

    // 以下为业务逻辑
    byte[] data = (byte[]) model;
    //去除标识符 和 校验符
    data = Arrays.copyOfRange(data, 1, data.length - 2);

    //消息ID
    String messageId = ByteBufUtil.hexDump(data, 0, 2);
    //消息体属性
    int bodyAttributes = Integer.parseInt(ByteBufUtil.hexDump(data, 2, 2), 16);
    //终端手机号
    String deviceNumber = ByteBufUtil.hexDump(data, 4, 6);
    //消息体属性有一个值决定是否有消息包装项目 这里要进行判断
    //反序数组
    //此三位都为 0，表示消息体不加密；
    if (ByteUtils.getUIntBit(bodyAttributes, 12) == 0 && ByteUtils.getUIntBit(bodyAttributes, 11) == 0 && ByteUtils.getUIntBit(bodyAttributes, 10) == 0) {
      //TODO 暂时不处理
    }
    //第 10 位为 1，表示消息体经过 RSA 算法加密；
    if (ByteUtils.getUIntBit(bodyAttributes, 10) == 1) {
      //TODO 暂时不处理
    }
    int contentIndex = 12;
    //消息进行了分包
    if (ByteUtils.getUIntBit(bodyAttributes, 13) == 1) {
      //TODO 分包没处理
      contentIndex = 16;
    }
    //去除消息体属性
    data = Arrays.copyOfRange(data, contentIndex, data.length);
    switch (messageId) {
      //注册包
      case "0100":
        //这里直接返回就可以了
        break;
      //鉴权包
      case "0102":
        //这里设备的判断在其他地方判断
        break;
      //注销包
      case "0003":
        //这里标识设备断开代表连接断开（808里面仅代表设备注销）
        deviceManager.offline(deviceNumber);
        devices.remove(deviceNumber);
        log.info("{}-注销设备离线", deviceNumber);
        break;
      //心跳包
      case "0002":
        //这里代表转发客户端和服务端的心跳
        //刷新设备连接状态
        break;
      //位置汇报
      case "0200":
        long status = Long.parseLong(ByteBufUtil.hexDump(data, 4, 4), 16);
        int acc = ByteUtils.getULongBit(status, 0);
        //ACC 打开算上线 才可以看视频
        if (acc == 1) {
          Device device = new Device();
          device.setProtocol(StreamSourceProtocol.JTT1078);
          device.setSipTransactionInfo(null);
          device.setTerminalNumber(deviceNumber);
          deviceManager.online(device);
          devices.add(deviceNumber);
          log.info("{}-ACC开启设备上线", deviceNumber);
        } else {
          //ACC 关闭不管连接是否存活直接下线
          deviceManager.offline(deviceNumber);
          devices.remove(deviceNumber);
          log.info("{}-ACC关闭设备下线", deviceNumber);
        }
        break;
      //批量位置汇报
      case "0704":
        int nums = Integer.parseInt(ByteBufUtil.hexDump(Arrays.copyOfRange(data, 0, 2)), 16);
        //移除头部 属性
        data = Arrays.copyOfRange(data, 3, data.length);
        int itemLength = 0;
        int start = 0;
        for (int i = 0; i < nums; i++) {
          itemLength = Integer.parseInt(ByteBufUtil.hexDump(Arrays.copyOfRange(data, start, start + 2)), 16);
          byte[] cache = Arrays.copyOfRange(data, start + 2, start + itemLength + 2);
          long _status = Long.parseLong(ByteBufUtil.hexDump(cache, 4, 4), 16);
          int _acc = ByteUtils.getULongBit(_status, 0);
          //ACC 打开算上线 才可以看视频
          if (_acc == 1) {
            Device device = new Device();
            device.setProtocol(StreamSourceProtocol.JTT1078);
            device.setSipTransactionInfo(null);
            device.setTerminalNumber(deviceNumber);
            deviceManager.online(device);
            devices.add(deviceNumber);
            log.info("{}-ACC开启设备上线", deviceNumber);
          } else {
            //ACC 关闭不管连接是否存活直接下线
            deviceManager.offline(deviceNumber);
            devices.remove(deviceNumber);
            log.info("{}-ACC关闭设备下线", deviceNumber);
          }
          start = start + itemLength + 2;
        }
        break;
      //历史音视频回传
      case "1205":
        //查询流水
        long queryNumber = Long.parseLong(ByteBufUtil.hexDump(data, 0, 2), 16);
        List<VideoFragment> videoFragments = ModelUtils.handleVideoFragment(deviceNumber, data);
        //数据回调
        subscribeManager.publish(StreamDefinitionEventKey.HistoryVideoFindCallback + deviceNumber + "_" + queryNumber, videoFragments);
        break;
    }

  }


  @Override
  public void channelActive(ChannelHandlerContext ctx) throws Exception {
    super.channelActive(ctx);
    log.info("有应用连接了JTT808转发JTT1078的端口，连接信息为：{}", ctx.channel().toString());
  }

  @Override
  public void channelInactive(ChannelHandlerContext ctx) {
    // 如果不是当前使用的连接，则不进行断连操作。
    // 不做这个判断的话，如果转发端口被其它应用建立了连接，当这些应用关闭连接时，断连操作会错误的断掉正在使用的合法连接。
    if (!ctx.equals(forwardService.getChannelHandlerContext())) {
      return;
    }
    log.info("当前使用的JTT808转发JTT1078连接已断开，连接信息为：{}", ctx.channel().toString());
    //所有设备离线
    for (String device : devices) {
      deviceManager.offline(device);
      devices.remove(device);
      log.info("由于转发连接断开，强制设备下线，设备信息为：{}", device);
    }
    forwardService.setChannelHandlerContext(null);
  }

  @Override
  public void exceptionCaught(final ChannelHandlerContext ctx, final Throwable cause) {
    //关了就关了 不处理
    log.error(cause.getLocalizedMessage(), cause);
  }
}
