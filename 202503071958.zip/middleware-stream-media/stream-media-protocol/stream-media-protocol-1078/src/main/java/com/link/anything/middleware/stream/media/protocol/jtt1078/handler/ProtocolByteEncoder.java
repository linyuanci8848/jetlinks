package com.link.anything.middleware.stream.media.protocol.jtt1078.handler;

import com.link.anything.middleware.stream.media.protocol.jtt1078.entity.IProtocolResponse;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author YcYa_xbj
 */

public class ProtocolByteEncoder extends MessageToByteEncoder<IProtocolResponse<byte[],Byte>> {
  private final static Logger logger = LoggerFactory.getLogger(ProtocolByteEncoder.class);
  @Override
  protected void encode(ChannelHandlerContext ctx, IProtocolResponse<byte[],Byte> builder, ByteBuf out) {
    byte[] data = builder.build();
    logger.debug("{} DOWN           {}", ctx.channel().remoteAddress().toString(), ByteBufUtil.hexDump(data));
    out.writeBytes(data);
  }
}
