package com.link.anything.middleware.stream.media.protocol.jtt1078.handler;


import com.link.anything.middleware.stream.media.protocol.jtt1078.configuration.JTT1078TranslationProperties;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class TranslationServer {

  private final LoggingHandler loggingHandler;
  private final JTT1078TranslationProperties translationConfig;
  NioEventLoopGroup boss = new NioEventLoopGroup();
  NioEventLoopGroup worker = new NioEventLoopGroup();
  private ProtocolHandlerAdapter protocolHandlerAdapter;

  public TranslationServer(JTT1078TranslationProperties translationConfig, ProtocolHandlerAdapter protocolHandlerAdapter) {
    this.protocolHandlerAdapter = protocolHandlerAdapter;
    this.loggingHandler = new LoggingHandler(LogLevel.DEBUG);
    this.translationConfig = translationConfig;
  }

  public void start() {
    try {
      // 服务器
      ServerBootstrap serverBootstrap = new ServerBootstrap();
      // 通道
      serverBootstrap.channel(NioServerSocketChannel.class);
      // 工作组
      serverBootstrap.group(boss, worker);

      serverBootstrap.childHandler(new ChannelInitializer<SocketChannel>() {

        @Override
        protected void initChannel(SocketChannel socketChannel) throws Exception {
          ChannelPipeline pipeline = socketChannel.pipeline();

          pipeline.addLast(loggingHandler);
          // 添加心跳响应 10秒响应一次心跳
          pipeline.addLast(new IdleStateHandler(1000, 0, 0, TimeUnit.SECONDS));
          // 报文定长解析器
          pipeline.addLast(new ProtocolByteDecoder());
          // 解析报文转换为数据实体
          pipeline.addLast(new ProtocolByteEncoder());
          // 数据处理
          pipeline.addLast(protocolHandlerAdapter);

        }
      });

      ChannelFuture channelFuture = serverBootstrap.bind(translationConfig.getPort()).sync();
      log.info("JTT1078车载服务启动成功 port:{}", translationConfig.getPort());
      // 优雅的关闭服务器
      Channel channel = channelFuture.channel();
      channel.closeFuture().addListener(new ChannelFutureListener() {
        @Override
        public void operationComplete(ChannelFuture channelFuture) throws Exception {
          log.info("---------------关闭JTT1078车载服务---------------");
          boss.shutdownGracefully();
          worker.shutdownGracefully();
        }
      });


    } catch (Exception e) {
      log.error("---------------JTT1078车载服务启动失败---------------", e);
    }

  }

  public void shutdown() {
    boss.shutdownGracefully();
    worker.shutdownGracefully();
  }
}
