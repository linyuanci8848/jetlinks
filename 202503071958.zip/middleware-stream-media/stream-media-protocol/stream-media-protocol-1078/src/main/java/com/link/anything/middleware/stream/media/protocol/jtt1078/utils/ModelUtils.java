package com.link.anything.middleware.stream.media.protocol.jtt1078.utils;

import com.link.anything.common.constant.AlarmVariable;
import com.link.anything.common.utils.ByteUtils;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import com.link.anything.middleware.stream.media.control.domain.Alarm;
import com.link.anything.middleware.stream.media.control.domain.VideoFragment;
import io.netty.buffer.ByteBufUtil;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 协议解析
 */
@Slf4j
public class ModelUtils {

  /**
   * 解析历史音视频回传
   *
   * @param data
   * @return
   */
  public static List<VideoFragment> handleVideoFragment(String deviceNumber, byte[] data) {
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
    List<VideoFragment> videoFragments = new ArrayList<>();
    int total = Integer.parseInt(ByteBufUtil.hexDump(data, 2, 4), 16);
    data = Arrays.copyOfRange(data, 6, data.length);
    if (total > 0) {
      //27个字节一个包
      for (int i = 0; i < data.length; i += 28) {
        VideoFragment videoFragment = new VideoFragment();
        videoFragment.setDevice(deviceNumber);
        videoFragment.setSource(HistoryVideoSource.Device);
        //通道号
        int chanel = Integer.parseInt(ByteBufUtil.hexDump(data, i, 1), 16);
        videoFragment.setChannel(chanel + "");
        //开始时间
        String start = ByteBufUtil.hexDump(data, i + 1, 6);
        videoFragment.setStart(LocalDateTime.parse(start, dateTimeFormatter));
        //结束时间
        String end = ByteBufUtil.hexDump(data, i + 7, 6);
        videoFragment.setEnd(LocalDateTime.parse(end, dateTimeFormatter));
        //报警位
        Long alarm = Long.parseLong(ByteBufUtil.hexDump(data, i + 13, 8), 16);
        videoFragment.setAlarmMark(alarm.toString());
        //流类型
        int streamType = Integer.parseInt(ByteBufUtil.hexDump(data, i + 21, 1), 16);
        switch (streamType) {
          case 0:
            videoFragment.setType(StreamType.VideoAndAudio);
            break;
          case 1:
            videoFragment.setType(StreamType.Audio);
            break;
          case 2:
            videoFragment.setType(StreamType.Video);
            break;
        }
        //end
        //码流类型
        int bitType = Integer.parseInt(ByteBufUtil.hexDump(data, i + 22, 1), 16);
        videoFragment.setBitStream(bitType);
        //存储器类型
        int diskType = Integer.parseInt(ByteBufUtil.hexDump(data, i + 23, 1), 16);
        //文件大小byte
        int size = Integer.parseInt(ByteBufUtil.hexDump(data, i + 24, 4), 16);
        videoFragment.setSize(size);
        videoFragment.setSourceProtocol(StreamSourceProtocol.JTT1078);
        videoFragments.add(videoFragment);
      }
    }
    return videoFragments;
  }

  /**
   * 构建报警数据
   *
   * @param deviceNumber
   * @param data
   * @return
   */
  public static List<Alarm> buildAlarm(String deviceNumber, byte[] data) {
    List<Alarm> alarmSources = new ArrayList<>();
    long status = Long.parseLong(ByteBufUtil.hexDump(data, 4, 4), 16);
    long alarm = Long.parseLong(ByteBufUtil.hexDump(data, 0, 4), 16);
    int location = ByteUtils.getULongBit(status, 1);
    LocalDateTime reportTime = null;
    try {
      reportTime = LocalDateTime.parse(ByteBufUtil.hexDump(data, 22, 6), DateTimeFormatter.ofPattern("yyMMddHHmmss"));
    } catch (Exception e) {
      return Collections.emptyList();
    }
    Alarm.AlarmBuilder alarmSourceBuilder = Alarm.builder();
    alarmSourceBuilder.number(deviceNumber).date(reportTime);
    alarmSourceBuilder.state(ByteUtils.getULongBit(alarm, 0)).variable(AlarmVariable.SOS).message("SOS警报");
    alarmSources.add(alarmSourceBuilder.build());
//        alarmSourceBuilder = AlarmSource.builder();
//        alarmSourceBuilder.number(deviceNumber).date(reportTime.toEpochSecond(ZoneOffset.ofHours(8)));
//        alarmSourceBuilder.state(ByteUtils.getULongBit(alarm, 2)).variable(AlarmVariable.DrivingTimeout).message("疲劳驾驶");
//        alarmSources.add(alarmSourceBuilder.build());

//    alarmSourceBuilder = Alarm.builder();
//    alarmSourceBuilder.number(deviceNumber).date(reportTime);
//    alarmSourceBuilder.state(ByteUtils.getULongBit(alarm, 8)).variable(AlarmVariable.PowerDown).message("终端掉电");
//    alarmSources.add(alarmSourceBuilder.build());
//
//    alarmSourceBuilder.number(deviceNumber).date(reportTime);
//    alarmSourceBuilder.state(ByteUtils.getULongBit(alarm, 29)).variable(AlarmVariable.ADAS).message("碰撞预警");
//    alarmSources.add(alarmSourceBuilder.build());
//
//    alarmSourceBuilder.number(deviceNumber).date(reportTime);
//    alarmSourceBuilder.state(ByteUtils.getULongBit(alarm, 30)).variable(AlarmVariable.ADAS).message("侧翻预警");
//    alarmSources.add(alarmSourceBuilder.build());
//
//    alarmSourceBuilder.number(deviceNumber).date(reportTime);
//    alarmSourceBuilder.state(ByteUtils.getULongBit(alarm, 26)).variable(AlarmVariable.ADAS).message("车辆被盗");
//    alarmSources.add(alarmSourceBuilder.build());
//
//    alarmSourceBuilder.number(deviceNumber).date(reportTime);
//    alarmSourceBuilder.state(ByteUtils.getULongBit(alarm, 25)).variable(AlarmVariable.ADAS).message("油量异常");
//    alarmSources.add(alarmSourceBuilder.build());
//
//    alarmSourceBuilder.number(deviceNumber).date(reportTime);
//    alarmSourceBuilder.state(ByteUtils.getULongBit(alarm, 24)).variable(AlarmVariable.ADAS).message("VSS 故障");
//    alarmSources.add(alarmSourceBuilder.build());
//
//    alarmSourceBuilder.number(deviceNumber).date(reportTime);
//    alarmSourceBuilder.state(ByteUtils.getULongBit(alarm, 23)).variable(AlarmVariable.ADAS).message("路线偏离");
//    alarmSources.add(alarmSourceBuilder.build());
    if (data.length > 28) {
      //未读附加数据长度
      int unreadExtLength = data.length - 28;
      int extStartIndex = 28;
      while (unreadExtLength > 0) {
        byte extMessageId = data[extStartIndex];
        int extMessageLength = Integer.parseInt(ByteBufUtil.hexDump(new byte[]{data[extStartIndex + 1]}), 16);
        //第28位为附加消息ID位置
        switch (extMessageId) {
          //0x01 4 里程，DWORD，1/10km，对应车上里程表读数  系统内部存的是米
          case 0x01:
            break;
          case 0x02:
            break;
          case 0x14:
            //视频相关报警,Dword,按位设置,标志位定义见表 14
            break;
          case 0x15:
            //视频信号丢失报警
            break;
          case 0x16:
            //视频信号遮挡报警
            break;
          case 0x17:
            //存储器故障报警
            break;
          case 0x18:
            //异常驾驶行为报警 ADAS 警报
            //行为
            int behavior = Integer.parseInt(ByteBufUtil.hexDump(data, extStartIndex + 2, 2), 16);
            //疲劳
            alarmSourceBuilder = Alarm.builder();
            alarmSourceBuilder.number(deviceNumber).date(reportTime);
            alarmSourceBuilder.state(ByteUtils.getUIntBit(behavior, 0)).variable(AlarmVariable.ADAS).message("疲劳驾驶");
            if (ByteUtils.getUIntBit(behavior, 0) == 1) {
              //疲劳值
              int fatigueValue = Integer.parseInt(ByteBufUtil.hexDump(data, extStartIndex + 4, 1), 16);
              alarmSourceBuilder.message("疲劳驾驶，当前疲劳值：" + fatigueValue);
            }
            alarmSources.add(alarmSourceBuilder.build());
            //打电话
            alarmSourceBuilder = Alarm.builder();
            alarmSourceBuilder.number(deviceNumber).date(reportTime);
            alarmSourceBuilder.state(ByteUtils.getUIntBit(behavior, 1)).variable(AlarmVariable.ADAS).message("接打电话");
            alarmSources.add(alarmSourceBuilder.build());
            //抽烟
            alarmSourceBuilder = Alarm.builder();
            alarmSourceBuilder.number(deviceNumber).date(reportTime);
            alarmSourceBuilder.state(ByteUtils.getUIntBit(behavior, 2)).variable(AlarmVariable.ADAS).message("抽烟");
            alarmSources.add(alarmSourceBuilder.build());
            break;
          case (byte) 0x65:   // 苏标DSM，暂用和上方0x18一样的处理逻辑，优先保证数据能对上。后续重构。
            if (log.isDebugEnabled()) {
              log.debug("发现苏标DSM数据");
            }
            long alarmId = Long.parseLong(ByteBufUtil.hexDump(data, extStartIndex + 2, 4), 16);
            int alarmStatus = Integer.parseInt(ByteBufUtil.hexDump(data, extStartIndex + 6, 1), 16);
            alarmStatus = alarmStatus == 0 ? 1 : alarmStatus;

            int alarmType = Integer.parseInt(ByteBufUtil.hexDump(data, extStartIndex + 7, 1), 16);
            alarmSourceBuilder = Alarm.builder();
            alarmSourceBuilder.id(alarmId)
                    .date(reportTime)
                    .number(deviceNumber)
                    .variable(AlarmVariable.ADAS)
                    .state(alarmStatus);
            switch (alarmType) {
              case (byte) 0x01:
                int fatigueValue = Integer.parseInt(ByteBufUtil.hexDump(data, extStartIndex + 9, 1), 16);
                alarmSourceBuilder.message("疲劳驾驶，当前疲劳值：" + fatigueValue);
                break;
              case (byte) 0x02:
                alarmSourceBuilder.message("接打电话");
                break;
              case (byte) 0x03:
                alarmSourceBuilder.message("抽烟");
                break;
              case (byte) 0x04:
                alarmSourceBuilder.message("分神驾驶");
                break;
              case (byte) 0x05:
                alarmSourceBuilder.message("驾驶员异常");
                break;
              case (byte) 0x10:
                alarmSourceBuilder.message("自动抓拍");
                break;
              case (byte) 0x11:
                alarmSourceBuilder.message("驾驶员变更");
                break;
              default:
                alarmSourceBuilder.message("未知事件");
                break;
            }
            Alarm alarmSource = alarmSourceBuilder.build();
            if (log.isDebugEnabled()) {
              log.debug("苏标DSM数据：" + alarmSource.getMessage());
            }
            alarmSources.add(alarmSource);
            break;
          //扩展WIFI定位获取的MAC地址及信号强度
          case (byte) 0xF0:

            break;
          //扩展的附加消息ID，内容包含电池电量，版本信息，ICCID值
          case (byte) 0xFE:
            break;
          //0xEB BSJ 扩展数据格式，兼容 2929 扩展终议，详见 BSJ 扩展附加 D 表 自定终
          case (byte) 0xEB:
            break;
        }
        extStartIndex = extStartIndex + extMessageLength + 2;
        unreadExtLength = unreadExtLength - 2 - extMessageLength;
      }
    }
    return alarmSources;
  }
}
