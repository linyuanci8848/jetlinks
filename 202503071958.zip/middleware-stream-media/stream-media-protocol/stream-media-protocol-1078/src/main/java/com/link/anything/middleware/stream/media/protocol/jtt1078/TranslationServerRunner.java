package com.link.anything.middleware.stream.media.protocol.jtt1078;



import com.link.anything.middleware.stream.media.protocol.jtt1078.forward.ForwardTranslationServer;
import com.link.anything.middleware.stream.media.protocol.jtt1078.handler.TranslationServer;
import com.link.anything.middleware.stream.media.protocol.jtt1078.talk.TranslationTalkServer;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.SmartLifecycle;
import org.springframework.stereotype.Component;

@Component
public class TranslationServerRunner implements SmartLifecycle {

  private TranslationTalkServer translationTalkServer = null;


  @Resource
  private TranslationServer translationServer;

  @Resource
  private ForwardTranslationServer forwardTranslationServer;

  private volatile boolean isRun = false;

  @Autowired(required = false)
  public void setTranslationTalkServer(TranslationTalkServer translationTalkServer) {
    this.translationTalkServer = translationTalkServer;
  }

  @Override
  public void start() {
    if (translationTalkServer != null) {
      translationTalkServer.start();
    }
    translationServer.start();
    forwardTranslationServer.start();
    isRun = true;
  }

  @Override
  public void stop() {
    translationTalkServer.shutdown();
    translationServer.shutdown();
    forwardTranslationServer.shutdown();
    isRun = false;
  }

  @Override
  public boolean isRunning() {
    return isRun;
  }


}
