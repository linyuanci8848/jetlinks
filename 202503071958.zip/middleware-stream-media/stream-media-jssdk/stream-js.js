class StreamDefinition {
    /**
 * 请求和响应方法的枚举
 */
    HandlerMethod = {
        /**
       * 心跳
       */
        Heart: "Heart",
        /**
         * 打开直播流
         */
        OpenLiveStream: "OpenLiveStream",
        /**
         * 控制直播流
         */
        ControlLiveStream: "ControlLiveStream",
        /**
         * 查询录像文件
         */
        FindHistoryVideo: "FindHistoryVideo",
        /**
         * 打开录像流
         */
        OpenHistoryStream: "OpenHistoryStream",

        /**
         * 控制录像流
         */
        ControlHistoryStream: "ControlHistoryStream",
        /**
         * 打开对讲流
         */
        OpenTalkStream: "OpenTalkStream",
        /**
         * 控制对讲流
         */
        ControlTalkStream: "ControlTalkStream",
        /**
         * 设备状态
         */
        DeviceState: "DeviceState",
        /**
         * 云台控制
         */
        PTZControl: "PTZControl"
    }
    /**
     * 设备协议
     */
    StreamSourceProtocol = {
        GB28181: "GB28181",
        JTT1078: "JTT1078"
    }
    /**
     * 历史视频控制协议
     */
    HistoryStreamControl = {
        /**
         * 正常播放
         */
        Play: "Play",

        /**
         * 暂停
         */
        Suspend: "Suspend",
        /**
         * 结束播放
         */
        Close: "Close",

        /**
         * 快进
         */
        FastForward: "FastForward",

        /**
         * 关键帧快退播放
         */
        KeyframeRewindPlayback: "KeyframeRewindPlayback",
        /**
         * 拖动
         */
        Drag: "Drag",
        /**
         * 单帧播放
         */
        SingleFramePlay: "SingleFramePlay"
    }
    /**
     * 直播视频控制指令
     */
    LiveStreamControl = {
        /**
           * 关闭视频流
           */
        CLoseVideo: "CLoseVideo",
        /**
         * 关闭音频流
         */
        CloseAudio: "CloseAudio",
        /**
         * 关闭音频和视频
         */
        CloseAudioAndVideo: "CloseAudioAndVideo",
        /**
         * 切换码流
         */
        ChangeBitStream: "ChangeBitStream",
        /**
         * 暂停流发送
         */
        PauseStream: "PauseStream",
        /**
         * 继续流发送
         */
        ContinueStream: "ContinueStream",
        /**
         * 关闭双向对讲
         */
        CloseWalkingTalkie: "CloseWalkingTalkie"
    }
    /**
     * 云台控制
     */
    PTZStreamControl = {
        /**
         * 左移
         */
        Left: "Left",
        /**
         * 右移
         */
        Right: "Right",
        /**
         * 上移
         */
        Up: "Up",
        /**
         * 下移
         */
        Down: "Down",
        /**
         * 上左移动
         */
        UpLeft: "UpLeft",
        /**
         * 上右移动
         */
        UpRight: "UpRight",
        /**
         * 下左移动
         */
        DownLeft: "DownLeft",
        /**
         * 下右移动
         */
        DownRight: "DownRight",
        /**
         * 缩小画面
         */
        ZooMin: "ZooMin",
        /**
         * 放大画面
         */
        ZoomOut: "ZoomOut",
        /**
         * 停止移动
         */
        Stop: "Stop"
    }
    /**
     * 流类型
     */
    StreamType = {
        //视频流
        Video: "Video",
        //音频流
        Audio: "Audio",
        //音频和视频
        VideoAndAudio: "VideoAndAudio",
        //双向对讲
        TwoWayIntercom: "TwoWayIntercom",
        //监听
        Monitor: "Monitor",
        //中心广播
        CentralBroadcasting: "CentralBroadcasting",
        //数据透传
        Transparent: "Transparent"
    }
    /**
     * 历史视频播放类型
     */
    HistoryStreamPlayType = {
        /**
           * 正常播放
           */
        Normal: "Normal",
        /**
         * 快进
         */
        FastForward: "FastForward",
        /**
         * 关键帧快退播放
         */
        KeyFramesFastBack: "KeyFramesFastBack",
        /**
         * 关键帧播放
         */
        KeyFrames: "KeyFrames",

        /**
         * 单帧播放
         */
        SingleFrame: "SingleFrame"

    }
    /**
     * 流获取方式
     */
    StreamTransferMethod = {
        /**
          * TCP被动
          */
        TCP_PASSIVE: "TCP_PASSIVE",
        /**
         * TCP主动
         */
        TCP_ACTIVE: "TCP_ACTIVE",
        /**
         * UDP被动
         */
        UDP_PASSIVE: "UDP_PASSIVE",
        /**
         * UDP主动
         */
        UDP_ACTIVE: "UDP_ACTIVE"
    }
}
window.streamDefinition = new StreamDefinition();



class SocketRequest {
    constructor(method, data) {
        this.method = method;
        this.data = data;
        this.callback = new Date().getTime();
    }
}

class SocketResponse {
    method;
    data;
    ok;
    message;
    callback;
}



 class StreamJs {

    constructor() {
        this.successCallbacks = {}
        this.errorCallbacks = {}
    }
    /**
     * 连接服务器
     * @param {SIP服务器地址} url 
     * @param {设备状态变化回调} callback 
     */
    connect(url, callback) {
        this.url = url;

        this.successCallbacks[streamDefinition.HandlerMethod.DeviceState] = callback
        this.websocket = new WebSocket(url);
        this.websocket.onopen = function () {
            console.log("SIP服务连接成功")
            window.streamJs.heartbeatInterval = setInterval(function () {
                if (window.streamJs.websocket.readyState !== 1) {
                    return
                }
                var socketRequest = new SocketRequest(streamDefinition.HandlerMethod.Heart, {});
                window.streamJs.websocket.send(JSON.stringify(socketRequest))
            }, 10000)
        }
        this.websocket.onerror = function (e) {
            console.error(e)
        }
        this.websocket.onmessage = function (event) {
            var socketResponse = JSON.parse(event.data);
            if (socketResponse.method === streamDefinition.HandlerMethod.Heart) {
                //心跳不处理
                return;
            }
            if (socketResponse.ok) {
                streamJs.successCallbacks[socketResponse.callback](socketResponse.data)
            } else {
                streamJs.errorCallbacks[socketResponse.callback](socketResponse.message)
            }
        }
        this.websocket.onclose = function () {
            console.log("SIP服务关闭成功")
            if (this.heartbeatInterval) {
                window.clearInterval(this.heartbeatInterval)
            }
        }
    }


    /**
     * 打开直播流
     * @param {设备编号} device  
     * @param {设备通道} channel  
     * @param {码流} streamResolutionRatio 
     * @param {设备协议} sourceProtocol 
     * @param {取流方式} streamTransferMethod 
     * @param {取流成功回调} successCallback 
     * @param {取流失败回调} errorCallback 
     */
    openLiveStream(device, channel, streamResolutionRatio, sourceProtocol, streamTransferMethod, successCallback, errorCallback) {
        var data = { device: device, channel: channel, streamResolutionRatio: streamResolutionRatio, sourceProtocol: sourceProtocol, streamTransferMethod: streamTransferMethod };
        var socketRequest = new SocketRequest(streamDefinition.HandlerMethod.OpenLiveStream, data);
        this.websocket.send(JSON.stringify(socketRequest));
        this.successCallbacks[socketRequest.callback] = successCallback;
        this.errorCallbacks[socketRequest.callback] = errorCallback;
    }
    /**
     * 控制直播流
     * @param {流标识} stream 
     * @param {控制指令}control 
     * @param {码流,切换码流才有效果} bitStream 
     * @param {控制成功回调} successCallback 
     * @param {控制失败回调} errorCallback 
     */
    controlLiveStream(stream, control, bitStream, successCallback, errorCallback) {
        var data = { stream: stream, control: control, bitStream: bitStream };
        var socketRequest = new SocketRequest(streamDefinition.HandlerMethod.ControlLiveStream, data);
        this.websocket.send(JSON.stringify(socketRequest));
        this.successCallbacks[socketRequest.callback] = successCallback;
        this.errorCallbacks[socketRequest.callback] = errorCallback;
    }
    /**
     * 查询设备历史视频
     * @param {设备编号} device 
     * @param {通道编号} channel 
     * @param {开始时间 yyyy-MM-dd HH:mm:ss} start 
     * @param {结束时间 yyyy-MM-dd HH:mm:ss} end 
     * @param {流类型} type 
     * @param {设备协议} protocol 
     * @param {查询成功回调} successCallback 
     * @param {查询失败回调} errorCallback 
     */
    findHistoryVideo(device, channel, start, end, type, protocol, successCallback, errorCallback) {
        var data = { device: device, channel: channel, start: start, end: end, type: type, protocol: protocol };
        var socketRequest = new SocketRequest(streamDefinition.HandlerMethod.FindHistoryVideo, data);
        this.websocket.send(JSON.stringify(socketRequest));
        this.successCallbacks[socketRequest.callback] = successCallback;
        this.errorCallbacks[socketRequest.callback] = errorCallback;
    }
    /**
     * 打开点播流
     * @param {录像标识，Key} stream 
     * @param {播放类型} playType 
     * @param {播放倍数} multiple 
     * @param {取流方式} method 
     * @param {成功回调} successCallback 
     * @param {失败回调} errorCallback 
     */
    openHistoryStream(stream, playType, multiple, method, successCallback, errorCallback) {
        var data = { stream: stream, playType: playType, multiple: multiple, method: method };
        var socketRequest = new SocketRequest(streamDefinition.HandlerMethod.OpenHistoryStream, data);
        this.websocket.send(JSON.stringify(socketRequest));
        this.successCallbacks[socketRequest.callback] = successCallback;
        this.errorCallbacks[socketRequest.callback] = errorCallback;
    }
    /**
     * 控制点播流
     * @param {流ID} stream 
     * @param {控制指令} control 
     * @param {倍数} multiple 
     * @param {拖动秒数} point 
     * @param {控制成功回调} successCallback 
     * @param {控制失败回调} errorCallback 
     */
    controlHistoryStream(stream, control, multiple, point, successCallback, errorCallback) {
        var data = { stream: stream, control: control, multiple: multiple, point: point };
        var socketRequest = new SocketRequest(streamDefinition.HandlerMethod.ControlHistoryStream, data);
        this.websocket.send(JSON.stringify(socketRequest));
        this.successCallbacks[socketRequest.callback] = successCallback;
        this.errorCallbacks[socketRequest.callback] = errorCallback;
    }
    /**
     * 打开对讲流
     * <p>连接断开就代表关闭对讲</p>
     * @param {设备编号} device 
     * @param {设备通道} channel 
     * @param {设备协议} sourceProtocol 
     * @param {取流方式} streamTransferMethod 
     * @param {成功回调} successCallback 
     * @param {失败回调} errorCallback 
     */
    openTalkStream(device, channel, sourceProtocol, streamTransferMethod, successCallback, errorCallback) {
        var data = { device: device, channel: channel, sourceProtocol: sourceProtocol, streamTransferMethod: streamTransferMethod };
        var socketRequest = new SocketRequest(streamDefinition.HandlerMethod.OpenTalkStream, data);
        this.websocket.send(JSON.stringify(socketRequest));
        this.successCallbacks[socketRequest.callback] = successCallback;
        this.errorCallbacks[socketRequest.callback] = errorCallback;
    }
    /**
     * 
     * @param {流标识} stream 
     * @param {控制指令 PTZStreamControl } control 
     * @param {水平速度} horizonSpeed 
     * @param {缩放速度} zoomSpeed 
     * @param {垂直速度} verticalSpeed 
     * @param {成功回调} successCallback 
     * @param {失败回调} errorCallback 
     */
    controlPTZStream(stream, control, horizonSpeed, zoomSpeed, verticalSpeed, successCallback, errorCallback) {
        var data = { stream: stream, control: control, horizonSpeed: horizonSpeed, zoomSpeed: zoomSpeed, verticalSpeed: verticalSpeed };
        var socketRequest = new SocketRequest(streamDefinition.HandlerMethod.PTZControl, data);
        this.websocket.send(JSON.stringify(socketRequest));
        this.successCallbacks[socketRequest.callback] = successCallback;
        this.errorCallbacks[socketRequest.callback] = errorCallback;
    }
}
window.streamJs = new StreamJs();