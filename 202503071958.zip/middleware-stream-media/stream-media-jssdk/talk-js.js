class TalkJs {
    constructor() {
        this.talkWs = null;
        this.recorderObject = null;
        this.playObject = null;
        //每个包的大小控制在320个字节
        this.SendFrameSize = 640;
    }
    /**
     * 连接对讲服务
     * @param {对讲服务Websocket连接URL} url 
     */
    connect(url) {
        var that = this;
        var transform = function (pcm, sampleRate, True, False) {
            //pcm需指定sampleRate，为传输过来pcm的采样率
            True(new Int16Array(pcm), sampleRate);
        };
        this.playObject = Recorder.BufferStreamPlayer({
            decode: false,
            onInputError: function (errMsg, inputIndex) {
                console.log("第" + inputIndex + "次的音频片段input输入出错: " + errMsg, 1);
            },
            onUpdateTime: function () {

            },
            onPlayEnd: function () {
                if (!that.playObject.isStop) {
                    console.log('没有可播放的数据了，缓冲中 或者 已播放完成');
                }
            },
            transform: function (pcm, sampleRate, True, False) {
                transform(pcm, 8000, function (pcm, sampleRate) {
                    True(pcm, sampleRate);
                }, False);
            }
        });

        this.talkWs = new WebSocket(url);
        this.talkWs.binaryType = 'arraybuffer';
        this.talkWs.onopen = function () {
            console.log("对讲服务连接成功")
        }
        this.talkWs.onerror = function (e) {
            console.error(e)
        }
        this.talkWs.onmessage = function (event) {
            that.playObject.input(event.data)
        }
        this.talkWs.onclose = function () {
            console.log("对讲服务关闭成功")
            //关闭录音
            that.close();
        }
    }

    playDeviceAudio() {
        this.playObject.start(function () {
            console.log("stream已打开[PCM]，正在播放中");
        }, function (err) {
            console.log("开始失败：" + err, 1);
        });
    }
    realTimeSendTryNumber;
    realTimeSendTryChunk;
    realTimeSendTryChunks;

    //=====实时处理核心函数==========
    realTimeSendTry(buffers, bufferSampleRate, isClose) {
        if (this.realTimeSendTryChunks == null) {
            this.realTimeSendTryNumber = 0;
            this.realTimeSendTryChunk = null;
            this.realTimeSendTryChunks = [];
        };
        //配置有效性检查
        if (this.SendFrameSize % 2 == 1) {
            console.log("16位pcm SendFrameSize 必须为2的整数倍", 1);
            return;
        };

        var pcm = [], pcmSampleRate = 0;
        if (buffers.length > 0) {
            //借用SampleData函数进行数据的连续处理，采样率转换是顺带的，得到新的pcm数据
            var chunk = Recorder.SampleData(buffers, bufferSampleRate, 8000, this.realTimeSendTryChunk);

            //清理已处理完的缓冲数据，释放内存以支持长时间录音，最后完成录音时不能调用stop，因为数据已经被清掉了
            for (var i = this.realTimeSendTryChunk ? this.realTimeSendTryChunk.index : 0; i < chunk.index; i++) {
                buffers[i] = null;
            };
            this.realTimeSendTryChunk = chunk;//此时的chunk.data就是原始的音频16位pcm数据（小端LE），直接保存即为16位pcm文件、加个wav头即为wav文件、丢给mp3编码器转一下码即为mp3文件

            pcm = chunk.data;
            pcmSampleRate = chunk.sampleRate;

            if (pcmSampleRate != 8000)//除非是onProcess给的bufferSampleRate低于testSampleRate
                throw new Error("不应该出现pcm采样率" + pcmSampleRate + "和需要的采样率8000不一致");
        };

        //将pcm数据丢进缓冲，凑够一帧发送，缓冲内的数据可能有多帧，循环切分发送
        if (pcm.length > 0) {
            this.realTimeSendTryChunks.push({ pcm: pcm, pcmSampleRate: pcmSampleRate });
        };

        //从缓冲中切出一帧数据
        var chunkSize = this.SendFrameSize / (16 / 8);//8位时需要的采样数和帧大小一致，16位时采样数为帧大小的一半
        var pcm = new Int16Array(chunkSize), pcmSampleRate = 0;
        var pcmOK = false, pcmLen = 0;
        for1: for (var i1 = 0; i1 < this.realTimeSendTryChunks.length; i1++) {
            var chunk = this.realTimeSendTryChunks[i1];
            pcmSampleRate = chunk.pcmSampleRate;
            for (var i2 = chunk.offset || 0; i2 < chunk.pcm.length; i2++) {
                pcm[pcmLen] = chunk.pcm[i2];
                pcmLen++;
                //满一帧了，清除已消费掉的缓冲
                if (pcmLen == chunkSize) {
                    pcmOK = true;
                    chunk.offset = i2 + 1;
                    for (var i3 = 0; i3 < i1; i3++) {
                        this.realTimeSendTryChunks.splice(0, 1);
                    };
                    break for1;
                }
            }
        };

        //缓冲的数据不够一帧时，不发送 或者 是结束了
        if (!pcmOK) {
            if (isClose) {
                //关闭就不发送了
                //this.transferUpload(number, null, 0, null);
            };
            return;
        };
        //console.log(pcm)
        //16位pcm格式可以不经过mock转码，直接发送new Blob([pcm.buffer],{type:"audio/pcm"}) 但8位的就必须转码，通用起见，均转码处理，pcm转码速度极快
    
        var encStartTime = Date.now();
        var recMock = Recorder({
            type: "pcm",
            sampleRate: 8000,//需要转换成的采样率
            bitRate: 16 //需要转换成的比特率
        });
        recMock.mock(pcm, pcmSampleRate);
        var that = this;
        recMock.stop(function (blob, duration) {
            blob.encTime = Date.now() - encStartTime;
            //转码好就推入传输
            var reader = new FileReader();
            reader.addEventListener("load", function (e) {
                if (that.talkWs && that.talkWs.readyState === 1) {
                     let array = Array.prototype.slice.call(new Int32Array(e.target.result ));
                     array.push(that.realTimeSendTryNumber)
                     array.push(that.realTimeSendTryNumber*40)
                     let arrayBuffer = new Int32Array(array).buffer;
                     that.talkWs.send(arrayBuffer)
                    //发送了序号才累加
                    ++that.realTimeSendTryNumber
                }
            }, false);
            reader.readAsArrayBuffer(blob);
            //循环调用，继续切分缓冲中的数据帧，直到不够一帧
            that.realTimeSendTry([], 0, isClose);
        }, function (msg) {
            //转码错误？没想到什么时候会产生错误！
            console.log("不应该出现的错误:" + msg, 1);
        });
    };
    /**
     * 开始录音
     */
    open() {
        var that = this;
        //防止重复打开
        if (this.recorderObject) {
            this.recorderObject.close();
        };
        this.recorderObject = Recorder({
            type:"mp3",sampleRate:16000,bitRate:16,
            onProcess: function (buffers, powerLevel, bufferDuration, bufferSampleRate) {
                //推入实时处理，因为是unknown格式，buffers和rec.buffers是完全相同的，只需清理buffers就能释放内存。
                that.realTimeSendTry(buffers, bufferSampleRate, false);
            }
        });
        this.recorderObject.open(function () {//打开麦克风授权获得相关资源
            //开始录音
            that.recorderObject.start();
            //重置环境，开始录音时必须调用一次
            that.realTimeSendTryChunks = null;
        }, function (msg, isUserNotAllow) {
            console.log((isUserNotAllow ? "UserNotAllow，" : "") + "无法录音:" + msg, 1);
        });
    };
    /**
     * 结束录音
     */
    close() {
        this.recorderObject.close();
        //直接close掉即可，这个例子不需要获得最终的音频文件
        //关闭直接关闭就好了
        //this.realTimeSendTry([], 0, true,0);//最后一次发送
    };
}

