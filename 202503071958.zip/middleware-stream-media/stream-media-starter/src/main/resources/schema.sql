create table if not exists device
(
    id                                  bigint unsigned auto_increment
        primary key,
    terminal_number                     varchar(50)          not null,
    name                                varchar(255)         null,
    manufacturer                        varchar(255)         null,
    model                               varchar(255)         null,
    firmware                            varchar(255)         null,
    transport                           varchar(50)          null,
    stream_mode                         varchar(50)          null,
    on_line                             tinyint(1) default 0 null,
    register_at                         datetime             null,
    keepalive_time                      varchar(50)          null,
    ip                                  varchar(50)          null,
    create_at                           datetime             null,
    update_at                           datetime             null,
    port                                int                  null,
    expires                             int                  null,
    subscribe_cycle_for_catalog         int        default 0 null,
    subscribe_cycle_for_mobile_position int        default 0 null,
    mobile_position_submission_interval int        default 5 null,
    subscribe_cycle_for_alarm           int        default 0 null,
    host_address                        varchar(50)          null,
    charset                             varchar(50)          null,
    ssrc_check                          tinyint(1) default 0 null,
    geo_coord_sys                       varchar(50)          null,
    media_server_id                     varchar(50)          null,
    custom_name                         varchar(255)         null,
    sdp_ip                              varchar(50)          null,
    local_ip                            varchar(50)          null,
    password                            varchar(255)         null,
    as_message_channel                  tinyint(1) default 0 null,
    keepalive_interval_time             int                  null,
    switch_primary_sub_stream           tinyint(1) default 0 null,
    broadcast_push_after_ack            tinyint(1) default 0 null,
    sip_transaction_info                json                 null,
    protocol                            varchar(20)          null,
    constraint id
        unique (id),
    constraint uk_device_device
        unique (terminal_number)
)
    row_format = DYNAMIC;

create table if not exists device_alarm
(
    id                bigint unsigned auto_increment
        primary key,
    device_id         varchar(50)  not null,
    channel_id        varchar(50)  not null,
    alarm_priority    varchar(50)  null,
    alarm_method      varchar(50)  null,
    alarm_time        varchar(50)  null,
    alarm_description varchar(255) null,
    longitude         double       null,
    latitude          double       null,
    alarm_type        varchar(50)  null,
    open_at           datetime     not null,
    close_at          datetime     null,
    create_at         datetime     null,
    constraint id
        unique (id)
)
    row_format = DYNAMIC;

create table if not exists device_channel
(
    id                      bigint unsigned auto_increment
        primary key,
    terminal_channel_number varchar(50)          not null,
    name                    varchar(255)         null,
    custom_name             varchar(255)         null,
    manufacture             varchar(50)          null,
    model                   varchar(50)          null,
    owner                   varchar(50)          null,
    civil_code              varchar(50)          null,
    block                   varchar(50)          null,
    address                 varchar(50)          null,
    parent_id               varchar(50)          null,
    safety_way              int                  null,
    register_way            int                  null,
    cert_num                varchar(50)          null,
    certifiable             int                  null,
    err_code                int                  null,
    end_time                varchar(50)          null,
    secrecy                 varchar(50)          null,
    ip_address              varchar(50)          null,
    port                    int                  null,
    password                varchar(255)         null,
    ptz_type                int                  null,
    status                  tinyint(1) default 0 null,
    longitude               double               null,
    custom_longitude        double               null,
    latitude                double               null,
    custom_latitude         double               null,
    stream_id               varchar(255)         null,
    terminal_number         varchar(50)          not null,
    parental                varchar(50)          null,
    has_audio               tinyint(1) default 0 null,
    create_at               datetime             not null,
    update_at               datetime             not null,
    sub_count               int                  null,
    longitude_gcj02         double               null,
    latitude_gcj02          double               null,
    longitude_wgs84         double               null,
    latitude_wgs84          double               null,
    business_group_id       varchar(50)          null,
    gps_time                datetime             null,
    constraint id
        unique (id),
    constraint uk_wvp_device_channel_unique_device_channel
        unique (terminal_number, terminal_channel_number)
)
    row_format = DYNAMIC;

create table if not exists media_server_instance
(
    id                  bigint(255) auto_increment
        primary key,
    stream_ip           varchar(50)          null,
    http_port           int                  null,
    http_ssl_port       int                  null,
    rtmp_port           int                  null,
    rtmp_ssl_port       int                  null,
    rtp_proxy_port      int                  null,
    rtsp_port           int                  null,
    rtsp_ssl_port       int                  null,
    secret              varchar(50)          null,
    rtp_enable          tinyint(1) default 0 null,
    rtp_port_range      varchar(50)          null,
    send_rtp_port_range varchar(50)          null,
    record_assist_port  int                  null,
    create_time         varchar(50)          null,
    update_time         varchar(50)          null,
    hook_alive_interval int                  null,
    control_server_id   varchar(20)          null,
    instance_id         varchar(255)         null,
    status              int                  null,
    control_ip          varchar(255)         null,
    constraint uk_media_server_unique_ip_http_port
        unique (stream_ip, http_port)
)
    collate = utf8_bin
    row_format = DYNAMIC;

create table if not exists stream_session
(
    id                     int auto_increment
        primary key,
    source_token           varchar(50)  null comment '流源Token',
    play_tokens            json         null comment '播放Token',
    stream_app             varchar(50)  null comment '流在媒体服务器的应用标识',
    media_server           varchar(50)  null comment '流媒体服务器标识',
    device                 varchar(50)  null comment '设备标识',
    channel                varchar(50)  null comment '通道标识',
    stream_source_protocol varchar(50)  null comment '流源协议',
    receive_ip             varchar(50)  null comment '流接收IP',
    receive_port           int          null comment '流接收端口',
    stream_transfer_method varchar(50)  null comment '流传输发方法',
    resolution             int          null comment '分辨率 即码流',
    stream_type            varchar(50)  null comment '流类型',
    start                  bigint       null comment '开始时间-点播流',
    end                    bigint       null comment '结束时间-点播流',
    stream_id              varchar(255) null comment '流标识',
    ssrc                   varchar(255) null comment 'GB28181 专用',
    stream_total           int          null comment '流总数 及当前注册了多少流',
    stream_proxy_key       varchar(255) null comment '流代理Key'
)
    row_format = DYNAMIC;

create table if not exists video_fragment
(
    id              bigint(100) auto_increment
        primary key,
    device          varchar(255) null,
    channel         varchar(255) null,
    start           datetime     null,
    end             datetime     null,
    alarm_mark      varchar(255) null,
    type            varchar(255) null,
    bit_stream      int          null,
    source          varchar(255) null,
    size            int          null,
    source_protocol varchar(255) null,
    `key`           varchar(100) null
)
    row_format = DYNAMIC;