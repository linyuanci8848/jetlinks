package com.link.anything.middleware.stream.media;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@ConditionalOnProperty(prefix = "dev", name = "api", havingValue = "true")
@Configuration(proxyBeanMethods = false)
public class OpenApiConfigure {

  @Value("${spring.application.version}")
  private String version;

  @Value("${spring.application.name}")
  private String name;

  @Bean
  public OpenAPI customOpenAPI() {
    Components components = new Components();
    return new OpenAPI().components(components).info(new Info().title(name + " API").version(version));
  }
}
