package com.link.anything.middleware.stream.media;

import com.google.common.collect.Lists;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.socket.config.annotation.EnableWebSocket;

@Slf4j
@EnableScheduling
@EnableAsync
@EnableWebSocket
@SpringBootApplication(scanBasePackages = "com.link.anything.middleware.stream.media")
@MapperScan(basePackages = "com.link.anything.middleware.stream.media.**.mapper")
public class StreamMediaApplication {

  public static void main(final String[] args) {
    SpringApplication springApplication = new SpringApplication(StreamMediaApplication.class);
    List<String> argsList = Lists.newArrayList(args);
    argsList.add("--server.servlet.encoding.charset=UTF-8");
    argsList.add("--spring.servlet.multipart.max-file-size=5MB");
    argsList.add("--spring.servlet.multipart.max-request-size=6MB");
    argsList.add("--server.http2.enabled=true");
    argsList.add("--server.shutdown=graceful");
    argsList.add("--logging.config=classpath:logback-spring.xml");
    argsList.add("--logging.charset.file=UTF-8");
    argsList.add("--mybatis-plus.configuration.log-impl=org.apache.ibatis.logging.slf4j.Slf4jImpl");
    springApplication.run(argsList.toArray(new String[0]));
    Runtime.getRuntime().addShutdownHook(new Thread(() -> System.out.println("关机啦")));
  }
}
