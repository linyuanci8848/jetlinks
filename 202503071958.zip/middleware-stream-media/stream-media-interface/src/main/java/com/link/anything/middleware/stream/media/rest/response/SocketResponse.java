package com.link.anything.middleware.stream.media.rest.response;

import com.link.anything.middleware.stream.media.rest.interaction.HandlerMethod;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SocketResponse {

  /**
   * 请求key
   */
  private HandlerMethod method;
  /**
   * 请求参数体
   */
  private Object data;
  /**
   * 是否成果
   */
  private boolean ok;
  /**
   * 系统消息
   */
  private String message;

  /**
   * 回调标识
   */
  private String callback;

}
