package com.link.anything.middleware.stream.media.rest.request;

import com.link.anything.middleware.stream.media.common.domain.HistoryStreamPlayType;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import java.time.LocalDateTime;
import lombok.Data;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 点播流请求对象
 */
@Data
public class FindHistoryStreamRequest {

  private String device;
  private String channel;
  private LocalDateTime start;
  private LocalDateTime end;
  private StreamType type;
  private StreamSourceProtocol protocol;

}
