package com.link.anything.middleware.stream.media.rest.request;

import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import lombok.Data;

/**
 * 直播流控制
 */
@Data
public class ControlLiveStreamRequest {

  /**
   * 流ID
   */
  private String stream;
  /**
   * 控制指令
   */
  private LiveStreamControl control;
  /**
   * 目标码率
   * <p>只有切换码流指令才有效</p>
   */
  private Integer bitStream;

}
