package com.link.anything.middleware.stream.media.rest.request;

import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import lombok.Data;

/**
 * 直播流请求对象
 */
@Data
public class TalkStreamRequest {

  /**
   * 设备编号
   */
  private String device;
  /**
   * 对讲通道号
   */
  private String channel;

  /**
   * 视频流协议
   */
  private StreamSourceProtocol sourceProtocol;

  /**
   * 传输方法
   */
  private StreamTransferMethod streamTransferMethod;

}
