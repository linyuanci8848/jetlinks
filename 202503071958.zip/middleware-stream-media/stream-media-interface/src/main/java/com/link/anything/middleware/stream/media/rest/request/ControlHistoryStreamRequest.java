package com.link.anything.middleware.stream.media.rest.request;

import com.link.anything.middleware.stream.media.common.domain.HistoryStreamControl;
import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import java.time.LocalDateTime;
import lombok.Data;

/**
 * 点播流控制
 */
@Data
public class ControlHistoryStreamRequest {

  /**
   * 流ID
   */
  private String stream;

  /**
   * 控制指令
   */
  private HistoryStreamControl control;

  /**
   * 倍数
   */
  Integer multiple;

  /**
   * 拖动时间点
   */
  Long point;
}
