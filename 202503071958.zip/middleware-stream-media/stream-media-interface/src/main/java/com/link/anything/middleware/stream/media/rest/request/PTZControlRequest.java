package com.link.anything.middleware.stream.media.rest.request;

import com.link.anything.middleware.stream.media.common.domain.LiveStreamControl;
import com.link.anything.middleware.stream.media.common.domain.PTZStreamControl;
import lombok.Data;

/**
 * 云台控制指令
 */
@Data
public class PTZControlRequest {

  /**
   * 流ID
   */
  private String stream;
  /**
   * 控制指令
   */
  private PTZStreamControl control;
  /**
   * 水平速度
   */
  private Integer horizonSpeed;
  /**
   * 缩放速度
   */
  private Integer zoomSpeed;
  /**
   * 垂直速度
   */
  private Integer verticalSpeed;

}
