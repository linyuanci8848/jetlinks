package com.link.anything.middleware.stream.media.rest.request;

import com.link.anything.middleware.stream.media.rest.interaction.HandlerMethod;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SocketRequest implements Serializable {

  /**
   * 请求key
   */
  private HandlerMethod method;
  /**
   * 请求参数体
   */
  private Object data;
  /**
   * 回调标识
   */
  private String callback;

}
