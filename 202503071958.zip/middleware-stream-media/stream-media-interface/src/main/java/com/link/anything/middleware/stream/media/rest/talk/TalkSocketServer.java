package com.link.anything.middleware.stream.media.rest.talk;

import com.link.anything.common.security.AESUtil;
import com.link.anything.middleware.stream.media.common.StreamServerProperties;
import com.link.anything.middleware.stream.media.protocol.TalkStreamContainer;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Slf4j
@Component
@ServerEndpoint("/talk/{token}")
public class TalkSocketServer implements DisposableBean {

  private static TalkStreamContainer talkStreamContainer;

  private static StreamServerProperties streamServerProperties;

  private static final Map<String, String> sessionMap = new ConcurrentHashMap<>();

  @Autowired
  public void setBean(TalkStreamContainer talkStreamContainer, StreamServerProperties streamServerProperties) {
    TalkSocketServer.talkStreamContainer = talkStreamContainer;
    TalkSocketServer.streamServerProperties = streamServerProperties;
  }

  @OnOpen
  public void OnOpen(Session session, @PathParam(value = "token") String token) {
    try {
      if (!StringUtils.hasLength(token)) {
        session.close();
      }
      //device_channel
      String deviceAndChannel = new String(AESUtil.decrypt(token.getBytes(StandardCharsets.UTF_8), streamServerProperties.getSecret() + "_" + LocalDateTime.now().getMinute()));
      String[] deviceAndChannelArray = deviceAndChannel.split("_");
      talkStreamContainer.join(deviceAndChannelArray[0], deviceAndChannelArray[1], session);
      sessionMap.put(session.getId(), deviceAndChannel);
    } catch (Exception e) {
      log.error(e.getMessage(), e);
      this.OnClose(session);
    }
  }

  @OnClose
  public void OnClose(Session session) {
    String[] deviceAndChannelArray = sessionMap.get(session.getId()).split("_");
    try {
      talkStreamContainer.kick(deviceAndChannelArray[0], deviceAndChannelArray[1]);
      sessionMap.remove(session.getId());
    } catch (Exception e) {
      log.error("语音对讲用户端连接关闭异常", e);
    }
  }

  /**
   * 收到客户端消息后调用的方法
   */

  @OnMessage
  public void OnMessage(byte[] message, boolean last, Session session) {
    if (message.length < 4) {
      return;
    }
    String[] deviceAndChannelArray = sessionMap.get(session.getId()).split("_");
    int affixLength = 8;
    byte[] realData = new byte[message.length - affixLength];
    System.arraycopy(message, 0, realData, 0, message.length - affixLength);
    Integer time = bytesToInteger(message, message.length - 4);
    Integer sequence = bytesToInteger(message, message.length - 8);
//    log.debug("收到语音对讲消息-length:{}, time:{}, sequence:{}", message.length, time, sequence);
    talkStreamContainer.downRedirect(deviceAndChannelArray[0], deviceAndChannelArray[1], sequence, time, realData);
  }

  private Integer bytesToInteger(byte[] bytes, int offset) {
    return (bytes[offset + 3] & 0xFF) << 24 | (bytes[offset + 2] & 0xFF) << 16 | (bytes[offset + 1] & 0xFF) << 8 | (bytes[offset] & 0xFF);
  }

  /**
   * 发生错误时调用
   *
   * @param session
   * @param error
   */
  @OnError
  public void onError(Session session, Throwable error) {
    String[] deviceAndChannelArray = sessionMap.get(session.getId()).split("_");
    log.error(deviceAndChannelArray[0] + "_" + deviceAndChannelArray[1] + "语音对讲用户端连接发生错误:" + session.toString(), error);
  }


  @Override
  public void destroy() {

  }
}
