package com.link.anything.middleware.stream.media.rest.interaction;

import com.link.anything.middleware.stream.media.rest.request.ControlHistoryStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.ControlLiveStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.FindHistoryStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.HistoryStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.LiveStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.PTZControlRequest;
import com.link.anything.middleware.stream.media.rest.request.TalkStreamRequest;

public enum HandlerMethod {
  /**
   * 心跳
   */
  Heart(Object.class),
  /**
   * 打开直播流
   */
  OpenLiveStream(LiveStreamRequest.class),
  /**
   * 控制直播流
   */
  ControlLiveStream(ControlLiveStreamRequest.class),
  /**
   * 查询录像文件
   */
  FindHistoryVideo(FindHistoryStreamRequest.class),
  /**
   * 打开录像流
   */
  OpenHistoryStream(HistoryStreamRequest.class),

  /**
   * 控制录像流
   */
  ControlHistoryStream(ControlHistoryStreamRequest.class),
  /**
   * 打开对讲流
   */
  OpenTalkStream(TalkStreamRequest.class),
  /**
   * 控制对讲流
   */
  ControlTalkStream(Object.class),
  /**
   * 设备状态
   */
  DeviceState(Object.class),
  /**
   * 云台控制
   */
  PTZControl(PTZControlRequest.class);

  private Class<?> data;

  public Class<?> getData() {
    return data;
  }

  HandlerMethod(Class<?> data) {
    this.data = data;
  }
}
