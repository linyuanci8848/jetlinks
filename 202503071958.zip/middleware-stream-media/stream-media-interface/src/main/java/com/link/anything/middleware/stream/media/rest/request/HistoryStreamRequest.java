package com.link.anything.middleware.stream.media.rest.request;

import com.link.anything.middleware.stream.media.common.domain.HistoryStreamPlayType;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import lombok.Data;

/**
 * 点播流请求对象
 */
@Data
public class HistoryStreamRequest {

  /**
   * 片段ID
   */
  private String stream;
  /**
   * 播放类型
   */
  private HistoryStreamPlayType playType;
  /**
   * 快进或者快退倍数
   */
  private Integer multiple = 0;
  /**
   * 取流方式
   */
  private StreamTransferMethod method;


}
