package com.link.anything.middleware.stream.media.rest.interceptors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.link.anything.middleware.stream.media.common.GlobalConstant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author YcYa_xbj
 */
@Slf4j
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

  @Value("${security.whitelist}")
  private List<String> whitelist = new ArrayList<>();
  @Resource
  private ObjectMapper objectMapper;


  @Resource
  private HttpServletRequest request;


  @Override
  public void addFormatters(FormatterRegistry registry) {
    registry.addConverter(String.class, Map.class, source -> {
      try {
        return objectMapper.readValue(source, Map.class);
      } catch (Exception e) {
        log.error(e.getMessage() + "【请求url : " + request.getRequestURL().toString() + "】", e);
        return null;
      }
    });
    registry.addConverter(String.class, LocalDate.class, source -> {
      try {
        if (!StringUtils.hasText(source)) {
          return null;
        }
        return LocalDate.parse(source, DateTimeFormatter.ofPattern(GlobalConstant.DEFAULT_DATE_FORMAT));
      } catch (Exception e) {
        log.error(e.getMessage() + "【请求url : " + request.getRequestURL().toString() + "】", e);
        return null;
      }
    });
    registry.addConverter(String.class, LocalDateTime.class, source -> {
      try {
        if (!StringUtils.hasText(source)) {
          return null;
        }
        return LocalDateTime.parse(source, DateTimeFormatter.ofPattern(GlobalConstant.DEFAULT_DATE_TIME_FORMAT));
      } catch (Exception e) {
        log.error(e.getMessage() + "【请求url : " + request.getRequestURL().toString() + "】", e);
        return null;
      }
    });
    registry.addConverter(String.class, LocalTime.class, source -> {
      try {
        if (!StringUtils.hasText(source)) {
          return null;
        }
        return LocalTime.parse(source, DateTimeFormatter.ofPattern(GlobalConstant.DEFAULT_TIME_FORMAT));
      } catch (Exception e) {
        log.error(e.getMessage() + "【请求url : " + request.getRequestURL().toString() + "】", e);
        return null;
      }
    });

  }


}
