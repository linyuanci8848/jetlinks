package com.link.anything.middleware.stream.media.rest.request;

import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.common.domain.StreamTransferMethod;
import com.link.anything.middleware.stream.media.common.domain.StreamType;
import lombok.Data;

/**
 * 直播流请求对象
 */
@Data
public class LiveStreamRequest {

  /**
   * 设备编号
   */
  private String device;
  /**
   * 通道编号
   */
  private String channel;
  /**
   * 码流
   */
  private Integer streamResolutionRatio;

  /**
   * 视频流协议
   */
  private StreamSourceProtocol sourceProtocol;

  /**
   * 传输协议
   */
  private StreamTransferMethod streamTransferMethod;


}
