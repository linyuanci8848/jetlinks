package com.link.anything.middleware.stream.media.rest.interaction;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.link.anything.middleware.stream.media.common.StreamServerProperties;
import com.link.anything.middleware.stream.media.common.SubscribeManager;
import com.link.anything.middleware.stream.media.common.constant.StreamDefinitionEventKey;
import com.link.anything.middleware.stream.media.common.domain.HistoryVideoSource;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.IStreamControlManager;
import com.link.anything.middleware.stream.media.rest.request.ControlHistoryStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.ControlLiveStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.FindHistoryStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.HistoryStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.LiveStreamRequest;
import com.link.anything.middleware.stream.media.rest.request.PTZControlRequest;
import com.link.anything.middleware.stream.media.rest.request.SocketRequest;
import com.link.anything.middleware.stream.media.rest.response.SocketResponse;
import com.link.anything.middleware.stream.media.rest.request.TalkStreamRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Slf4j
@Component
@ServerEndpoint("/data/{token}")
public class DataWebSocketServer implements DisposableBean {


    private static IStreamControlManager streamControlManager;

    private static IDeviceManager deviceManager;

    private static ObjectMapper objectMapper;


    private static ThreadPoolTaskExecutor taskExecutor;
    private static SubscribeManager subscribeManager;
    private static StreamServerProperties streamServerProperties;
    private static Long deviceStateEventId;

    private static final CopyOnWriteArraySet<Session> sessionSet = new CopyOnWriteArraySet<>();

    @Autowired
    public void setBean(
        StreamServerProperties streamServerProperties,
        SubscribeManager subscribeManager,
        @Qualifier("taskExecutor") ThreadPoolTaskExecutor taskExecutor,
        IStreamControlManager streamControlManager,
        ObjectMapper objectMapper,
        IDeviceManager deviceManager
    ) {
        DataWebSocketServer.taskExecutor = taskExecutor;
        DataWebSocketServer.streamControlManager = streamControlManager;
        DataWebSocketServer.objectMapper = objectMapper;
        DataWebSocketServer.deviceManager = deviceManager;
        DataWebSocketServer.subscribeManager = subscribeManager;
        DataWebSocketServer.streamServerProperties = streamServerProperties;
    }

    @OnOpen
    public void OnOpen(Session session, @PathParam(value = "token") String token) {
        try {
            //前端需要每个10秒发送一个心跳包
            session.setMaxIdleTimeout(30_1000L);
            if (!StringUtils.hasLength(token)) {
                session.close();
            }
            if (!"Cx2QL9UmTjYgWg7rNcKh".equals(token)) {
                session.close();
            }
            sessionSet.add(session);
            Map<String, Boolean> deviceState = deviceManager.findDeviceStatus();
            SocketResponse response = new SocketResponse(HandlerMethod.DeviceState, deviceState, true, "操作成功", HandlerMethod.DeviceState.name());
            if (session.isOpen()) {
                try {
                    session.getBasicRemote().sendText(objectMapper.writeValueAsString(response));
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
            }
            //监听设备状态变化
            deviceStateEventId = subscribeManager.subscribe(
                StreamDefinitionEventKey.DeviceStateChange.toString(),
                data -> {
                    SocketResponse stateResponse = new SocketResponse(HandlerMethod.DeviceState, data, true, "操作成功", HandlerMethod.DeviceState.name());
                    if (session.isOpen()) {
                        try {
                            session.getBasicRemote().sendText(objectMapper.writeValueAsString(stateResponse));
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                }
            );
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    @OnClose
    public void OnClose(Session session) {
        sessionSet.remove(session);
        //取消设备状态订阅
        subscribeManager.unSubscribe(StreamDefinitionEventKey.DeviceStateChange.toString(), deviceStateEventId);
        log.debug("数据交互连接关闭");
    }

    /**
     * 收到客户端消息后调用的方法
     */

    @OnMessage
    public void OnMessage(String message, Session session) {
        try {
            SocketRequest request = objectMapper.readValue(message, SocketRequest.class);
            taskExecutor.execute(() -> {
                SocketResponse response = new SocketResponse(request.getMethod(), null, true, "操作成功", request.getCallback());
                try {
                    Object data = null;
                    if (request.getMethod().equals(HandlerMethod.FindHistoryVideo)) {
                        //这个是异步操作所以这里不返回
                        FindHistoryStreamRequest findHistoryVideo = (FindHistoryStreamRequest) objectMapper.convertValue(request.getData(), request.getMethod().getData());
                        streamControlManager.findVideoHistory(findHistoryVideo.getDevice(), findHistoryVideo.getChannel(), findHistoryVideo.getProtocol(), findHistoryVideo.getStart(), findHistoryVideo.getEnd(),
                            findHistoryVideo.getType(), 1, HistoryVideoSource.Device, historyVideoFragments -> {
                                SocketResponse _response = new SocketResponse(request.getMethod(), historyVideoFragments, true, "操作成功", request.getCallback());
                                extracted(session, _response);
                            }, o -> {
                                SocketResponse _response = new SocketResponse(request.getMethod(), null, false, "等待设备超时", request.getCallback());
                                extracted(session, _response);
                            });
                        return;
                    }
                    switch (request.getMethod()) {
                        case Heart:
                            //心跳不进行处理
                            break;
                        case OpenLiveStream:
                            LiveStreamRequest openLiveStream = (LiveStreamRequest) objectMapper.convertValue(request.getData(), request.getMethod().getData());
                            data = streamControlManager.createLiveStream(openLiveStream.getDevice(), openLiveStream.getChannel(), openLiveStream.getStreamResolutionRatio(), openLiveStream.getSourceProtocol(),
                                openLiveStream.getStreamTransferMethod());
                            break;
                        case ControlLiveStream:
                            ControlLiveStreamRequest controlLiveStream = (ControlLiveStreamRequest) objectMapper.convertValue(request.getData(), request.getMethod().getData());
                            streamControlManager.controlLiveStream(controlLiveStream.getStream(), controlLiveStream.getControl(), controlLiveStream.getBitStream());
                            break;
                        case OpenHistoryStream:
                            HistoryStreamRequest openHistoryStream = (HistoryStreamRequest) objectMapper.convertValue(request.getData(), request.getMethod().getData());
                            data = streamControlManager.createAppointStream(openHistoryStream.getStream(), openHistoryStream.getMethod(), openHistoryStream.getPlayType(), openHistoryStream.getMultiple());
                            break;
                        case ControlHistoryStream:
                            ControlHistoryStreamRequest controlHistoryStream = (ControlHistoryStreamRequest) objectMapper.convertValue(request.getData(), request.getMethod().getData());
                            streamControlManager.controlAppointStream(controlHistoryStream.getStream(), controlHistoryStream.getControl(), controlHistoryStream.getMultiple(), controlHistoryStream.getPoint());
                            break;
                        case OpenTalkStream:
                            TalkStreamRequest openTalkStream = (TalkStreamRequest) objectMapper.convertValue(request.getData(), request.getMethod().getData());
                            String token = streamControlManager.createTalkLink(openTalkStream.getDevice(), openTalkStream.getSourceProtocol(), openTalkStream.getChannel(), openTalkStream.getStreamTransferMethod());
                            Map<String, Object> returnData = new HashMap<>();
                            returnData.put("token", token);
                            returnData.put("server", streamServerProperties.getId());
                            data = returnData;
                            break;
                        case DeviceState:

                            break;
                        case PTZControl:
                            PTZControlRequest ptzControlRequest = (PTZControlRequest) objectMapper.convertValue(request.getData(), request.getMethod().getData());
                            streamControlManager.controlPTZStream(ptzControlRequest.getStream(), ptzControlRequest.getControl(), ptzControlRequest.getHorizonSpeed(), ptzControlRequest.getZoomSpeed(),
                                ptzControlRequest.getVerticalSpeed());
                            break;
                    }
                    response.setData(data);
                } catch (Exception e) {
                    log.error(message + "：方法执行出错", e);
                    response.setOk(false);
                    response.setMessage(e.getMessage());
                }
                extracted(session, response);
            });
        } catch (IOException e) {
            log.error("请求参数序列化失败", e);
            try {
                session.close();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    private static void extracted(Session session, SocketResponse _response) {
        if (session.isOpen()) {
            try {
                session.getBasicRemote().sendText(objectMapper.writeValueAsString(_response));
            } catch (IOException e) {
                log.error("返回序列化失败");
            }
        }
    }

    /**
     * 发生错误时调用
     *
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {
        log.error("连接发生错误:" + session.toString(), error);
    }


    @Override
    public void destroy() {
        try {
            for (Session session : sessionSet) {
                session.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }
}
