package com.link.anything.middleware.stream.media.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.link.anything.common.security.AESUtil;
import com.link.anything.middleware.stream.media.common.domain.StreamSourceProtocol;
import com.link.anything.middleware.stream.media.control.IDeviceManager;
import com.link.anything.middleware.stream.media.control.domain.DeviceChannel;
import com.link.anything.middleware.stream.media.protocol.IProtocolExecutor;
import com.link.anything.middleware.stream.media.protocol.ProtocolExecutorProvider;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Tag(name = "SDK管理接口")
@RestController
@Validated
@Slf4j
public class SDKController {

    @Resource
    private IDeviceManager deviceManager;
    @Resource
    private ProtocolExecutorProvider protocolExecutorProvider;

    protected static String secret = "aInDdmwPAK5mRkCl";

    @Resource
    private ObjectMapper objectMapper;

    @Operation(summary = "设备通道变更")
    @PostMapping("/sdk/device/channel")
    public String deviceChannel() {
        try {
            List<DeviceChannel> channels = deviceManager.findDeviceChannel();
            //<Model>AlarmIn</Model> 这个是报警通道
            //这里是要获取摄像头所以要过滤
            channels = channels.stream().filter(item -> Objects.equals(item.getModel(), "Camera")).collect(Collectors.toList());
            String data = objectMapper.writeValueAsString(channels);
            data = new String(AESUtil.encrypt(data.getBytes(StandardCharsets.UTF_8), secret), StandardCharsets.UTF_8);
            return data;
        } catch (Exception e) {
            log.error("设备通道队列获取数据出错", e);
        }
        return "";
    }

    @Operation(summary = "获取设施是否在线")
    @GetMapping("/sdk/device/onLine")
    public boolean deviceOnline(String number) {
        try {
            return deviceManager.isOnline(number);
        } catch (Exception e) {
            log.error("获取数据出错", e);
        }
        return false;
    }
    @Operation(summary = "获取所有设备是否在线")
    @GetMapping("/sdk/device/allOnLine")
    public  Map<String, Boolean>  deviceOnline() {
        try {
            return   deviceManager.findDeviceStatus();
        } catch (Exception e) {
            log.error("获取数据出错", e);
        }
        return null;
    }


    /**
     * 视频抓图
     */
    @Operation(summary = "视频抓图")
    @GetMapping("/sdk/channels/{channelNo}/capture")
    public ResponseEntity<org.springframework.core.io.Resource> downloadCapture(@PathVariable(value = "channelNo") String channelNo, @RequestParam(value = "protocol") String protocol, @RequestParam(value = "overflow", required = false) boolean overflow) {
        try {
            org.springframework.core.io.Resource resource;
            if (overflow) {
                // 满溢测试
                resource = new ClassPathResource("/capture/overflow.png");
            } else {
                StreamSourceProtocol streamSourceProtocol = StreamSourceProtocol.valueOf(protocol);
                IProtocolExecutor protocolExecutor = protocolExecutorProvider.getProtocolExecutor(streamSourceProtocol);
                resource = protocolExecutor.captureAsResource(channelNo);
            }

            if (resource.exists() || resource.isReadable()) {
                // 设置响应头
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"");
                return ResponseEntity.ok()
                        .headers(headers)
                        .contentType(MediaType.APPLICATION_OCTET_STREAM)
                        .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return ResponseEntity.badRequest().build();
        }
    }
}
